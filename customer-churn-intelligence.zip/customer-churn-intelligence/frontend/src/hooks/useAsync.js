import { useCallback, useEffect, useRef, useState } from 'react'

/** Run an async loader on mount/deps change. Returns {data, loading, error, reload}. */
export function useAsync(fn, deps = [], { enabled = true } = {}) {
  const [state, setState] = useState({ data: null, loading: enabled, error: null })
  const seq = useRef(0)
  const run = useCallback(() => {
    const id = ++seq.current
    setState((s) => ({ ...s, loading: true, error: null }))
    return fn()
      .then((data) => id === seq.current && setState({ data, loading: false, error: null }))
      .catch((e) => id === seq.current && setState({ data: null, loading: false, error: e.friendly || e.message }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
  useEffect(() => {
    if (enabled) run()
    else setState({ data: null, loading: false, error: null })
  }, [run, enabled])
  return { ...state, reload: run }
}
