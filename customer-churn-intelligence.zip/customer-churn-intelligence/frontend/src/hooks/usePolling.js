import { useEffect, useRef } from 'react'

/** Calls `fn` every `ms` while `active` is true. */
export function usePolling(fn, active, ms = 2000) {
  const ref = useRef(fn)
  ref.current = fn
  useEffect(() => {
    if (!active) return
    const t = setInterval(() => ref.current(), ms)
    return () => clearInterval(t)
  }, [active, ms])
}
