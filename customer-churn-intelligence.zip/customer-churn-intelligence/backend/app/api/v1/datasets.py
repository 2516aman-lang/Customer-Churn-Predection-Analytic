from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ...database.models import Dataset, User
from ...database.session import get_db
from ...schemas import CleanIn, DatasetOut, DatasetUpdate, SampleIn
from ...services import dataset_service as svc
from ...services.common import to_records
from ..deps import current_user, get_dataset

router = APIRouter(prefix="/datasets", tags=["datasets"])


@router.get("", response_model=list[DatasetOut])
def list_datasets(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return db.query(Dataset).filter(Dataset.owner_id == user.id).order_by(Dataset.id.desc()).all()


@router.post("/upload", response_model=DatasetOut, status_code=201)
async def upload(file: UploadFile = File(...), db: Session = Depends(get_db), user: User = Depends(current_user)):
    try:
        df = svc.read_upload(file.filename or "upload.csv", await file.read())
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"Could not read file: {e}")
    return svc.create_dataset(db, user, (file.filename or "dataset").rsplit(".", 1)[0], file.filename or "upload.csv", df)


@router.put("/{dataset_id}/data", response_model=DatasetOut)
async def replace_data(dataset_id: int, file: UploadFile = File(...), db: Session = Depends(get_db),
                       user: User = Depends(current_user)):
    """Replace a dataset's rows with a newer extract (same columns). Scheduled re-scoring picks it up."""
    ds = get_dataset(db, dataset_id, user)
    try:
        df = svc.read_upload(file.filename or "upload.csv", await file.read())
        return svc.replace_data(db, ds, df)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/sample", response_model=DatasetOut, status_code=201)
def sample(body: SampleIn = SampleIn(), db: Session = Depends(get_db), user: User = Depends(current_user)):
    return svc.create_sample(db, user, body.rows, body.seed)


@router.get("/{dataset_id}", response_model=DatasetOut)
def get_one(dataset_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return get_dataset(db, dataset_id, user)


@router.patch("/{dataset_id}", response_model=DatasetOut)
def update(dataset_id: int, body: DatasetUpdate, db: Session = Depends(get_db), user: User = Depends(current_user)):
    ds = get_dataset(db, dataset_id, user)
    raw = svc.load_df(ds, prefer_clean=False)
    if body.name:
        ds.name = body.name
    if body.target is not None:
        if body.target not in raw.columns:
            raise HTTPException(400, f"Column '{body.target}' not found")
        ds.target = body.target
        ds.status, ds.clean_path, ds.cleaning_report = "raw", None, None  # target changed → needs re-clean
    if body.id_columns is not None:
        bad = [c for c in body.id_columns if c not in raw.columns]
        if bad:
            raise HTTPException(400, f"Unknown columns: {bad}")
        ds.id_columns = body.id_columns
    db.commit()
    return svc.revalidate(db, ds)


@router.get("/{dataset_id}/preview")
def preview(dataset_id: int, rows: int = Query(50, ge=1, le=500), offset: int = Query(0, ge=0), version: str = "auto",
            db: Session = Depends(get_db), user: User = Depends(current_user)):
    ds = get_dataset(db, dataset_id, user)
    df = svc.load_df(ds, prefer_clean=(version != "raw"))
    return {"columns": list(df.columns), "total": int(len(df)), "rows": to_records(df.iloc[offset: offset + rows])}


@router.post("/{dataset_id}/validate")
def validate(dataset_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return svc.revalidate(db, get_dataset(db, dataset_id, user)).validation


@router.post("/{dataset_id}/clean", response_model=DatasetOut)
def clean(dataset_id: int, body: CleanIn = CleanIn(), db: Session = Depends(get_db), user: User = Depends(current_user)):
    ds = get_dataset(db, dataset_id, user)
    try:
        return svc.clean(db, ds, **body.model_dump())
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/{dataset_id}/download")
def download(dataset_id: int, version: str = "clean", db: Session = Depends(get_db), user: User = Depends(current_user)):
    ds = get_dataset(db, dataset_id, user)
    path = ds.clean_path if version == "clean" and ds.clean_path else ds.raw_path
    return FileResponse(path, media_type="text/csv", filename=f"{ds.name}_{version}.csv")


@router.delete("/{dataset_id}", status_code=204)
def delete(dataset_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    from ...database.models import MLModel, ScoringRun

    ds = get_dataset(db, dataset_id, user)
    if db.query(MLModel).filter(MLModel.dataset_id == ds.id).first():
        raise HTTPException(409, "Delete the models trained on this dataset first")
    db.query(ScoringRun).filter(ScoringRun.dataset_id == ds.id).update({ScoringRun.dataset_id: None})
    svc.delete_files(ds)
    db.delete(ds)
    db.commit()
