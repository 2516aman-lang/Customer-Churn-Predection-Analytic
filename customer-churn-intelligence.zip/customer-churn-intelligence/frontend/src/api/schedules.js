import client, { data } from './client'
export const listSchedules = () => data(client.get('/schedules'))
export const createSchedule = (b) => data(client.post('/schedules', b))
export const updateSchedule = (id, b) => data(client.patch(`/schedules/${id}`, b))
export const runSchedule = (id) => data(client.post(`/schedules/${id}/run`))
export const deleteSchedule = (id) => client.delete(`/schedules/${id}`)
