"""Export at-risk customer lists: CRM-ready CSV, SMTP email with attachment, webhook push."""
from __future__ import annotations

import ipaddress
import json
import smtplib
import socket
from email.message import EmailMessage
from urllib.parse import urlparse

import httpx
import pandas as pd

from ..core.config import settings
from ..database.models import ScoringRun
from . import prediction_service, retention_service

TIER_ORDER = ["Low", "Medium", "High", "Critical"]

# Column naming conventions for common CRMs. These are *custom property* names: create matching fields in the CRM
# (or edit the mapping in the import wizard) and map the customer ID to your CRM's external-id/record key.
CRM_FORMATS = {
    "generic": {"id": "customer_id", "churn_probability": "churn_probability", "risk_tier": "risk_tier",
                "monthly_value": "monthly_value", "expected_loss": "expected_loss", "primary_driver": "primary_driver",
                "recommended_action": "recommended_action", "action_owner": "action_owner"},
    "salesforce": {"id": "External_Id__c", "churn_probability": "Churn_Risk_Score__c", "risk_tier": "Churn_Risk_Tier__c",
                   "monthly_value": "Monthly_Value__c", "expected_loss": "Expected_Loss__c",
                   "primary_driver": "Churn_Driver__c", "recommended_action": "Recommended_Action__c",
                   "action_owner": "Action_Owner__c"},
    "hubspot": {"id": "customer_id", "churn_probability": "churn_risk_score", "risk_tier": "churn_risk_tier",
                "monthly_value": "monthly_value", "expected_loss": "expected_loss", "primary_driver": "churn_driver",
                "recommended_action": "recommended_action", "action_owner": "action_owner"},
}


def at_risk_frame(run: ScoringRun, min_tier: str = "High", clv_months: int = 12) -> pd.DataFrame:
    if min_tier not in TIER_ORDER:
        raise ValueError(f"min_tier must be one of {TIER_ORDER}")
    df = retention_service.prepared(run, prediction_service.load_run(run), clv_months)
    df = df[df["risk_tier"].map(TIER_ORDER.index) >= TIER_ORDER.index(min_tier)].sort_values("expected_loss", ascending=False)
    id_col = (run.summary or {}).get("id_column")
    out = pd.DataFrame({"id": df[id_col].astype(str) if id_col and id_col in df.columns else df.index.astype(str)})
    for c in ("churn_probability", "risk_tier", "monthly_value", "expected_loss", "primary_driver", "recommended_action", "action_owner"):
        out[c] = df[c].values
    return out.reset_index(drop=True)


def to_crm(df: pd.DataFrame, fmt: str = "generic") -> pd.DataFrame:
    if fmt not in CRM_FORMATS:
        raise ValueError(f"format must be one of {list(CRM_FORMATS)}")
    return df.rename(columns=CRM_FORMATS[fmt])


def csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode()


# ---------------------------------------------------------------- email
def smtp_configured() -> bool:
    return bool(settings.SMTP_HOST)


def send_email(recipients: list[str], subject: str, body: str, attachment: bytes | None = None,
               filename: str = "at_risk_customers.csv") -> None:
    if not smtp_configured():
        raise ValueError("Email is not configured on the server (set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD)")
    recipients = [r.strip() for r in recipients if r.strip()]
    if not recipients:
        raise ValueError("At least one recipient is required")
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = settings.SMTP_FROM, ", ".join(recipients), subject
    msg.set_content(body)
    if attachment:
        msg.add_attachment(attachment, maintype="text", subtype="csv", filename=filename)
    with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=30) as s:
        if settings.SMTP_STARTTLS:
            s.starttls()
        if settings.SMTP_USER:
            s.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
        s.send_message(msg)


def summary_text(run: ScoringRun, df: pd.DataFrame, min_tier: str) -> str:
    top = df.head(5)
    lines = [f"Churn risk update: {run.name}", "",
             f"{len(df)} customers at {min_tier} risk or above, expected loss {df['expected_loss'].sum():,.0f}.", "",
             "Top 5 by expected loss:"]
    lines += [f"  - {r.id}: {r.churn_probability:.0%} risk, {r.recommended_action}" for r in top.itertuples()]
    lines += ["", "Full list attached as CSV."]
    return "\n".join(lines)


# ---------------------------------------------------------------- webhook
def webhook_configured() -> bool:
    return bool(settings.CRM_WEBHOOK_URL)


def _check_url(url: str) -> None:
    """SSRF guard: https/http only; refuse private, loopback, link-local targets unless explicitly allowed."""
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Webhook URL must be an http(s) URL")
    if settings.ALLOW_PRIVATE_WEBHOOKS:
        return
    try:
        addrs = {ipaddress.ip_address(a[4][0]) for a in socket.getaddrinfo(p.hostname, p.port or 443)}
    except socket.gaierror:
        raise ValueError("Webhook host could not be resolved")
    if any(a.is_private or a.is_loopback or a.is_link_local or a.is_reserved or a.is_multicast for a in addrs):
        raise ValueError("Webhook target resolves to a private/internal address (blocked)")


def push_webhook(run: ScoringRun, df: pd.DataFrame, url: str | None = None, batch: int = 500) -> dict:
    url = url or settings.CRM_WEBHOOK_URL
    if not url:
        raise ValueError("No webhook URL configured (set CRM_WEBHOOK_URL or pass a url)")
    _check_url(url)
    headers = {"Content-Type": "application/json"}
    if settings.CRM_WEBHOOK_TOKEN:
        headers["Authorization"] = f"Bearer {settings.CRM_WEBHOOK_TOKEN}"
    # to_json maps NaN -> null so the payload is strict JSON (blank drivers/actions are common)
    records = json.loads(df.rename(columns={"id": "customer_id"}).to_json(orient="records"))
    sent = 0
    for i in range(0, len(records), batch):
        chunk = records[i: i + batch]
        r = httpx.post(url, json={"source": "churn-intelligence", "run_id": run.id, "batch": i // batch + 1,
                                  "customers": chunk}, headers=headers, timeout=30, follow_redirects=False)
        if r.status_code >= 400:
            raise ValueError(f"Webhook returned HTTP {r.status_code} after {sent} customers were delivered")
        sent += len(chunk)
    return {"delivered": sent, "batches": -(-len(records) // batch) if records else 0}
