from __future__ import annotations

import numpy as np
import pandas as pd

from .common import find_revenue_col, to_records

from src.cleaning import normalize_target


def _target(df: pd.DataFrame, target: str) -> pd.Series:
    return normalize_target(df[target]) if not pd.api.types.is_integer_dtype(df[target]) else df[target]


def overview(df: pd.DataFrame, target: str | None) -> dict:
    out = {"rows": int(len(df)), "columns": int(df.shape[1]), "target": target}
    if not target or target not in df.columns:
        return out
    y = _target(df, target)
    ok = y.notna()
    out["churn_rate"] = round(float(y[ok].mean()), 4)
    out["churned"] = int(y[ok].sum())
    out["retained"] = int((1 - y[ok]).sum())
    rev = find_revenue_col(df)
    if rev:
        out["revenue_column"] = rev
        out["avg_monthly_revenue"] = round(float(df[rev].mean()), 2)
        out["monthly_revenue_churned"] = round(float(df.loc[ok & (y == 1), rev].sum()), 2)
        out["monthly_revenue_total"] = round(float(df[rev].sum()), 2)
    ten = next((c for c in df.columns if str(c).lower() == "tenure"), None)
    if ten:
        out["avg_tenure"] = round(float(df[ten].mean()), 2)
    return out


def eda(df: pd.DataFrame, target: str | None, id_columns: list[str] | None = None, bins: int = 12, max_cats: int = 12) -> dict:
    id_columns = id_columns or []
    y = _target(df, target) if target and target in df.columns else None
    cols = [c for c in df.columns if c != target and c not in id_columns]
    num = [c for c in cols if pd.api.types.is_numeric_dtype(df[c])]
    cat = [c for c in cols if c not in num and df[c].nunique() <= 50]

    numeric = []
    for c in num:
        s = df[c].dropna()
        if s.empty:
            continue
        edges = np.histogram_bin_edges(s, bins=min(bins, max(s.nunique(), 2)))
        item = {"column": c, "mean": round(float(s.mean()), 3), "median": round(float(s.median()), 3),
                "std": round(float(s.std() or 0), 3), "min": float(s.min()), "max": float(s.max()), "bins": []}
        for lo, hi in zip(edges[:-1], edges[1:]):
            m = (df[c] >= lo) & ((df[c] < hi) if hi != edges[-1] else (df[c] <= hi))
            b = {"label": f"{lo:.4g}–{hi:.4g}", "count": int(m.sum())}
            if y is not None:
                yy = y[m]
                b["churned"] = int((yy == 1).sum())
                b["retained"] = int((yy == 0).sum())
                b["churn_rate"] = round(float(yy.mean()), 4) if len(yy) else 0
            item["bins"].append(b)
        if y is not None:
            item["mean_churned"] = round(float(df.loc[y == 1, c].mean()), 3)
            item["mean_retained"] = round(float(df.loc[y == 0, c].mean()), 3)
        numeric.append(item)

    categorical = []
    for c in cat:
        item = {"column": c, "values": []}
        for v, g in df.groupby(c, dropna=False):
            n = len(g)
            row = {"value": str(v), "count": int(n)}
            if y is not None:
                row["churn_rate"] = round(float(y.loc[g.index].mean()), 4)
            item["values"].append(row)
        item["values"] = sorted(item["values"], key=lambda r: -r["count"])[:max_cats]
        if y is not None:
            rates = [v["churn_rate"] for v in item["values"]]
            item["spread"] = round(max(rates) - min(rates), 4) if rates else 0
        categorical.append(item)
    categorical.sort(key=lambda i: -i.get("spread", 0))

    corr_cols = num + ([target] if y is not None else [])
    corr = None
    if len(corr_cols) >= 2:
        frame = df[num].copy()
        if y is not None:
            frame[target] = y
        cm = frame.corr(numeric_only=True).fillna(0).round(3)
        corr = {"columns": list(cm.columns), "matrix": cm.values.tolist()}

    target_corr = []
    if y is not None and num:
        for c in num:
            r = df[c].corr(y)
            if pd.notna(r):
                target_corr.append({"feature": c, "correlation": round(float(r), 4)})
        target_corr.sort(key=lambda r: -abs(r["correlation"]))

    missing = [{"column": c, "missing": int(df[c].isna().sum()), "pct": round(float(df[c].isna().mean() * 100), 2)}
               for c in df.columns if df[c].isna().any()]
    return {"overview": overview(df, target), "numeric": numeric, "categorical": categorical,
            "correlation": corr, "target_correlation": target_corr, "missing": missing}


def segment(df: pd.DataFrame, target: str, by: str, bins: int = 5) -> list[dict]:
    y = _target(df, target)
    s = df[by]
    if pd.api.types.is_numeric_dtype(s) and s.nunique() > 12:
        s = pd.qcut(s, q=bins, duplicates="drop").astype(str)
    g = pd.DataFrame({"seg": s.astype(str), "y": y}).groupby("seg")["y"].agg(["count", "mean"]).reset_index()
    g.columns = ["segment", "customers", "churn_rate"]
    g["churn_rate"] = g["churn_rate"].round(4)
    return to_records(g.sort_values("churn_rate", ascending=False))
