"""Feature engineering and preprocessing pipeline construction."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


class FeatureEngineer(BaseEstimator, TransformerMixin):
    """Adds generic, safe derived features when the source columns exist (case-insensitive)."""

    def fit(self, X, y=None):
        self.cols_ = {str(c).lower(): c for c in X.columns}
        return self

    def transform(self, X):
        X = X.copy()
        low = {str(c).lower(): c for c in X.columns}
        ten, mon, tot = low.get("tenure"), low.get("monthlycharges"), low.get("totalcharges")
        if ten and mon:
            X["fe_expected_total"] = pd.to_numeric(X[ten], errors="coerce") * pd.to_numeric(X[mon], errors="coerce")
        if ten and tot:
            t = pd.to_numeric(X[ten], errors="coerce").replace(0, np.nan)
            X["fe_avg_monthly_spend"] = pd.to_numeric(X[tot], errors="coerce") / t
        if ten:
            X["fe_tenure_bucket"] = pd.cut(
                pd.to_numeric(X[ten], errors="coerce"), [-1, 6, 12, 24, 48, np.inf],
                labels=["0-6", "7-12", "13-24", "25-48", "49+"],
            ).astype(object)
        return X.replace([np.inf, -np.inf], np.nan)


def split_columns(X: pd.DataFrame) -> tuple[list[str], list[str]]:
    num = [c for c in X.columns if pd.api.types.is_numeric_dtype(X[c]) and not pd.api.types.is_bool_dtype(X[c])]
    cat = [c for c in X.columns if c not in num]
    return num, cat


def build_pipeline(estimator, X_sample: pd.DataFrame, scale: bool = True) -> Pipeline:
    fe = FeatureEngineer().fit(X_sample)
    Xe = fe.transform(X_sample.head(200))
    num, cat = split_columns(Xe)
    num_steps = [("imp", SimpleImputer(strategy="median"))]
    if scale:
        num_steps.append(("scale", StandardScaler()))
    pre = ColumnTransformer(
        [
            ("num", Pipeline(num_steps), num),
            (
                "cat",
                Pipeline([
                    ("imp", SimpleImputer(strategy="most_frequent")),
                    ("oh", OneHotEncoder(handle_unknown="ignore", min_frequency=0.01, sparse_output=False)),
                ]),
                cat,
            ),
        ],
        verbose_feature_names_out=False,
    )
    return Pipeline([("fe", FeatureEngineer()), ("pre", pre), ("model", estimator)])
