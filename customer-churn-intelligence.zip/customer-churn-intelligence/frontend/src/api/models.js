import client, { data } from './client'
export const listAlgorithms = () => data(client.get('/models/algorithms'))
export const listModels = (dataset_id) => data(client.get('/models', { params: { dataset_id } }))
export const trainModels = (body) => data(client.post('/models/train', body))
export const getModel = (id) => data(client.get(`/models/${id}`))
export const compareModels = (ids) => data(client.get('/models/compare', { params: { ids: ids.join(',') } }))
export const activateModel = (id) => data(client.post(`/models/${id}/activate`))
export const deleteModel = (id) => client.delete(`/models/${id}`)
