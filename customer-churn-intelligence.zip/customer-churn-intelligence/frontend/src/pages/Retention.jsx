import { useEffect, useState } from 'react'
import { Calculator, Download, Mail, Send } from 'lucide-react'
import { download } from '../api/client'
import { exportConfig, exportEmail, exportWebhook, retentionCustomers, retentionOverview, retentionRecs, simulateCampaign } from '../api/predictions'
import { Badge, Button, Card, EmptyState, Field, Loader, NumberField, PageHeader, Select, StatCard, Tabs, fmt, TIER_COLORS } from '../components/common'
import { CurveArea, HBar } from '../components/charts'
import DataTable from '../components/tables/DataTable'
import { useApp } from '../context/AppContext'
import { useAction } from '../hooks/useAction'
import { useAsync } from '../hooks/useAsync'

export default function Retention() {
  const { runs } = useApp()
  const [runId, setRunId] = useState(null)
  const [months, setMonths] = useState(12)
  const [tab, setTab] = useState('overview')
  useEffect(() => { if (!runId && runs.length) setRunId(runs[0].id) }, [runs.length])
  if (!runs.length) return <><PageHeader title="Retention" /><Card><EmptyState title="Score your customers first" text="Retention plans are built from a scoring run (Predictions → Batch scoring)." /></Card></>
  return (
    <>
      <PageHeader title="Retention" subtitle="Turn churn risk into prioritised actions and a defensible campaign budget.">
        <div style={{ minWidth: 280 }}><Select label="Scoring run" value={runId ?? ''} onChange={(v) => setRunId(Number(v))} options={runs.map((r) => ({ value: r.id, label: `#${r.id} ${r.name}` }))} /></div>
        <div style={{ width: 150 }}><NumberField label="Value horizon (months)" value={months} min={1} max={120} onChange={(v) => setMonths(v || 12)} /></div>
      </PageHeader>
      <Tabs value={tab} onChange={setTab} tabs={[{ key: 'overview', label: 'Overview' }, { key: 'customers', label: 'At-risk customers' }, { key: 'playbook', label: 'Action playbook' }, { key: 'sim', label: 'Campaign simulator' }, { key: 'export', label: 'Export & CRM' }]} />
      {runId && tab === 'overview' && <Overview runId={runId} months={months} />}
      {runId && tab === 'customers' && <Customers runId={runId} months={months} />}
      {runId && tab === 'playbook' && <Playbook runId={runId} months={months} />}
      {runId && tab === 'sim' && <Simulator runId={runId} months={months} />}
      {runId && tab === 'export' && <Export runId={runId} months={months} />}
    </>
  )
}

function Overview({ runId, months }) {
  const { data: o, loading } = useAsync(() => retentionOverview(runId, months), [runId, months])
  if (loading || !o) return <Loader />
  return (
    <div className="stack">
      <div className="grid g4">
        <StatCard label="Customers scored" value={fmt.num(o.customers)} />
        <StatCard label="Predicted churners" value={fmt.num(o.predicted_churners)} tone="bad" />
        <StatCard label={`Expected loss (${months}m)`} value={fmt.money(o.total_expected_loss)} tone="bad" hint="Σ probability × customer value" />
        <StatCard label="Monthly revenue at risk" value={fmt.money(o.monthly_revenue_at_risk)} />
      </div>
      <div className="grid g2">
        <Card title="Expected loss by risk tier"><HBar data={o.tiers} labelKey="tier" valueKey="expected_loss" format={fmt.money} h={220} width={70} /></Card>
        <Card title="Tier breakdown"><div className="table-wrap"><table><thead><tr><th>Tier</th><th>Customers</th><th>Avg prob.</th><th>Expected loss</th></tr></thead><tbody>{o.tiers.map((t) => <tr key={t.tier}><td><Badge kind={t.tier} /></td><td>{fmt.num(t.customers)}</td><td>{fmt.pct(t.avg_probability)}</td><td>{fmt.money(t.expected_loss)}</td></tr>)}</tbody></table></div></Card>
        <Card title="Primary churn drivers" sub="Top churn-increasing factor per predicted churner"><HBar data={o.drivers.slice(0, 8)} labelKey="feature" valueKey="customers" h={280} /></Card>
        <Card title="Where to intervene" sub="Expected loss by retention lever"><HBar data={o.levers} labelKey="lever" valueKey="expected_loss" format={fmt.money} color="#e11d48" h={280} /></Card>
      </div>
    </div>
  )
}

function Customers({ runId, months }) {
  const [tier, setTier] = useState('All')
  const [offset, setOffset] = useState(0)
  useEffect(() => setOffset(0), [tier, runId])
  const { data, loading } = useAsync(() => retentionCustomers(runId, { tier, limit: 15, offset, clv_months: months }), [runId, tier, offset, months])
  const cols = data ? [
    { key: data.id_column, label: 'Customer' },
    { key: 'churn_probability', label: 'Risk', render: (v) => fmt.pct(v) },
    { key: 'risk_tier', label: 'Tier', render: (v) => <Badge kind={v} /> },
    { key: 'monthly_value', label: 'Monthly value', render: fmt.money },
    { key: 'expected_loss', label: 'Expected loss', render: fmt.money },
    { key: 'top_drivers', label: 'Why', wrap: true, render: (v) => v.filter((d) => d.impact > 0).slice(0, 2).map((d) => `${d.feature}=${d.value}`).join(', ') || '—' },
    { key: 'recommended_action', label: 'Recommended action', wrap: true },
  ] : []
  return (
    <Card title="Highest-value customers at risk" sub="Ranked by expected loss (probability × value)">
      <div className="stack">
        <div className="row">{['All', 'Critical', 'High', 'Medium', 'Low'].map((t) => <button key={t} className={`btn sm ${tier === t ? 'primary' : ''}`} onClick={() => setTier(t)} style={t !== 'All' && tier !== t ? { borderLeft: `3px solid ${TIER_COLORS[t]}` } : undefined}>{t}</button>)}</div>
        {loading && !data ? <Loader /> : data && <DataTable columns={cols} rows={data.rows} total={data.total} offset={offset} limit={15} onPage={setOffset} />}
      </div>
    </Card>
  )
}

function Playbook({ runId, months }) {
  const { data, loading } = useAsync(() => retentionRecs(runId, months), [runId, months])
  if (loading || !data) return <Loader />
  return (
    <Card title="Next-best-action playbook" sub="Each predicted churner is mapped from their strongest churn driver to an intervention">
      <DataTable rows={data} columns={[
        { key: 'recommended_action', label: 'Action', wrap: true }, { key: 'lever', label: 'Lever' }, { key: 'action_owner', label: 'Owner' },
        { key: 'customers', label: 'Customers', render: fmt.num }, { key: 'avg_probability', label: 'Avg risk', render: (v) => fmt.pct(v) }, { key: 'expected_loss', label: 'Expected loss', render: fmt.money },
      ]} />
    </Card>
  )
}

function Simulator({ runId, months }) {
  const [p, setP] = useState({ budget: 10000, cost_per_contact: 15, offer_cost_pct: 10, success_rate: 0.3, min_probability: 0.5, default_monthly_value: 60 })
  const [res, setRes] = useState(null)
  const [run, busy] = useAction(async () => setRes(await simulateCampaign(runId, { ...p, clv_months: months })))
  useEffect(() => { setRes(null) }, [runId, months])
  const set = (k) => (v) => setP({ ...p, [k]: v === '' ? 0 : v })
  return (
    <div className="grid g-wide" style={{ gridTemplateColumns: '1fr 2fr' }}>
      <Card title="Campaign assumptions">
        <div className="stack">
          <NumberField label="Budget" value={p.budget} step={500} onChange={set('budget')} />
          <NumberField label="Cost per contact" value={p.cost_per_contact} onChange={set('cost_per_contact')} />
          <NumberField label="Offer cost (% of customer value)" value={p.offer_cost_pct} onChange={set('offer_cost_pct')} help="Paid only for customers who accept" />
          <NumberField label="Save rate (0–1)" value={p.success_rate} step={0.05} min={0} max={1} onChange={set('success_rate')} help="Share of at-risk contacted customers retained" />
          <NumberField label="Min. churn probability to target" value={p.min_probability} step={0.05} min={0} max={1} onChange={set('min_probability')} />
          <NumberField label="Fallback monthly value" value={p.default_monthly_value} onChange={set('default_monthly_value')} help="Used if the data has no revenue column" />
          <Button variant="primary" icon={Calculator} busy={busy} onClick={run}>Simulate</Button>
        </div>
      </Card>
      <div className="stack">
        {!res ? <Card><EmptyState title="Set assumptions and simulate" text="Customers are targeted in order of net expected value until the budget is spent." /></Card> : (
          <>
            <div className="grid g4">
              <StatCard label="Customers contacted" value={fmt.num(res.contacted)} hint={`of ${fmt.num(res.eligible)} profitable targets`} />
              <StatCard label="Expected saves" value={res.expected_customers_saved} tone="good" />
              <StatCard label="Net benefit" value={fmt.money(res.net_benefit)} tone={res.net_benefit >= 0 ? 'good' : 'bad'} hint={`ROI ${(res.roi * 100).toFixed(0)}%`} />
              <StatCard label="Campaign cost" value={fmt.money(res.campaign_cost)} hint={`${fmt.pct(res.budget_used_pct, 0)} of budget`} />
            </div>
            <Card title="Cumulative net benefit" sub="Diminishing returns as lower-risk customers are added"><CurveArea data={res.curve} x="contacted" y="cumulative_net" format={fmt.money} /></Card>
          </>
        )}
      </div>
    </div>
  )
}

const TIERS = ['Critical', 'High', 'Medium', 'Low']

function Export({ runId, months }) {
  const { data: cfg } = useAsync(exportConfig, [])
  const [tier, setTier] = useState('High')
  const [crm, setCrm] = useState('generic')
  const [to, setTo] = useState('')
  const [note, setNote] = useState('')
  const [csv, b0] = useAction(() => download(`/retention/${runId}/export/csv`, `at_risk_${crm}_run${runId}.csv`, { fmt: crm, min_tier: tier, clv_months: months }))
  const [mail, b1] = useAction(async () => exportEmail(runId, { to: to.split(/[,;\s]+/).filter(Boolean), min_tier: tier, crm_format: crm, message: note || null }), { success: (r) => `Emailed ${r.customers} customers` })
  const [hook, b2] = useAction(async () => exportWebhook(runId, { min_tier: tier }), { success: (r) => `Delivered ${r.delivered} customers in ${r.batches} batch(es)` })
  return (
    <div className="grid g2">
      <Card title="What to export" sub="Customers at or above the chosen tier, ranked by expected loss">
        <div className="stack">
          <Select label="Minimum risk tier" value={tier} onChange={setTier} options={TIERS} />
          <Select label="CRM column format" value={crm} onChange={setCrm} options={cfg?.crm_formats || ['generic']} help="Salesforce / HubSpot use custom-property names (e.g. Churn_Risk_Score__c) — create matching fields in your CRM, then map the ID column." />
          <div><Button icon={Download} busy={b0} onClick={csv}>Download CSV</Button></div>
        </div>
      </Card>
      <div className="stack">
        <Card title="Email the list" sub={cfg?.email_configured ? 'Sends a summary with the CSV attached' : undefined}>
          {cfg && !cfg.email_configured ? <div className="alert warn">Email isn’t configured on the server. Set <code>SMTP_HOST</code> (and port/user/password) in the backend environment.</div> : (
            <div className="stack">
              <Field label="Recipients" help="Comma-separated"><input value={to} onChange={(e) => setTo(e.target.value)} placeholder="retention@company.com, cs-lead@company.com" /></Field>
              <Field label="Note (optional)"><input value={note} onChange={(e) => setNote(e.target.value)} /></Field>
              <div><Button variant="primary" icon={Mail} busy={b1} disabled={!to.trim()} onClick={mail}>Send email</Button></div>
            </div>
          )}
        </Card>
        <Card title="Push to CRM (webhook)" sub="POSTs JSON batches of 500 to the server-configured endpoint">
          {cfg && !cfg.webhook_configured ? <div className="alert warn">No webhook configured. Set <code>CRM_WEBHOOK_URL</code> (and optionally <code>CRM_WEBHOOK_TOKEN</code>) in the backend environment.</div>
            : <Button variant="primary" icon={Send} busy={b2} onClick={hook}>Push {tier}+ customers</Button>}
        </Card>
      </div>
    </div>
  )
}
