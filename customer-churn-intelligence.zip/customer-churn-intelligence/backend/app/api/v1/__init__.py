from fastapi import APIRouter

from . import analytics, auth, datasets, models, predictions, reports, retention, schedules

api_router = APIRouter()
for m in (auth, datasets, analytics, models, predictions, retention, reports, schedules):
    api_router.include_router(m.router)
