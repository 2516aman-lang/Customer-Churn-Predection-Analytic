"""Data cleaning: type coercion, de-duplication, imputation, outlier capping, target normalisation."""
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

POSITIVE = {"yes", "y", "true", "1", "churn", "churned", "left", "t", "1.0"}
NEGATIVE = {"no", "n", "false", "0", "retained", "stayed", "active", "f", "0.0"}


def normalize_target(series: pd.Series) -> pd.Series:
    """Map common churn labels (Yes/No, True/False, 1/0, Churned/...) to 0/1 ints."""

    def conv(v: Any):
        if pd.isna(v):
            return np.nan
        s = str(v).strip().lower()
        if s in POSITIVE:
            return 1
        if s in NEGATIVE:
            return 0
        return np.nan

    out = series.map(conv)
    if out.isna().all():
        raise ValueError("Target column could not be interpreted as binary churn labels")
    return out


def _coerce_numeric_like(df: pd.DataFrame, report: dict) -> pd.DataFrame:
    """Columns that are mostly numeric but stored as text (e.g. ' ' blanks) become numeric."""
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]) or pd.api.types.is_bool_dtype(df[col]):
            continue
        s = df[col].astype("object").map(lambda v: v.strip() if isinstance(v, str) else v)
        s = s.replace({"": np.nan, "NA": np.nan, "N/A": np.nan, "null": np.nan, "None": np.nan, "nan": np.nan})
        conv = pd.to_numeric(s, errors="coerce")
        non_null = s.notna().sum()
        if non_null and conv.notna().sum() / non_null >= 0.95:
            df[col] = conv
            report["coerced_numeric"].append(col)
        else:
            df[col] = s
    return df


def clean_dataframe(
    df: pd.DataFrame,
    target: str | None = None,
    drop_duplicates: bool = True,
    cap_outliers: bool = True,
    impute: bool = True,
    id_columns: list[str] | None = None,
) -> tuple[pd.DataFrame, dict]:
    report: dict[str, Any] = {
        "rows_before": int(len(df)),
        "coerced_numeric": [],
        "imputed": {},
        "capped_outliers": {},
        "dropped_rows_missing_target": 0,
        "duplicates_removed": 0,
    }
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    df = df.loc[:, ~df.columns.duplicated()]
    df = df.dropna(how="all")
    df = _coerce_numeric_like(df, report)

    if drop_duplicates:
        before = len(df)
        df = df.drop_duplicates()
        if id_columns:
            ids = [c for c in id_columns if c in df.columns]
            if ids:
                df = df.drop_duplicates(subset=ids)
        report["duplicates_removed"] = int(before - len(df))

    if target and target in df.columns:
        df[target] = normalize_target(df[target])
        before = len(df)
        df = df.dropna(subset=[target])
        report["dropped_rows_missing_target"] = int(before - len(df))
        df[target] = df[target].astype(int)

    skip = set(id_columns or []) | ({target} if target else set())
    num_cols = [c for c in df.select_dtypes(include="number").columns if c not in skip]
    cat_cols = [c for c in df.columns if c not in num_cols and c not in skip]

    if cap_outliers:
        for c in num_cols:
            if df[c].nunique() <= 10:  # flags / small ordinal counts
                continue
            q1, q3 = df[c].quantile([0.25, 0.75])
            iqr = q3 - q1
            if iqr == 0:
                continue
            lo, hi = q1 - 3 * iqr, q3 + 3 * iqr
            n = int(((df[c] < lo) | (df[c] > hi)).sum())
            if n:
                df[c] = df[c].clip(lo, hi)
                report["capped_outliers"][c] = n

    if impute:
        for c in num_cols:
            n = int(df[c].isna().sum())
            if n:
                df[c] = df[c].fillna(df[c].median())
                report["imputed"][c] = {"count": n, "strategy": "median"}
        for c in cat_cols:
            n = int(df[c].isna().sum())
            if n:
                mode = df[c].mode(dropna=True)
                df[c] = df[c].fillna(mode.iloc[0] if len(mode) else "Unknown")
                report["imputed"][c] = {"count": n, "strategy": "mode"}

    df = df.reset_index(drop=True)
    report["rows_after"] = int(len(df))
    return df, report
