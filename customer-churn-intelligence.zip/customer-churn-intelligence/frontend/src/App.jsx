import { Navigate, Route, Routes } from 'react-router-dom'
import MainLayout from './components/layout/MainLayout'
import { Loader } from './components/common'
import { useAuth } from './context/AuthContext'
import Automation from './pages/Automation'
import Dashboard from './pages/Dashboard'
import Datasets from './pages/Datasets'
import EDA from './pages/EDA'
import Login from './pages/Login'
import ModelStudio from './pages/ModelStudio'
import Predictions from './pages/Predictions'
import Reports from './pages/Reports'
import Retention from './pages/Retention'

export default function App() {
  const { user, loading } = useAuth()
  if (loading) return <Loader label="Signing in…" />
  if (!user) return <Login />
  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="datasets" element={<Datasets />} />
        <Route path="eda" element={<EDA />} />
        <Route path="models" element={<ModelStudio />} />
        <Route path="predictions" element={<Predictions />} />
        <Route path="retention" element={<Retention />} />
        <Route path="automation" element={<Automation />} />
        <Route path="reports" element={<Reports />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  )
}
