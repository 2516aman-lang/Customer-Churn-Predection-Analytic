"""Synthetic telecom-style churn dataset generator (used for demos, tests and notebooks)."""
from __future__ import annotations

import numpy as np
import pandas as pd


def generate_sample(n: int = 3000, seed: int = 42, dirty: bool = True) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    contract = rng.choice(["Month-to-month", "One year", "Two year"], n, p=[0.55, 0.25, 0.20])
    internet = rng.choice(["DSL", "Fiber optic", "No"], n, p=[0.35, 0.45, 0.20])
    payment = rng.choice(
        ["Electronic check", "Mailed check", "Bank transfer", "Credit card"], n, p=[0.35, 0.2, 0.22, 0.23]
    )
    tenure = np.where(
        contract == "Month-to-month",
        rng.integers(1, 40, n),
        np.where(contract == "One year", rng.integers(6, 60, n), rng.integers(12, 72, n)),
    )
    base = np.where(internet == "Fiber optic", 80, np.where(internet == "DSL", 55, 22))
    monthly = np.round(base + rng.normal(0, 8, n), 2).clip(18, 125)
    senior = rng.choice([0, 1], n, p=[0.84, 0.16])
    partner = rng.choice(["Yes", "No"], n)
    dependents = rng.choice(["Yes", "No"], n, p=[0.3, 0.7])
    tech = np.where(internet == "No", "No internet service", rng.choice(["Yes", "No"], n, p=[0.4, 0.6]))
    security = np.where(internet == "No", "No internet service", rng.choice(["Yes", "No"], n, p=[0.4, 0.6]))
    paperless = rng.choice(["Yes", "No"], n, p=[0.6, 0.4])
    tickets = rng.poisson(np.where(contract == "Month-to-month", 1.6, 0.8))

    logit = (
        -1.2
        + 1.3 * (contract == "Month-to-month")
        - 0.9 * (contract == "Two year")
        + 0.7 * (internet == "Fiber optic")
        + 0.6 * (payment == "Electronic check")
        - 0.04 * tenure
        + 0.012 * (monthly - 60)
        + 0.35 * senior
        - 0.5 * (tech == "Yes")
        - 0.4 * (security == "Yes")
        + 0.25 * tickets
        + 0.2 * (paperless == "Yes")
        - 0.2 * (partner == "Yes")
    )
    p = 1 / (1 + np.exp(-logit))
    churn = np.where(rng.random(n) < p, "Yes", "No")
    total = np.round(tenure * monthly * rng.uniform(0.95, 1.05, n), 2)

    df = pd.DataFrame(
        {
            "customerID": [f"C{100000 + i}" for i in range(n)],
            "gender": rng.choice(["Male", "Female"], n),
            "SeniorCitizen": senior,
            "Partner": partner,
            "Dependents": dependents,
            "tenure": tenure,
            "Contract": contract,
            "InternetService": internet,
            "TechSupport": tech,
            "OnlineSecurity": security,
            "PaperlessBilling": paperless,
            "PaymentMethod": payment,
            "SupportTickets": tickets,
            "MonthlyCharges": monthly,
            "TotalCharges": total,
            "Churn": churn,
        }
    )
    if dirty:  # realistic mess so cleaning/validation has something to do
        idx = rng.choice(n, size=max(5, n // 150), replace=False)
        df["TotalCharges"] = df["TotalCharges"].astype(object)
        df.loc[idx, "TotalCharges"] = " "
        df.loc[rng.choice(n, size=n // 100, replace=False), "MonthlyCharges"] = np.nan
        df = pd.concat([df, df.sample(n // 100, random_state=seed)], ignore_index=True)
    return df


if __name__ == "__main__":
    import sys

    out = sys.argv[1] if len(sys.argv) > 1 else "ml/data/raw/sample_telco_churn.csv"
    generate_sample().to_csv(out, index=False)
    print("wrote", out)
