"""Migrations, CRM/email export, dataset refresh and scheduled re-scoring."""
import io
import smtplib

import httpx
import pytest
from sqlalchemy import inspect

from app.core.config import settings
from app.database.models import Schedule
from app.database.session import SessionLocal, engine
from app.services import scheduler_service as sch

P = "/api/v1"


@pytest.fixture(scope="module")
def ctx(client):
    r = client.post(f"{P}/auth/register", json={"email": "feat@example.com", "password": "secret1"})
    h = {"Authorization": f"Bearer {r.json()['access_token']}"}
    ds = client.post(f"{P}/datasets/sample", json={"rows": 1200}, headers=h).json()
    client.post(f"{P}/datasets/{ds['id']}/clean", json={}, headers=h)
    m = client.post(f"{P}/models/train", headers=h, json={"dataset_id": ds["id"], "algorithms": ["logistic_regression"], "cv_folds": 0}).json()[0]
    run = client.post(f"{P}/predictions/batch/dataset", headers=h, json={"model_id": m["id"], "dataset_id": ds["id"]}).json()
    return {"h": h, "ds": ds["id"], "model": m["id"], "run": run["id"]}


def test_migrations_applied_at_startup(client):
    insp = inspect(engine)
    assert {"users", "schedules", "alembic_version"} <= set(insp.get_table_names())
    with engine.connect() as c:
        assert c.exec_driver_sql("select version_num from alembic_version").scalar() == "0002"


def test_crm_csv_formats(client, ctx):
    r = client.get(f"{P}/retention/{ctx['run']}/export/csv?fmt=salesforce&min_tier=Medium", headers=ctx["h"])
    assert r.status_code == 200 and "text/csv" in r.headers["content-type"]
    head = r.text.splitlines()[0].split(",")
    assert {"External_Id__c", "Churn_Risk_Score__c", "Recommended_Action__c"} <= set(head)
    assert client.get(f"{P}/retention/{ctx['run']}/export/csv?fmt=hubspot", headers=ctx["h"]).text.splitlines()[0].startswith("customer_id")
    # tier filter: Critical-only is a subset of Medium-and-above
    n = lambda t: len(client.get(f"{P}/retention/{ctx['run']}/export/csv?min_tier={t}", headers=ctx["h"]).text.splitlines())
    assert n("Critical") <= n("High") <= n("Medium")
    assert client.get(f"{P}/retention/{ctx['run']}/export/csv?fmt=nope", headers=ctx["h"]).status_code == 400
    assert client.get(f"{P}/retention/{ctx['run']}/export/csv?min_tier=Bad", headers=ctx["h"]).status_code == 400


class FakeSMTP:
    sent = []

    def __init__(self, host, port, timeout=None): pass
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def starttls(self): pass
    def login(self, u, p): pass
    def send_message(self, msg): FakeSMTP.sent.append(msg)


def test_email_export(client, ctx, monkeypatch):
    body = {"to": ["boss@example.com"], "min_tier": "Medium"}
    # not configured → clear 400
    assert client.post(f"{P}/retention/{ctx['run']}/export/email", json=body, headers=ctx["h"]).status_code == 400
    monkeypatch.setattr(settings, "SMTP_HOST", "smtp.test")
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    assert client.get(f"{P}/retention/export/config", headers=ctx["h"]).json()["email_configured"] is True
    r = client.post(f"{P}/retention/{ctx['run']}/export/email", json=body, headers=ctx["h"])
    assert r.status_code == 200 and r.json()["customers"] > 0
    msg = FakeSMTP.sent[-1]
    assert msg["To"] == "boss@example.com" and "at-risk" in msg["Subject"]
    att = list(msg.iter_attachments())[0]
    assert att.get_filename().endswith(".csv") and b"churn_probability" in att.get_content().encode()


def test_webhook_export_batches_and_ssrf(client, ctx, monkeypatch):
    calls = []

    def fake_post(url, json=None, headers=None, **kw):
        import json as _json
        _json.dumps(json, allow_nan=False)  # real receivers reject NaN; payload must be strict JSON
        calls.append((url, json, headers))
        return httpx.Response(200, request=httpx.Request("POST", url))

    monkeypatch.setattr(httpx, "post", fake_post)
    url = "https://crm.example.test/hook"
    r = client.post(f"{P}/retention/{ctx['run']}/export/webhook", json={"url": url, "min_tier": "Low"}, headers=ctx["h"])
    assert r.status_code == 200, r.text
    assert r.json()["delivered"] == sum(len(c[1]["customers"]) for c in calls) and len(calls) == r.json()["batches"] >= 2
    assert calls[0][1]["customers"][0]["customer_id"] and calls[0][1]["source"] == "churn-intelligence"
    # no URL anywhere → 400; private target blocked when guard on
    assert client.post(f"{P}/retention/{ctx['run']}/export/webhook", json={}, headers=ctx["h"]).status_code == 400
    monkeypatch.setattr(settings, "ALLOW_PRIVATE_WEBHOOKS", False)
    r = client.post(f"{P}/retention/{ctx['run']}/export/webhook", json={"url": "http://127.0.0.1:9/x"}, headers=ctx["h"])
    assert r.status_code == 400 and "private" in r.json()["detail"]
    # failing endpoint reports partial delivery
    monkeypatch.setattr(settings, "ALLOW_PRIVATE_WEBHOOKS", True)
    monkeypatch.setattr(httpx, "post", lambda *a, **k: httpx.Response(500, request=httpx.Request("POST", url)))
    assert client.post(f"{P}/retention/{ctx['run']}/export/webhook", json={"url": url}, headers=ctx["h"]).status_code == 400


def test_replace_dataset_data(client, ctx):
    old = client.get(f"{P}/datasets/{ctx['ds']}", headers=ctx["h"]).json()
    csv = client.get(f"{P}/datasets/{ctx['ds']}/download?version=raw", headers=ctx["h"]).content.decode().splitlines()
    new = "\n".join(csv[: 401])  # header + 400 rows
    r = client.put(f"{P}/datasets/{ctx['ds']}/data", files={"file": ("new.csv", io.BytesIO(new.encode()))}, headers=ctx["h"])
    assert r.status_code == 200 and r.json()["status"] == "cleaned" and r.json()["rows"] <= 400 < old["rows"]
    bad = "a,b\n1,2\n"
    r = client.put(f"{P}/datasets/{ctx['ds']}/data", files={"file": ("bad.csv", io.BytesIO(bad.encode()))}, headers=ctx["h"])
    assert r.status_code == 400 and "missing columns" in r.json()["detail"]


def test_schedule_lifecycle_and_drift(client, ctx, monkeypatch):
    h = ctx["h"]
    # notifications require server config
    r = client.post(f"{P}/schedules", headers=h, json={"name": "x", "dataset_id": ctx["ds"], "email_to": "a@b.co"})
    assert r.status_code == 400
    monkeypatch.setattr(settings, "SMTP_HOST", "smtp.test")
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    FakeSMTP.sent.clear()
    r = client.post(f"{P}/schedules", headers=h, json={"name": "Nightly", "dataset_id": ctx["ds"], "frequency": "daily",
                                                      "email_to": "ops@example.com", "min_tier": "Medium"})
    assert r.status_code == 201, r.text
    s = r.json()
    assert s["next_run_at"] and s["model_id"] is None  # follows the active model
    a = client.post(f"{P}/schedules/{s['id']}/run", headers=h).json()
    assert a["last_status"] == "ok" and a["last_run_id"] and "emailed" in a["last_message"], a
    b = client.post(f"{P}/schedules/{s['id']}/run", headers=h).json()
    assert b["last_run_id"] != a["last_run_id"]
    run = client.get(f"{P}/predictions/runs/{b['last_run_id']}", headers=h).json()["run"]
    cmp_ = run["summary"]["comparison"]
    assert cmp_["previous_run_id"] == a["last_run_id"] and cmp_["avg_probability_delta"] == 0
    assert cmp_["newly_critical"] == 0
    assert len(FakeSMTP.sent) == 2
    # pause / change frequency
    p = client.patch(f"{P}/schedules/{s['id']}", json={"enabled": False, "frequency": "weekly"}, headers=h).json()
    assert p["enabled"] is False and p["frequency"] == "weekly"
    assert any(x["id"] == s["id"] for x in client.get(f"{P}/schedules", headers=h).json())
    ctx["schedule"] = s["id"]


def test_tick_runs_only_due_enabled_and_claims_once(client, ctx):
    from datetime import datetime, timedelta, timezone

    h = ctx["h"]
    s = client.post(f"{P}/schedules", headers=h, json={"name": "Due", "dataset_id": ctx["ds"], "frequency": "hourly"}).json()
    with SessionLocal() as db:
        db.get(Schedule, s["id"]).next_run_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        db.commit()
    assert sch.tick() == 1          # ran
    assert sch.tick() == 0          # next_run_at advanced → not due again
    got = [x for x in client.get(f"{P}/schedules", headers=h).json() if x["id"] == s["id"]][0]
    assert got["last_status"] == "ok" and got["last_run_id"]
    # disabled schedules never run
    client.patch(f"{P}/schedules/{s['id']}", json={"enabled": False}, headers=h)
    with SessionLocal() as db:
        db.get(Schedule, s["id"]).next_run_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        db.commit()
    assert sch.tick() == 0


def test_schedule_failure_is_recorded_not_raised(client, ctx):
    h = ctx["h"]
    s = client.post(f"{P}/schedules", headers=h, json={"name": "Orphan", "dataset_id": ctx["ds"]}).json()
    # point at a missing model by clearing every active model for this user
    models = client.get(f"{P}/models", headers=h).json()
    with SessionLocal() as db:
        from app.database.models import MLModel
        db.query(MLModel).filter(MLModel.id.in_([m["id"] for m in models])).update({MLModel.is_active: False}, synchronize_session=False)
        db.commit()
    out = client.post(f"{P}/schedules/{s['id']}/run", headers=h).json()
    assert out["last_status"] == "failed" and "active model" in out["last_message"]


def test_schedule_isolation(client, ctx):
    r = client.post(f"{P}/auth/register", json={"email": "nosy@example.com", "password": "secret1"})
    h2 = {"Authorization": f"Bearer {r.json()['access_token']}"}
    assert client.post(f"{P}/schedules/{ctx['schedule']}/run", headers=h2).status_code == 404
    assert client.delete(f"{P}/schedules/{ctx['schedule']}", headers=h2).status_code == 404
    assert client.get(f"{P}/retention/{ctx['run']}/export/csv", headers=h2).status_code == 404
    assert client.delete(f"{P}/schedules/{ctx['schedule']}", headers=ctx["h"]).status_code == 204
