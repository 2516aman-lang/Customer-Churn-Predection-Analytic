import { useState } from 'react'
import { LineChart } from 'lucide-react'
import { Button, Card, ErrorBox, Field } from '../components/common'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { login, register } = useAuth()
  const [mode, setMode] = useState('login')
  const [f, setF] = useState({ name: '', email: '', password: '' })
  const [err, setErr] = useState(null)
  const [busy, setBusy] = useState(false)
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true); setErr(null)
    try { await (mode === 'login' ? login(f) : register(f)) } catch (x) { setErr(x.friendly || x.message) } finally { setBusy(false) }
  }
  return (
    <div className="auth-wrap">
      <div className="auth-card stack">
        <div className="row" style={{ justifyContent: 'center', gap: 12 }}>
          <span className="brand-mark" style={{ background: 'linear-gradient(135deg,#6366f1,#ec4899)', width: 38, height: 38, borderRadius: 11, display: 'grid', placeItems: 'center' }}><LineChart color="#fff" size={20} /></span>
          <h2>Churn Intelligence</h2>
        </div>
        <Card title={mode === 'login' ? 'Sign in' : 'Create your account'}>
          <form className="stack" onSubmit={submit}>
            {mode === 'register' && <Field label="Name"><input value={f.name} onChange={set('name')} placeholder="Ada Lovelace" /></Field>}
            <Field label="Email"><input type="email" required value={f.email} onChange={set('email')} autoFocus /></Field>
            <Field label="Password" help={mode === 'register' ? 'At least 6 characters' : null}><input type="password" required minLength={6} value={f.password} onChange={set('password')} /></Field>
            <ErrorBox error={err} />
            <Button variant="primary" busy={busy} type="submit">{mode === 'login' ? 'Sign in' : 'Create account'}</Button>
            <button type="button" className="btn ghost" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setErr(null) }}>
              {mode === 'login' ? 'New here? Create an account' : 'Have an account? Sign in'}
            </button>
          </form>
        </Card>
      </div>
    </div>
  )
}
