# Customer Churn Intelligence

End-to-end churn platform: **upload data → validate & clean → explore → train & compare models → score customers (with explanations) → plan retention & ROI → export reports.**

| Layer | Stack |
|---|---|
| Frontend | React 18, Vite, React Router, Recharts, Axios |
| Backend | FastAPI, SQLAlchemy 2 + Alembic migrations (SQLite locally, Postgres in Docker), JWT auth, background training worker, scheduler |
| ML | pandas, scikit-learn pipelines, permutation-importance explainability, reportlab PDFs |

## Features

**Data**
- CSV / Excel upload (50 MB cap), auto-detected target column & ID columns
- Data-quality score with issues (duplicates, missing, constants, imbalance, too few rows)
- Cleaning: numeric-text coercion (e.g. blank `TotalCharges`), de-duplication, median/mode imputation, 3×IQR outlier capping, target normalised to 0/1 (`Yes/No/True/False/Churned…`)
- Raw vs. cleaned preview, CSV download, built-in synthetic sample dataset

**Exploration** — churn split, histograms stacked by outcome, churn rate by every category, correlation heat-map, correlation with churn, free-form segment explorer

**Model Studio** — Logistic Regression, Decision Tree, Random Forest, Gradient Boosting, Hist-Gradient Boosting; editable hyper-parameters; stratified split + CV; class-imbalance handling; max-F1 threshold; ROC / PR curves, confusion matrix, threshold trade-off, lift & cumulative-capture by decile, permutation importance; side-by-side comparison; activate a model for scoring

**Predictions** — single-customer scoring with top drivers, **what-if scenarios** (e.g. switch contract → Δ risk), batch scoring of a stored dataset or an uploaded file (missing columns tolerated), risk tiers (Critical/High/Medium/Low), CSV export

**Retention** — expected loss (probability × customer value), at-risk customer ranking, driver-based **next-best-action playbook** with owners, and a **campaign ROI simulator** (budget, contact cost, offer cost, save rate)

**Export & CRM** — download at-risk lists as CSV with Generic / Salesforce / HubSpot column naming, email them (SMTP, CSV attached), or push JSON batches to a CRM webhook (bearer token, SSRF-guarded)

**Automation** — schedules (hourly / daily / weekly) re-score a dataset with a chosen or the active model, store a new scoring run, report drift vs. the previous run (avg-risk change, newly critical customers) and optionally email / push the at-risk list. *Replace data with a newer file* on the Datasets page feeds fresh extracts into scheduled runs.

**Reports** — executive summary PDF, model-performance PDF, at-risk customers (CSV or PDF)

**Platform** — user accounts (PBKDF2 + JWT), per-user data isolation, Docker Compose, tests

## Quick start

```bash
# 1. backend (Python 3.11+)
pip install -r backend/requirements.txt
cd backend && uvicorn app.main:app --reload --port 8000     # docs: http://localhost:8000/docs

# 2. frontend (Node 18+)
cd frontend && npm install && npm run dev                   # http://localhost:5173
```

Register an account, click **Load sample data**, then follow the dashboard pipeline: *Clean → Explore → Train → Predict → Retention → Reports*.

Docker (includes Postgres 16): `cp .env.example .env && docker compose up --build` → UI on http://localhost:8080, API on :8000.

### Database & migrations
Schema is managed by Alembic (`backend/alembic/versions`). On startup the API runs `alembic upgrade head` (`AUTO_MIGRATE=true`); databases created by older versions are adopted automatically. Locally the default is SQLite; for Postgres set `DATABASE_URL=postgresql+psycopg://user:pass@host:5432/churn`.
```bash
make migrate                       # apply migrations manually
make migration m="add column"      # autogenerate a new revision after editing app/database/models.py
```

### Email, CRM and scheduler configuration
Set in `.env` (see `.env.example`): `SMTP_HOST/PORT/USER/PASSWORD/FROM`, `CRM_WEBHOOK_URL` (+ `CRM_WEBHOOK_TOKEN`), `ENABLE_SCHEDULER`. The UI shows which channels are configured. The scheduler is a background thread inside the API process; job claims are atomic, so running several API workers will not double-run a schedule. Webhook payload: `{"source","run_id","batch","customers":[{customer_id, churn_probability, risk_tier, monthly_value, expected_loss, primary_driver, recommended_action, action_owner}]}`. Webhook targets that resolve to private/loopback addresses are refused unless `ALLOW_PRIVATE_WEBHOOKS=true`.

Tests: `cd backend && python -m pytest -q` (API end-to-end flow + ML unit tests).

## Layout

```
frontend/src   api/ (axios client per domain) · pages/ · components/{layout,charts,tables,common} · context/ · hooks/ · styles/
backend/app    main.py · core/{config,security} · api/v1/* · schemas/ · database/ · services/ (incl. export, scheduler) · workers/
backend/alembic  migrations (0001 initial, 0002 schedules)
ml/src         cleaning · validation · features · training · evaluation · inference · explainability · sample_data
ml/            data/{raw,processed} · notebooks/ · artifacts/ (trained .joblib + .json)
reports/       generated PDFs / CSVs
```

The backend imports `ml/src` as the `src` package (`ML_DIR` setting), so the same code runs in notebooks, tests and the API.

## How it works

- **Pipelines**: every model is a single sklearn `Pipeline` (feature engineering → impute/scale/one-hot → estimator), so scoring new data needs no manual preprocessing. Derived features (`expected_total`, `avg_monthly_spend`, `tenure_bucket`) are added automatically when `tenure` / `MonthlyCharges` / `TotalCharges` exist.
- **Explainability** is model-agnostic: global = permutation importance on held-out data (ΔROC-AUC); local = change in probability when a feature is replaced by its baseline value.
- **Retention economics**: `expected_loss = P(churn) × monthly_value × horizon`. Monthly value comes from a detected revenue column (e.g. `MonthlyCharges`), otherwise a configurable fallback. The simulator targets customers in descending *net* expected value (`P × save_rate × value − contact cost − save_rate × offer cost`) until the budget is spent.
- **Training** runs in a thread pool (`TRAIN_WORKERS`); the UI polls model status. Swap `workers/trainer.py` for Celery/RQ at scale.

## API (all under `/api/v1`, Bearer token except `/auth/*`)

`auth` register · login · me — `datasets` upload · sample · list · patch · preview · validate · clean · download · delete — `analytics` dashboard · datasets/{id}/eda · segments — `models` algorithms · train · list · compare · detail · activate · delete — `predictions` schema · single · whatif · batch · batch/dataset · runs (list/detail/download/delete) — `retention` {run}/overview · customers · recommendations · simulate · export/csv · export/email · export/webhook · export/config — `schedules` list · create · patch · run · delete — `datasets` also `PUT {id}/data` (replace rows) — `reports` create · list · download · delete

Interactive docs at `/docs`.

## Production notes

Set a strong `SECRET_KEY`; use Postgres via `DATABASE_URL` (the Docker setup already does); serve behind HTTPS; model artifacts are joblib pickles — only load artifacts this app produced.
