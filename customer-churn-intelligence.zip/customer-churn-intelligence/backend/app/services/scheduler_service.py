"""Recurring re-scoring. A single daemon thread polls for due schedules; claims are atomic so several API
workers can run the loop safely without double-executing a job."""
from __future__ import annotations

import logging
import threading
from datetime import datetime, timedelta, timezone

from sqlalchemy import update
from sqlalchemy.orm import Session

from ..core.config import settings
from ..database.models import Dataset, MLModel, ScoringRun, Schedule, User
from ..database.session import SessionLocal
from . import dataset_service, export_service, prediction_service

log = logging.getLogger("scheduler")
STEP = {"hourly": timedelta(hours=1), "daily": timedelta(days=1), "weekly": timedelta(days=7)}
_stop = threading.Event()
_thread: threading.Thread | None = None


def _now():
    return datetime.now(timezone.utc)


def _aware(d):
    return d if d is None or d.tzinfo else d.replace(tzinfo=timezone.utc)


def next_after(freq: str, base: datetime | None = None) -> datetime:
    return (base or _now()) + STEP[freq]


def compare_runs(prev: ScoringRun | None, cur: ScoringRun) -> dict | None:
    """What changed since the last scheduled run (drift in risk, new critical customers)."""
    if not prev or not prev.summary or not cur.summary:
        return None
    out = {"previous_run_id": prev.id,
           "avg_probability_delta": round(cur.summary["avg_probability"] - prev.summary["avg_probability"], 4),
           "predicted_churners_delta": cur.summary["predicted_churners"] - prev.summary["predicted_churners"],
           "critical_delta": cur.summary["tiers"]["Critical"] - prev.summary["tiers"]["Critical"]}
    idc = cur.summary.get("id_column")
    try:
        a, b = prediction_service.load_run(prev), prediction_service.load_run(cur)
        if idc and idc in a.columns and idc in b.columns:
            was = set(a.loc[a["risk_tier"] == "Critical", idc].astype(str))
            now = set(b.loc[b["risk_tier"] == "Critical", idc].astype(str))
            out["newly_critical"] = len(now - was)
            out["no_longer_critical"] = len(was - now)
    except Exception:  # noqa: BLE001
        pass
    return out


def run_schedule(db: Session, s: Schedule) -> ScoringRun:
    """Execute one schedule now. Raises on failure (callers record the status)."""
    user = db.get(User, s.owner_id)
    ds = db.get(Dataset, s.dataset_id)
    model = db.get(MLModel, s.model_id) if s.model_id else (
        db.query(MLModel).filter(MLModel.owner_id == s.owner_id, MLModel.is_active.is_(True)).first())
    if not ds or not model:
        raise ValueError("Schedule's dataset or model no longer exists (and no active model is set)")
    prev = db.get(ScoringRun, s.last_run_id) if s.last_run_id else None
    run = prediction_service.run_batch(db, user, model, dataset_service.load_df(ds),
                                       f"{s.name} · {_now():%Y-%m-%d %H:%M}", ds)
    cmp_ = compare_runs(prev, run)
    if cmp_:
        run.summary = {**run.summary, "comparison": cmp_}
        db.commit()
    s.last_run_id = run.id
    notes = [f"scored {run.rows} customers"]
    if s.email_to or s.push_webhook:
        df = export_service.at_risk_frame(run, s.min_tier)
        if s.email_to:
            body = export_service.summary_text(run, df, s.min_tier)
            if cmp_:
                body += (f"\n\nSince last run: avg risk {cmp_['avg_probability_delta']:+.1%}, "
                         f"{cmp_.get('newly_critical', '?')} newly critical customers.")
            export_service.send_email(s.email_to.split(","), f"[Churn] {s.name}: {len(df)} at-risk customers", body,
                                      export_service.csv_bytes(export_service.to_crm(df)))
            notes.append(f"emailed {len(df)} customers")
        if s.push_webhook:
            r = export_service.push_webhook(run, df)
            notes.append(f"pushed {r['delivered']} to CRM")
    s.last_message = "; ".join(notes)
    return run


def execute(schedule_id: int) -> None:
    """Run a schedule in its own session and record the outcome (never raises)."""
    db = SessionLocal()
    try:
        s = db.get(Schedule, schedule_id)
        try:
            run_schedule(db, s)
            s.last_status = "ok"
        except Exception as e:  # noqa: BLE001
            db.rollback()
            s = db.get(Schedule, schedule_id)
            s.last_status, s.last_message = "failed", str(e)[:500]
            log.warning("schedule %s failed: %s", schedule_id, e)
        s.last_run_at = _now()
        db.commit()
    finally:
        db.close()


def tick() -> int:
    """Run every due schedule once. Returns how many were executed."""
    db = SessionLocal()
    ran = 0
    try:
        due = db.query(Schedule).filter(Schedule.enabled.is_(True), Schedule.next_run_at <= _now()).all()
        for s in due:
            old = s.next_run_at
            claimed = db.execute(update(Schedule).where(Schedule.id == s.id, Schedule.next_run_at == old)
                                 .values(next_run_at=next_after(s.frequency))).rowcount
            db.commit()
            if claimed:  # another worker may have claimed it first
                execute(s.id)
                ran += 1
    finally:
        db.close()
    return ran


def _loop():
    while not _stop.wait(settings.SCHEDULER_INTERVAL_SECONDS):
        try:
            tick()
        except Exception:  # noqa: BLE001
            log.exception("scheduler tick failed")


def start():
    global _thread
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(target=_loop, name="scheduler", daemon=True)
    _thread.start()


def stop():
    _stop.set()
