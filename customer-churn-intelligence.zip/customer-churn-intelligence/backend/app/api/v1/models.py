from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ...database.models import MLModel, ScoringRun, User
from ...database.session import get_db
from ...schemas import ModelOut, TrainIn
from ...services import model_service as svc
from ..deps import current_user, get_dataset, get_model

from src.training import list_algorithms

router = APIRouter(prefix="/models", tags=["models"])


@router.get("/algorithms")
def algorithms(_: User = Depends(current_user)):
    return list_algorithms()


@router.get("", response_model=list[ModelOut])
def list_models(dataset_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = db.query(MLModel).filter(MLModel.owner_id == user.id)
    if dataset_id:
        q = q.filter(MLModel.dataset_id == dataset_id)
    return q.order_by(MLModel.id.desc()).all()


@router.post("/train", response_model=list[ModelOut], status_code=202)
def train(body: TrainIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    ds = get_dataset(db, body.dataset_id, user)
    try:
        return svc.start_training(db, user, ds, body.algorithms, body.name, body.params, body.test_size,
                                  body.cv_folds, body.exclude_columns)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/compare")
def compare(ids: str = Query(..., description="comma-separated model ids"), db: Session = Depends(get_db),
            user: User = Depends(current_user)):
    out = []
    for i in [int(x) for x in ids.split(",") if x.strip().isdigit()]:
        m = get_model(db, i, user)
        if m.status == "completed":
            out.append({"id": m.id, "name": m.name, "algorithm": m.algorithm, "metrics": m.metrics,
                        "roc_curve": m.result["roc_curve"], "pr_curve": m.result["pr_curve"],
                        "train_seconds": m.result["meta"]["train_seconds"]})
    return out


@router.get("/{model_id}")
def detail(model_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    m = get_model(db, model_id, user)
    return {**ModelOut.model_validate(m).model_dump(), "result": m.result}


@router.post("/{model_id}/activate", response_model=ModelOut)
def activate(model_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    try:
        return svc.activate(db, user, get_model(db, model_id, user))
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.delete("/{model_id}", status_code=204)
def delete(model_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    m = get_model(db, model_id, user)
    if db.query(ScoringRun).filter(ScoringRun.model_id == m.id).first():
        raise HTTPException(409, "Delete this model's scoring runs first")
    svc.delete(db, m)
