from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ...database.models import Report, User
from ...database.session import get_db
from ...schemas import ReportIn, ReportOut
from ...services import report_service
from ..deps import current_user, get_dataset, get_model, get_run

router = APIRouter(prefix="/reports", tags=["reports"])


@router.get("", response_model=list[ReportOut])
def list_reports(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return db.query(Report).filter(Report.owner_id == user.id).order_by(Report.id.desc()).all()


@router.post("", response_model=ReportOut, status_code=201)
def create(body: ReportIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    ds = get_dataset(db, body.dataset_id, user) if body.dataset_id else None
    model = get_model(db, body.model_id, user) if body.model_id else None
    run = get_run(db, body.run_id, user) if body.run_id else None
    if run and not ds and run.dataset_id:
        ds = get_dataset(db, run.dataset_id, user)
    rep = Report(owner_id=user.id, title="pending", kind=body.kind, fmt=body.fmt, path="",
                 params=body.model_dump(exclude={"title"}))
    db.add(rep)
    db.flush()
    try:
        rep.title, rep.path = report_service.build(db, user, body.kind, body.fmt, body.title, ds, model, run, rep.id)
    except ValueError as e:
        db.rollback()
        raise HTTPException(400, str(e))
    db.commit()
    return rep


def _get(db, id_, user) -> Report:
    r = db.get(Report, id_)
    if not r or r.owner_id != user.id:
        raise HTTPException(404, "Report not found")
    return r


@router.get("/{report_id}/download")
def download(report_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = _get(db, report_id, user)
    mt = "application/pdf" if r.fmt == "pdf" else "text/csv"
    return FileResponse(r.path, media_type=mt, filename=f"{r.title}.{r.fmt}")


@router.delete("/{report_id}", status_code=204)
def delete(report_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    r = _get(db, report_id, user)
    Path(r.path).unlink(missing_ok=True)
    db.delete(r)
    db.commit()
