"""Model evaluation: metrics, curves, confusion matrix, threshold + lift analysis."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, average_precision_score, confusion_matrix, f1_score, precision_recall_curve,
    precision_score, recall_score, roc_auc_score, roc_curve, brier_score_loss,
)


def _thin(a, k=100):
    a = list(a)
    if len(a) <= k:
        return [round(float(x), 4) for x in a]
    idx = np.linspace(0, len(a) - 1, k).astype(int)
    return [round(float(a[i]), 4) for i in idx]


def best_threshold(y_true, proba) -> float:
    thr = np.linspace(0.05, 0.95, 91)
    f1s = [f1_score(y_true, proba >= t, zero_division=0) for t in thr]
    return float(thr[int(np.argmax(f1s))])


def threshold_table(y_true, proba, points: int = 19) -> list[dict]:
    rows = []
    for t in np.linspace(0.05, 0.95, points):
        pred = proba >= t
        rows.append({
            "threshold": round(float(t), 2),
            "precision": round(float(precision_score(y_true, pred, zero_division=0)), 4),
            "recall": round(float(recall_score(y_true, pred, zero_division=0)), 4),
            "f1": round(float(f1_score(y_true, pred, zero_division=0)), 4),
            "flagged_pct": round(float(pred.mean()), 4),
        })
    return rows


def lift_table(y_true, proba, bins: int = 10) -> list[dict]:
    df = pd.DataFrame({"y": np.asarray(y_true), "p": np.asarray(proba)}).sort_values("p", ascending=False)
    df = df.reset_index(drop=True)
    parts = [df.iloc[idx] for idx in np.array_split(np.arange(len(df)), bins)]
    base = df["y"].mean() or 1e-9
    total_pos = max(df["y"].sum(), 1)
    cum = 0
    out = []
    for i, part in enumerate(parts, 1):
        pos = part["y"].sum()
        cum += pos
        out.append({
            "decile": i,
            "customers": int(len(part)),
            "churn_rate": round(float(part["y"].mean()), 4),
            "lift": round(float(part["y"].mean() / base), 3),
            "cum_capture": round(float(cum / total_pos), 4),
        })
    return out


def evaluate(y_true, proba, threshold: float | None = None) -> dict:
    y_true = np.asarray(y_true)
    proba = np.asarray(proba)
    thr = best_threshold(y_true, proba) if threshold is None else threshold
    pred = (proba >= thr).astype(int)
    fpr, tpr, _ = roc_curve(y_true, proba)
    pr, rc, _ = precision_recall_curve(y_true, proba)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    return {
        "threshold": round(thr, 3),
        "metrics": {
            "roc_auc": round(float(roc_auc_score(y_true, proba)), 4),
            "pr_auc": round(float(average_precision_score(y_true, proba)), 4),
            "accuracy": round(float(accuracy_score(y_true, pred)), 4),
            "precision": round(float(precision_score(y_true, pred, zero_division=0)), 4),
            "recall": round(float(recall_score(y_true, pred, zero_division=0)), 4),
            "f1": round(float(f1_score(y_true, pred, zero_division=0)), 4),
            "brier": round(float(brier_score_loss(y_true, proba)), 4),
        },
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
        "roc_curve": {"fpr": _thin(fpr), "tpr": _thin(tpr)},
        "pr_curve": {"precision": _thin(pr), "recall": _thin(rc)},
        "threshold_table": threshold_table(y_true, proba),
        "lift_table": lift_table(y_true, proba),
    }
