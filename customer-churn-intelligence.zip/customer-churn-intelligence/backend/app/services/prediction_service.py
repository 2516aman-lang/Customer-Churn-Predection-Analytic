from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
from sqlalchemy.orm import Session

from ..core.config import settings
from ..database.models import Dataset, MLModel, ScoringRun, User
from .common import find_revenue_col

from src.inference import load_artifact, predict_frame


def _artifact(m: MLModel) -> str:
    if m.status != "completed" or not m.artifact_path:
        raise ValueError("Model is not ready (status: %s)" % m.status)
    return m.artifact_path


def schema(m: MLModel) -> dict:
    meta = load_artifact(_artifact(m))["meta"]
    return {k: meta[k] for k in ("features", "feature_types", "feature_options", "feature_ranges", "baselines", "threshold", "target")}


def run_batch(db: Session, user: User, m: MLModel, df: pd.DataFrame, name: str, ds: Dataset | None = None) -> ScoringRun:
    preds = predict_frame(_artifact(m), df, explain=True)
    out = df.reset_index(drop=True).copy()
    preds = preds.reset_index(drop=True)
    out["churn_probability"] = preds["churn_probability"]
    out["predicted_churn"] = preds["predicted_churn"]
    out["risk_tier"] = preds["risk_tier"]
    out["top_drivers"] = preds["top_drivers"].map(json.dumps)

    rev = find_revenue_col(out)
    id_col = None
    if ds and ds.id_columns:
        id_col = next((c for c in ds.id_columns if c in out.columns), None)
    tiers = out["risk_tier"].value_counts().reindex(["Critical", "High", "Medium", "Low"], fill_value=0)
    summary = {
        "rows": int(len(out)),
        "predicted_churners": int(out["predicted_churn"].sum()),
        "avg_probability": round(float(out["churn_probability"].mean()), 4),
        "tiers": {k: int(v) for k, v in tiers.items()},
        "id_column": id_col,
        "revenue_column": rev,
        "histogram": [int(x) for x in pd.cut(out["churn_probability"], bins=[i / 10 for i in range(11)],
                                              include_lowest=True).value_counts(sort=False)],
    }
    if rev:
        summary["expected_monthly_revenue_at_risk"] = round(float((out["churn_probability"] * out[rev]).sum()), 2)

    run = ScoringRun(owner_id=user.id, model_id=m.id, dataset_id=ds.id if ds else None, name=name, rows=len(out),
                     summary=summary, results_path="")
    db.add(run)
    db.flush()
    path = settings.processed_dir / "runs" / f"run_{run.id}.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(path, index=False)
    run.results_path = str(path)
    db.commit()
    db.refresh(run)
    return run


def load_run(run: ScoringRun) -> pd.DataFrame:
    df = pd.read_csv(run.results_path)
    df["top_drivers"] = df["top_drivers"].map(lambda s: json.loads(s) if isinstance(s, str) else [])
    return df


def delete_run(db: Session, run: ScoringRun):
    Path(run.results_path).unlink(missing_ok=True)
    db.delete(run)
    db.commit()
