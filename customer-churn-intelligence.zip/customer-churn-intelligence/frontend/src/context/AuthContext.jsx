import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import * as authApi from '../api/auth'
import { TOKEN_KEY } from '../api/client'

const Ctx = createContext(null)
export const useAuth = () => useContext(Ctx)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(!!localStorage.getItem(TOKEN_KEY))

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY)
    setUser(null)
  }, [])

  useEffect(() => {
    if (localStorage.getItem(TOKEN_KEY)) authApi.me().then(setUser).catch(logout).finally(() => setLoading(false))
    window.addEventListener('auth:logout', logout)
    return () => window.removeEventListener('auth:logout', logout)
  }, [logout])

  const finish = (res) => {
    localStorage.setItem(TOKEN_KEY, res.access_token)
    setUser(res.user)
  }
  const login = async (b) => finish(await authApi.login(b))
  const register = async (b) => finish(await authApi.register(b))

  return <Ctx.Provider value={{ user, loading, login, register, logout }}>{children}</Ctx.Provider>
}
