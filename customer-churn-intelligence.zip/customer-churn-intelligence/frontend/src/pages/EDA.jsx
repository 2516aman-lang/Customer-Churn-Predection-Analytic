import { useState } from 'react'
import { getEda, getSegments } from '../api/datasets'
import { Card, EmptyState, ErrorBox, Loader, PageHeader, Select, StatCard, Tabs, fmt } from '../components/common'
import { Donut, Heatmap, Histogram, HBar, RateBars } from '../components/charts'
import { useApp } from '../context/AppContext'
import { useAsync } from '../hooks/useAsync'

export default function EDA() {
  const { dataset } = useApp()
  const [tab, setTab] = useState('overview')
  const { data, loading, error } = useAsync(() => getEda(dataset.id), [dataset?.id, dataset?.status], { enabled: !!dataset?.target })
  if (!dataset) return <EmptyState title="No dataset" text="Add a dataset first." />
  if (!dataset.target) return <EmptyState title="Set a target column" text="Pick the churn column on the Datasets page to unlock exploration." />
  return (
    <>
      <PageHeader title="Exploration" subtitle={`Understanding churn in ${dataset.name}${dataset.status !== 'cleaned' ? ' (raw data — clean it for best results)' : ''}`} />
      <ErrorBox error={error} />
      {loading && !data ? <Loader /> : data && (
        <>
          <Tabs value={tab} onChange={setTab} tabs={[{ key: 'overview', label: 'Overview' }, { key: 'numeric', label: 'Numeric features' }, { key: 'categorical', label: 'Categorical features' }, { key: 'correlation', label: 'Correlations' }, { key: 'segments', label: 'Segment explorer' }]} />
          {tab === 'overview' && <Overview d={data} />}
          {tab === 'numeric' && <Numeric d={data} />}
          {tab === 'categorical' && <Categorical d={data} />}
          {tab === 'correlation' && <Correlation d={data} />}
          {tab === 'segments' && <Segments d={data} ds={dataset} />}
        </>
      )}
    </>
  )
}

function Overview({ d }) {
  const o = d.overview
  return (
    <div className="stack">
      <div className="grid g4">
        <StatCard label="Customers" value={fmt.num(o.rows)} />
        <StatCard label="Churn rate" value={fmt.pct(o.churn_rate)} tone="bad" />
        <StatCard label="Avg monthly revenue" value={o.avg_monthly_revenue != null ? fmt.money(o.avg_monthly_revenue) : '—'} />
        <StatCard label="Monthly revenue lost" value={o.monthly_revenue_churned != null ? fmt.money(o.monthly_revenue_churned) : '—'} tone="bad" hint={o.monthly_revenue_total ? `${fmt.pct(o.monthly_revenue_churned / o.monthly_revenue_total)} of total` : undefined} />
      </div>
      <div className="grid g2">
        <Card title="Churn split"><Donut data={[{ name: 'Retained', value: o.retained }, { name: 'Churned', value: o.churned }]} colors={{ Retained: '#4f46e5', Churned: '#e11d48' }} /></Card>
        <Card title="Strongest numeric correlations with churn">
          {d.target_correlation.length ? <HBar data={d.target_correlation.slice(0, 8)} labelKey="feature" valueKey="correlation" color="#e11d48" format={(v) => v.toFixed(2)} h={230} /> : <div className="muted">No numeric features.</div>}
        </Card>
      </div>
      {d.missing.length > 0 && <Card title="Missing values"><HBar data={d.missing} labelKey="column" valueKey="pct" format={(v) => `${v}%`} h={Math.max(120, d.missing.length * 34)} /></Card>}
    </div>
  )
}

function Numeric({ d }) {
  const [col, setCol] = useState(d.numeric[0]?.column)
  const f = d.numeric.find((n) => n.column === col)
  if (!f) return <EmptyState title="No numeric features" text="" />
  return (
    <div className="stack">
      <div style={{ maxWidth: 280 }}><Select label="Feature" value={col} onChange={setCol} options={d.numeric.map((n) => n.column)} /></div>
      <div className="grid g-wide">
        <Card title={`${col} distribution`} sub="Stacked by outcome"><Histogram bins={f.bins} /></Card>
        <Card title="Statistics">
          <dl className="kv">
            <dt>Mean</dt><dd>{f.mean}</dd><dt>Median</dt><dd>{f.median}</dd><dt>Std dev</dt><dd>{f.std}</dd><dt>Min / Max</dt><dd>{f.min} / {f.max}</dd>
            <dt>Mean (churned)</dt><dd className="pos">{f.mean_churned}</dd><dt>Mean (retained)</dt><dd>{f.mean_retained}</dd>
          </dl>
        </Card>
      </div>
      <Card title={`Churn rate by ${col} range`}><RateBars data={f.bins} labelKey="label" h={220} /></Card>
    </div>
  )
}

function Categorical({ d }) {
  if (!d.categorical.length) return <EmptyState title="No categorical features" text="" />
  return (
    <div className="grid g3">
      {d.categorical.map((c) => (
        <Card key={c.column} title={c.column} sub={`Spread: ${fmt.pct(c.spread)} between best and worst group`}>
          <RateBars data={c.values} h={200} avg={d.overview.churn_rate} />
        </Card>
      ))}
    </div>
  )
}

function Correlation({ d }) {
  if (!d.correlation) return <EmptyState title="Not enough numeric columns" text="" />
  return <Card title="Correlation matrix" sub="Pearson correlation between numeric features and the churn flag"><Heatmap {...d.correlation} /></Card>
}

function Segments({ d, ds }) {
  const cols = [...d.categorical.map((c) => c.column), ...d.numeric.map((n) => n.column)]
  const [by, setBy] = useState(cols[0])
  const { data, loading } = useAsync(() => getSegments(ds.id, by), [ds.id, by], { enabled: !!by })
  return (
    <div className="stack">
      <div style={{ maxWidth: 280 }}><Select label="Segment by" value={by} onChange={setBy} options={cols} /></div>
      <Card title={`Churn rate by ${by}`} sub="Numeric columns are grouped into quintiles">
        {loading ? <Loader /> : data && <><RateBars data={data} labelKey="segment" h={260} avg={d.overview.churn_rate} />
          <div className="table-wrap" style={{ marginTop: 12 }}><table><thead><tr><th>Segment</th><th>Customers</th><th>Churn rate</th></tr></thead><tbody>{data.map((r) => <tr key={r.segment}><td>{r.segment}</td><td>{fmt.num(r.customers)}</td><td>{fmt.pct(r.churn_rate)}</td></tr>)}</tbody></table></div></>}
      </Card>
    </div>
  )
}
