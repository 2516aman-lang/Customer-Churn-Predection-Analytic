from __future__ import annotations

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from ..core.security import decode_token
from ..database.models import Dataset, MLModel, ScoringRun, User
from ..database.session import get_db

bearer = HTTPBearer(auto_error=False)


def current_user(creds: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db)) -> User:
    if not creds:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated")
    sub = decode_token(creds.credentials)
    user = db.get(User, int(sub)) if sub and sub.isdigit() else None
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")
    return user


def _owned(db: Session, cls, id_: int, user: User, label: str):
    obj = db.get(cls, id_)
    if not obj or obj.owner_id != user.id:
        raise HTTPException(404, f"{label} not found")
    return obj


def get_dataset(db: Session, id_: int, user: User) -> Dataset:
    return _owned(db, Dataset, id_, user, "Dataset")


def get_model(db: Session, id_: int, user: User) -> MLModel:
    return _owned(db, MLModel, id_, user, "Model")


def get_run(db: Session, id_: int, user: User) -> ScoringRun:
    return _owned(db, ScoringRun, id_, user, "Scoring run")
