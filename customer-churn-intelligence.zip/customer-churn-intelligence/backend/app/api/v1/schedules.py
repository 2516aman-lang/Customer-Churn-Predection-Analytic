from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ...database.models import Schedule, User
from ...database.session import get_db
from ...schemas import ScheduleIn, ScheduleOut, ScheduleUpdate
from ...services import export_service, scheduler_service as sch
from ..deps import current_user, get_dataset, get_model

router = APIRouter(prefix="/schedules", tags=["schedules"])


def _get(db: Session, id_: int, user: User) -> Schedule:
    s = db.get(Schedule, id_)
    if not s or s.owner_id != user.id:
        raise HTTPException(404, "Schedule not found")
    return s


def _check_notify(email_to, push_webhook):
    if email_to and not export_service.smtp_configured():
        raise HTTPException(400, "Email is not configured on the server (SMTP_HOST)")
    if push_webhook and not export_service.webhook_configured():
        raise HTTPException(400, "CRM webhook is not configured on the server (CRM_WEBHOOK_URL)")


@router.get("", response_model=list[ScheduleOut])
def list_schedules(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return db.query(Schedule).filter(Schedule.owner_id == user.id).order_by(Schedule.id.desc()).all()


@router.post("", response_model=ScheduleOut, status_code=201)
def create(body: ScheduleIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    ds = get_dataset(db, body.dataset_id, user)
    if ds.status != "cleaned":
        raise HTTPException(400, "Clean the dataset before scheduling")
    if body.model_id:
        get_model(db, body.model_id, user)
    _check_notify(body.email_to, body.push_webhook)
    s = Schedule(owner_id=user.id, **body.model_dump(), next_run_at=sch.next_after(body.frequency))
    db.add(s)
    db.commit()
    return s


@router.patch("/{schedule_id}", response_model=ScheduleOut)
def update(schedule_id: int, body: ScheduleUpdate, db: Session = Depends(get_db), user: User = Depends(current_user)):
    s = _get(db, schedule_id, user)
    data = body.model_dump(exclude_unset=True)
    if data.get("model_id"):
        get_model(db, data["model_id"], user)
    _check_notify(data.get("email_to"), data.get("push_webhook"))
    for k, v in data.items():
        setattr(s, k, v)
    if "frequency" in data or data.get("enabled"):
        s.next_run_at = sch.next_after(s.frequency)
    db.commit()
    return s


@router.post("/{schedule_id}/run", response_model=ScheduleOut)
def run_now(schedule_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    s = _get(db, schedule_id, user)
    sch.execute(s.id)
    db.refresh(s)
    return s


@router.delete("/{schedule_id}", status_code=204)
def delete(schedule_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    db.delete(_get(db, schedule_id, user))
    db.commit()
