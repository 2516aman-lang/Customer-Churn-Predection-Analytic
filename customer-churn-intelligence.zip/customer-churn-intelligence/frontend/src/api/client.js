import axios from 'axios'

export const TOKEN_KEY = 'churn_token'

const client = axios.create({ baseURL: import.meta.env.VITE_API_URL || '/api/v1', timeout: 120000 })

client.interceptors.request.use((cfg) => {
  const t = localStorage.getItem(TOKEN_KEY)
  if (t) cfg.headers.Authorization = `Bearer ${t}`
  return cfg
})

client.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401 && !err.config.url.includes('/auth/')) {
      localStorage.removeItem(TOKEN_KEY)
      window.dispatchEvent(new Event('auth:logout'))
    }
    const d = err.response?.data?.detail
    err.friendly = typeof d === 'string' ? d : Array.isArray(d) ? d.map((x) => x.msg).join('; ') : err.message
    return Promise.reject(err)
  },
)

export const data = (p) => p.then((r) => r.data)

export async function download(url, filename, params) {
  const r = await client.get(url, { responseType: 'blob', params })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(r.data)
  a.download = filename
  a.click()
  URL.revokeObjectURL(a.href)
}

export default client
