"""Dataset validation / data-quality profiling."""
from __future__ import annotations

from typing import Any

import pandas as pd

from .cleaning import POSITIVE, NEGATIVE

ID_HINTS = ("id", "customerid", "customer_id", "uuid", "account")
TARGET_HINTS = ("churn", "exited", "attrition", "left", "cancel", "target")


def guess_target(df: pd.DataFrame) -> str | None:
    for c in df.columns:
        if any(h in str(c).lower() for h in TARGET_HINTS):
            vals = {str(v).strip().lower() for v in df[c].dropna().unique()}
            if 0 < len(vals) <= 3 and vals <= (POSITIVE | NEGATIVE):
                return c
    for c in df.columns:  # any binary Yes/No-like column
        vals = {str(v).strip().lower() for v in df[c].dropna().unique()}
        if len(vals) == 2 and vals <= (POSITIVE | NEGATIVE):
            return c
    return None


def _numeric_like(s: pd.Series) -> bool:
    """Text column that is really numbers with blanks (e.g. ' ' in TotalCharges)."""
    if pd.api.types.is_numeric_dtype(s):
        return True
    t = s.astype("object").map(lambda v: v.strip() if isinstance(v, str) else v).replace("", pd.NA).dropna()
    return len(t) > 0 and pd.to_numeric(t, errors="coerce").notna().mean() >= 0.95


def guess_id_columns(df: pd.DataFrame) -> list[str]:
    out = []
    for c in df.columns:
        low = str(c).lower().replace(" ", "")
        unique_ratio = df[c].nunique(dropna=True) / max(len(df), 1)
        is_numeric_float = pd.api.types.is_float_dtype(df[c]) or _numeric_like(df[c])
        if (low in ID_HINTS or low.endswith("id") or low.endswith("_id")) and unique_ratio > 0.9:
            out.append(c)
        elif unique_ratio > 0.98 and not is_numeric_float and not pd.api.types.is_numeric_dtype(df[c]):
            out.append(c)
    return out


def column_profile(df: pd.DataFrame) -> list[dict]:
    prof = []
    for c in df.columns:
        s = df[c]
        item: dict[str, Any] = {
            "name": str(c),
            "dtype": str(s.dtype),
            "kind": "numeric" if pd.api.types.is_numeric_dtype(s) else "categorical",
            "missing": int(s.isna().sum()),
            "missing_pct": round(float(s.isna().mean() * 100), 2),
            "unique": int(s.nunique(dropna=True)),
        }
        if item["kind"] == "numeric" and s.notna().any():
            item.update(
                mean=round(float(s.mean()), 3), std=round(float(s.std() or 0), 3),
                min=float(s.min()), max=float(s.max()), median=float(s.median()),
            )
        else:
            top = s.value_counts(dropna=True).head(3)
            item["top_values"] = {str(k): int(v) for k, v in top.items()}
        prof.append(item)
    return prof


def validate_dataset(df: pd.DataFrame, target: str | None = None) -> dict:
    issues: list[dict] = []
    n_rows, n_cols = df.shape

    def add(sev: str, code: str, msg: str, **extra):
        issues.append({"severity": sev, "code": code, "message": msg, **extra})

    if n_rows < 100:
        add("error", "too_few_rows", f"Only {n_rows} rows; at least 100 are recommended for modelling.")
    elif n_rows < 500:
        add("warning", "few_rows", f"{n_rows} rows is small; model metrics may be unstable.")

    dupes = int(df.duplicated().sum())
    if dupes:
        add("warning", "duplicates", f"{dupes} duplicate rows detected.", count=dupes)

    for c in df.columns:
        pct = df[c].isna().mean() * 100
        blanks = 0
        if not pd.api.types.is_numeric_dtype(df[c]):
            blanks = int(df[c].astype("object").map(lambda v: isinstance(v, str) and v.strip() == "").sum())
        if pct > 40:
            add("error", "high_missing", f"'{c}' is {pct:.1f}% missing.", column=str(c))
        elif pct > 0 or blanks:
            add("info", "missing", f"'{c}' has {int(df[c].isna().sum()) + blanks} missing/blank values.", column=str(c))
        if df[c].nunique(dropna=True) <= 1:
            add("warning", "constant", f"'{c}' is constant and carries no signal.", column=str(c))

    ids = guess_id_columns(df)
    for c in ids:
        add("info", "id_column", f"'{c}' looks like an identifier and will be excluded from features.", column=str(c))

    imbalance = None
    if target:
        if target not in df.columns:
            add("error", "missing_target", f"Target column '{target}' not found.")
        else:
            from .cleaning import normalize_target

            try:
                y = normalize_target(df[target]).dropna()
                rate = float(y.mean())
                imbalance = {"churn_rate": round(rate, 4), "positives": int(y.sum()), "negatives": int((1 - y).sum())}
                if y.nunique() < 2:
                    add("error", "single_class", "Target has a single class.")
                elif min(rate, 1 - rate) < 0.1:
                    add("warning", "imbalance", f"Severe class imbalance (churn rate {rate:.1%}); class weights will be used.")
                elif min(rate, 1 - rate) < 0.25:
                    add("info", "imbalance", f"Moderate class imbalance (churn rate {rate:.1%}).")
            except ValueError as e:
                add("error", "bad_target", str(e))

    penalty = sum({"error": 15, "warning": 5, "info": 0.5}[i["severity"]] for i in issues)
    score = max(0, round(100 - penalty, 1))
    return {
        "rows": int(n_rows),
        "columns": int(n_cols),
        "duplicates": dupes,
        "quality_score": score,
        "suggested_target": guess_target(df),
        "suggested_id_columns": ids,
        "imbalance": imbalance,
        "issues": issues,
        "is_valid": not any(i["severity"] == "error" for i in issues),
        "profile": column_profile(df),
    }
