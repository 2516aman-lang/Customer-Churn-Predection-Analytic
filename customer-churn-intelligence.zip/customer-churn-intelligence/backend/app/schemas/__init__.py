from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---- auth
class RegisterIn(BaseModel):
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    password: str = Field(min_length=6)
    name: str = ""


class LoginIn(BaseModel):
    email: str
    password: str


class UserOut(ORM):
    id: int
    email: str
    name: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---- datasets
class DatasetOut(ORM):
    id: int
    name: str
    filename: str
    rows: int
    columns: int
    target: str | None
    id_columns: list[str]
    status: str
    validation: dict | None = None
    cleaning_report: dict | None = None
    created_at: datetime


class DatasetUpdate(BaseModel):
    name: str | None = None
    target: str | None = None
    id_columns: list[str] | None = None


class CleanIn(BaseModel):
    drop_duplicates: bool = True
    cap_outliers: bool = True
    impute: bool = True


class SampleIn(BaseModel):
    rows: int = Field(3000, ge=200, le=50000)
    seed: int = 42


# ---- models
class TrainIn(BaseModel):
    dataset_id: int
    algorithms: list[str] = Field(min_length=1)
    name: str | None = None
    params: dict[str, dict[str, Any]] = {}
    test_size: float = Field(0.2, gt=0.05, lt=0.5)
    cv_folds: int = Field(3, ge=0, le=10)
    exclude_columns: list[str] = []


class ModelOut(ORM):
    id: int
    dataset_id: int
    name: str
    algorithm: str
    status: str
    config: dict
    metrics: dict | None
    is_active: bool
    error: str | None
    created_at: datetime
    finished_at: datetime | None


# ---- predictions
class SinglePredictIn(BaseModel):
    model_id: int
    record: dict[str, Any]


class WhatIfIn(BaseModel):
    model_id: int
    record: dict[str, Any]
    changes: dict[str, Any]


class BatchFromDatasetIn(BaseModel):
    model_id: int
    dataset_id: int
    name: str | None = None


class RunOut(ORM):
    id: int
    model_id: int
    dataset_id: int | None
    name: str
    rows: int
    summary: dict | None
    created_at: datetime


# ---- retention
class SimulateIn(BaseModel):
    budget: float = Field(10000, ge=0)
    cost_per_contact: float = Field(15, ge=0)
    offer_cost_pct: float = Field(10, ge=0, le=100, description="Discount as % of monthly revenue, per retained customer per month")
    success_rate: float = Field(0.3, ge=0, le=1)
    min_probability: float = Field(0.5, ge=0, le=1)
    clv_months: int = Field(12, ge=1, le=120)
    default_monthly_value: float = Field(60, ge=0)


# ---- reports
class ReportIn(BaseModel):
    kind: str = Field(pattern="^(executive_summary|model_performance|at_risk_customers)$")
    fmt: str = Field("pdf", pattern="^(pdf|csv)$")
    dataset_id: int | None = None
    model_id: int | None = None
    run_id: int | None = None
    title: str | None = None


class ReportOut(ORM):
    id: int
    title: str
    kind: str
    fmt: str
    params: dict
    created_at: datetime


# ---- export
class EmailExportIn(BaseModel):
    to: list[str] = Field(min_length=1)
    min_tier: str = Field("High", pattern="^(Low|Medium|High|Critical)$")
    subject: str | None = None
    message: str | None = None
    crm_format: str = Field("generic", pattern="^(generic|salesforce|hubspot)$")


class WebhookExportIn(BaseModel):
    url: str | None = None
    min_tier: str = Field("High", pattern="^(Low|Medium|High|Critical)$")


# ---- schedules
class ScheduleIn(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    dataset_id: int
    model_id: int | None = None
    frequency: str = Field("daily", pattern="^(hourly|daily|weekly)$")
    enabled: bool = True
    min_tier: str = Field("High", pattern="^(Low|Medium|High|Critical)$")
    email_to: str | None = None
    push_webhook: bool = False


class ScheduleUpdate(BaseModel):
    name: str | None = None
    frequency: str | None = Field(None, pattern="^(hourly|daily|weekly)$")
    enabled: bool | None = None
    min_tier: str | None = Field(None, pattern="^(Low|Medium|High|Critical)$")
    email_to: str | None = None
    push_webhook: bool | None = None
    model_id: int | None = None


class ScheduleOut(ORM):
    id: int
    name: str
    dataset_id: int
    model_id: int | None
    frequency: str
    enabled: bool
    min_tier: str
    email_to: str | None
    push_webhook: bool
    next_run_at: datetime | None
    last_run_at: datetime | None
    last_run_id: int | None
    last_status: str | None
    last_message: str | None
    created_at: datetime
