"""Model training: algorithm registry, train/test split, cross-validation, artifact persistence."""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.tree import DecisionTreeClassifier

from . import explainability as xai
from .evaluation import evaluate
from .features import build_pipeline

ALGORITHMS: dict[str, dict[str, Any]] = {
    "logistic_regression": {
        "label": "Logistic Regression", "scale": True,
        "defaults": {"C": 1.0, "max_iter": 1000},
        "factory": lambda p: LogisticRegression(class_weight="balanced", **p),
    },
    "decision_tree": {
        "label": "Decision Tree", "scale": False,
        "defaults": {"max_depth": 6, "min_samples_leaf": 20},
        "factory": lambda p: DecisionTreeClassifier(class_weight="balanced", random_state=42, **p),
    },
    "random_forest": {
        "label": "Random Forest", "scale": False,
        "defaults": {"n_estimators": 300, "max_depth": 12, "min_samples_leaf": 5},
        "factory": lambda p: RandomForestClassifier(class_weight="balanced_subsample", n_jobs=-1, random_state=42, **p),
    },
    "gradient_boosting": {
        "label": "Gradient Boosting", "scale": False,
        "defaults": {"n_estimators": 200, "learning_rate": 0.05, "max_depth": 3},
        "factory": lambda p: GradientBoostingClassifier(random_state=42, **p),
    },
    "hist_gradient_boosting": {
        "label": "Hist Gradient Boosting", "scale": False,
        "defaults": {"max_iter": 300, "learning_rate": 0.05, "max_depth": 6},
        "factory": lambda p: HistGradientBoostingClassifier(class_weight="balanced", random_state=42, **p),
    },
}


def list_algorithms() -> list[dict]:
    return [{"key": k, "label": v["label"], "defaults": v["defaults"]} for k, v in ALGORITHMS.items()]


def _coerce_params(algo: str, params: dict | None) -> dict:
    merged = dict(ALGORITHMS[algo]["defaults"])
    for k, v in (params or {}).items():
        if k in merged and v is not None and v != "":
            merged[k] = type(merged[k])(v)
    return merged


def train_model(
    df: pd.DataFrame,
    target: str,
    algorithm: str,
    out_dir: str | Path,
    model_id: str,
    params: dict | None = None,
    id_columns: list[str] | None = None,
    exclude_columns: list[str] | None = None,
    test_size: float = 0.2,
    cv_folds: int = 3,
    seed: int = 42,
) -> dict:
    if algorithm not in ALGORITHMS:
        raise ValueError(f"Unknown algorithm '{algorithm}'")
    t0 = time.time()
    drop = set(id_columns or []) | set(exclude_columns or []) | {target}
    features = [c for c in df.columns if c not in drop]
    X, y = df[features], df[target].astype(int)
    if y.nunique() < 2:
        raise ValueError("Target needs both classes to train a model")

    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=test_size, stratify=y, random_state=seed)
    spec = ALGORITHMS[algorithm]
    p = _coerce_params(algorithm, params)
    pipe = build_pipeline(spec["factory"](p), X_tr, scale=spec["scale"])

    cv_scores = []
    if cv_folds and cv_folds >= 2:
        cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=seed)
        cv_scores = cross_val_score(pipe, X_tr, y_tr, cv=cv, scoring="roc_auc", n_jobs=1).tolist()

    pipe.fit(X_tr, y_tr)
    proba = pipe.predict_proba(X_te)[:, 1]
    ev = evaluate(y_te, proba)
    importance = xai.global_importance(pipe, X_te, y_te)
    base = xai.baselines(X_tr)

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{model_id}.joblib"
    meta = {
        "algorithm": algorithm,
        "label": spec["label"],
        "params": p,
        "target": target,
        "features": features,
        "feature_types": {c: ("numeric" if pd.api.types.is_numeric_dtype(X[c]) else "categorical") for c in features},
        "feature_options": {c: sorted(map(str, X[c].dropna().unique()))[:50] for c in features if not pd.api.types.is_numeric_dtype(X[c])},
        "feature_ranges": {c: [float(X[c].min()), float(X[c].max())] for c in features if pd.api.types.is_numeric_dtype(X[c])},
        "baselines": {k: (v if not isinstance(v, (np.generic,)) else v.item()) for k, v in base.items()},
        "threshold": ev["threshold"],
        "train_rows": int(len(X_tr)),
        "test_rows": int(len(X_te)),
        "cv_roc_auc": [round(s, 4) for s in cv_scores],
        "cv_roc_auc_mean": round(float(np.mean(cv_scores)), 4) if cv_scores else None,
        "train_seconds": round(time.time() - t0, 2),
    }
    joblib.dump({"pipeline": pipe, "meta": meta}, path)
    result = {**ev, "importance": importance, "meta": meta, "artifact_path": str(path)}
    (out_dir / f"{model_id}.json").write_text(json.dumps(result, default=str))
    return result
