import { useState } from 'react'
import { useApp } from '../context/AppContext'

/** Wraps an async handler with loading state + error toast. */
export function useAction(fn, { success } = {}) {
  const { toast } = useApp()
  const [busy, setBusy] = useState(false)
  const run = async (...args) => {
    setBusy(true)
    try {
      const r = await fn(...args)
      if (success) toast(typeof success === 'function' ? success(r) : success, 'success')
      return r
    } catch (e) {
      toast(e.friendly || e.message, 'error')
    } finally {
      setBusy(false)
    }
  }
  return [run, busy]
}
