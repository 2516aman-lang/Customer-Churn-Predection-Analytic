import { Outlet } from 'react-router-dom'
import Toasts from '../common/Toasts'
import Navbar from './Navbar'
import Sidebar from './Sidebar'

export default function MainLayout() {
  return (
    <div className="app">
      <Sidebar />
      <div className="main">
        <Navbar />
        <main className="content"><Outlet /></main>
      </div>
      <Toasts />
    </div>
  )
}
