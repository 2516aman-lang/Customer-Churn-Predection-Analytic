import client, { data } from './client'
export const login = (b) => data(client.post('/auth/login', b))
export const register = (b) => data(client.post('/auth/register', b))
export const me = () => data(client.get('/auth/me'))
