import { Fragment } from 'react'
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, ComposedChart, Legend, Line, LineChart, Pie, PieChart,
  ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import { TIER_COLORS } from '../common'

const C = { churn: 'var(--churn)', retained: 'var(--retained)', grid: 'var(--border)', text: 'var(--muted)' }
const AX = { stroke: C.text, fontSize: 11, tickLine: false, axisLine: false }
const TT = { contentStyle: { background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 } }
const pct = (v) => `${(v * 100).toFixed(1)}%`

export const Box = ({ h = 260, children }) => <div style={{ height: h }}><ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer></div>

/** Stacked retained/churned histogram for a numeric column. */
export function Histogram({ bins, h = 240 }) {
  return (
    <Box h={h}>
      <BarChart data={bins} margin={{ left: -15, right: 4 }}>
        <CartesianGrid stroke={C.grid} vertical={false} />
        <XAxis dataKey="label" {...AX} interval="preserveStartEnd" />
        <YAxis {...AX} />
        <Tooltip {...TT} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Bar dataKey="retained" stackId="a" fill={C.retained} name="Retained" />
        <Bar dataKey="churned" stackId="a" fill={C.churn} name="Churned" radius={[3, 3, 0, 0]} />
      </BarChart>
    </Box>
  )
}

/** Churn rate by category (bars) with customer count tooltip. */
export function RateBars({ data, labelKey = 'value', rateKey = 'churn_rate', h = 240, layout = 'vertical', avg }) {
  const horizontal = layout === 'horizontal'
  return (
    <Box h={h}>
      <BarChart data={data} layout={horizontal ? 'vertical' : 'horizontal'} margin={{ left: horizontal ? 30 : -10, right: 14 }}>
        <CartesianGrid stroke={C.grid} horizontal={!horizontal} vertical={horizontal} />
        {horizontal ? (<><XAxis type="number" tickFormatter={pct} {...AX} /><YAxis type="category" dataKey={labelKey} width={110} {...AX} /></>)
          : (<><XAxis dataKey={labelKey} {...AX} /><YAxis tickFormatter={pct} {...AX} /></>)}
        <Tooltip {...TT} formatter={(v, n, p) => [pct(v), `Churn rate (${(p.payload.count ?? p.payload.customers ?? '')} customers)`]} />
        {avg != null && (horizontal ? <ReferenceLine x={avg} stroke="var(--muted)" strokeDasharray="4 4" /> : <ReferenceLine y={avg} stroke="var(--muted)" strokeDasharray="4 4" />)}
        <Bar dataKey={rateKey} fill={C.churn} radius={horizontal ? [0, 4, 4, 0] : [4, 4, 0, 0]} />
      </BarChart>
    </Box>
  )
}

export function HBar({ data, labelKey, valueKey, color = 'var(--accent)', h = 280, format, width = 130 }) {
  return (
    <Box h={h}>
      <BarChart data={data} layout="vertical" margin={{ left: 10, right: 20 }}>
        <CartesianGrid stroke={C.grid} horizontal={false} />
        <XAxis type="number" {...AX} tickFormatter={format} />
        <YAxis type="category" dataKey={labelKey} width={width} {...AX} />
        <Tooltip {...TT} formatter={(v) => (format ? format(v) : v)} />
        <Bar dataKey={valueKey} fill={color} radius={[0, 4, 4, 0]} />
      </BarChart>
    </Box>
  )
}

export function Donut({ data, nameKey = 'name', valueKey = 'value', colors, h = 220, center }) {
  return (
    <div style={{ position: 'relative' }}>
      <Box h={h}>
        <PieChart>
          <Pie data={data} dataKey={valueKey} nameKey={nameKey} innerRadius="58%" outerRadius="88%" paddingAngle={2} stroke="none">
            {data.map((d, i) => <Cell key={i} fill={colors?.[d[nameKey]] || colors?.[i] || TIER_COLORS[d[nameKey]]} />)}
          </Pie>
          <Tooltip {...TT} />
          <Legend wrapperStyle={{ fontSize: 12 }} />
        </PieChart>
      </Box>
      {center && <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', pointerEvents: 'none', paddingBottom: 28 }}>{center}</div>}
    </div>
  )
}

const PALETTE = ['#4f46e5', '#e11d48', '#0ea5e9', '#f59e0b', '#10b981', '#8b5cf6']

/** ROC curves for one or many models: curves = [{name, fpr, tpr}] */
export function RocChart({ curves, h = 280 }) {
  const merged = curves.flatMap((c, k) => c.fpr.map((x, i) => ({ x, [`m${k}`]: c.tpr[i] }))).sort((a, b) => a.x - b.x)
  return (
    <Box h={h}>
      <LineChart data={merged} margin={{ left: -10, right: 10 }}>
        <CartesianGrid stroke={C.grid} />
        <XAxis dataKey="x" type="number" domain={[0, 1]} {...AX} label={{ value: 'False positive rate', position: 'insideBottom', offset: -2, fontSize: 11, fill: 'var(--muted)' }} />
        <YAxis domain={[0, 1]} {...AX} />
        <Tooltip {...TT} formatter={(v) => (typeof v === 'number' ? v.toFixed(3) : v)} labelFormatter={(v) => `FPR ${Number(v).toFixed(3)}`} />
        <ReferenceLine segment={[{ x: 0, y: 0 }, { x: 1, y: 1 }]} stroke="var(--muted)" strokeDasharray="4 4" />
        {curves.map((c, k) => <Line key={k} dataKey={`m${k}`} name={c.name} stroke={PALETTE[k % PALETTE.length]} dot={false} strokeWidth={2} connectNulls />)}
        {curves.length > 1 && <Legend wrapperStyle={{ fontSize: 12 }} />}
      </LineChart>
    </Box>
  )
}

export function PrChart({ curves, h = 280 }) {
  const merged = curves.flatMap((c, k) => c.recall.map((x, i) => ({ x, [`m${k}`]: c.precision[i] }))).sort((a, b) => a.x - b.x)
  return (
    <Box h={h}>
      <LineChart data={merged} margin={{ left: -10, right: 10 }}>
        <CartesianGrid stroke={C.grid} />
        <XAxis dataKey="x" type="number" domain={[0, 1]} {...AX} label={{ value: 'Recall', position: 'insideBottom', offset: -2, fontSize: 11, fill: 'var(--muted)' }} />
        <YAxis domain={[0, 1]} {...AX} />
        <Tooltip {...TT} formatter={(v) => (typeof v === 'number' ? v.toFixed(3) : v)} />
        {curves.map((c, k) => <Line key={k} dataKey={`m${k}`} name={c.name} stroke={PALETTE[k % PALETTE.length]} dot={false} strokeWidth={2} connectNulls />)}
        {curves.length > 1 && <Legend wrapperStyle={{ fontSize: 12 }} />}
      </LineChart>
    </Box>
  )
}

export function ThresholdChart({ rows, current, h = 260 }) {
  return (
    <Box h={h}>
      <LineChart data={rows} margin={{ left: -10, right: 10 }}>
        <CartesianGrid stroke={C.grid} />
        <XAxis dataKey="threshold" {...AX} />
        <YAxis domain={[0, 1]} {...AX} />
        <Tooltip {...TT} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Line dataKey="precision" stroke="#0ea5e9" dot={false} strokeWidth={2} />
        <Line dataKey="recall" stroke="#e11d48" dot={false} strokeWidth={2} />
        <Line dataKey="f1" stroke="#4f46e5" dot={false} strokeWidth={2} />
        {current != null && <ReferenceLine x={rows.reduce((b, r) => (Math.abs(r.threshold - current) < Math.abs(b - current) ? r.threshold : b), rows[0].threshold)} stroke="var(--muted)" strokeDasharray="4 4" />}
      </LineChart>
    </Box>
  )
}

export function LiftChart({ rows, h = 260 }) {
  return (
    <Box h={h}>
      <ComposedChart data={rows} margin={{ left: -10, right: 10 }}>
        <CartesianGrid stroke={C.grid} vertical={false} />
        <XAxis dataKey="decile" {...AX} />
        <YAxis yAxisId="l" tickFormatter={pct} {...AX} />
        <YAxis yAxisId="r" orientation="right" tickFormatter={pct} domain={[0, 1]} {...AX} />
        <Tooltip {...TT} formatter={(v, n) => (n === 'Lift' ? v : pct(v))} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Bar yAxisId="l" dataKey="churn_rate" name="Churn rate" fill="#e11d48" radius={[3, 3, 0, 0]} />
        <Line yAxisId="r" dataKey="cum_capture" name="Cumulative capture" stroke="#4f46e5" strokeWidth={2} dot />
      </ComposedChart>
    </Box>
  )
}

export function ProbHistogram({ counts, h = 200 }) {
  const data = counts.map((c, i) => ({ range: `${i * 10}–${(i + 1) * 10}%`, count: c, tier: i >= 7 ? 'Critical' : i >= 5 ? 'High' : i >= 3 ? 'Medium' : 'Low' }))
  return (
    <Box h={h}>
      <BarChart data={data} margin={{ left: -15 }}>
        <CartesianGrid stroke={C.grid} vertical={false} />
        <XAxis dataKey="range" {...AX} interval={0} tick={{ fontSize: 9 }} />
        <YAxis {...AX} />
        <Tooltip {...TT} />
        <Bar dataKey="count" radius={[3, 3, 0, 0]}>{data.map((d, i) => <Cell key={i} fill={TIER_COLORS[d.tier]} />)}</Bar>
      </BarChart>
    </Box>
  )
}

export function CurveArea({ data, x, y, color = '#4f46e5', h = 240, format }) {
  return (
    <Box h={h}>
      <AreaChart data={data} margin={{ left: -5, right: 10 }}>
        <CartesianGrid stroke={C.grid} vertical={false} />
        <XAxis dataKey={x} {...AX} />
        <YAxis {...AX} tickFormatter={format} />
        <Tooltip {...TT} formatter={(v) => (format ? format(v) : v)} />
        <Area dataKey={y} stroke={color} fill={color} fillOpacity={0.18} strokeWidth={2} />
      </AreaChart>
    </Box>
  )
}

/** Correlation heat-map (CSS grid; diverging colour scale). */
export function Heatmap({ columns, matrix }) {
  const color = (v) => (v >= 0 ? `rgba(79,70,229,${Math.min(1, Math.abs(v)).toFixed(2)})` : `rgba(225,29,72,${Math.min(1, Math.abs(v)).toFixed(2)})`)
  const n = columns.length
  return (
    <div style={{ overflowX: 'auto' }}>
      <div className="heat" style={{ gridTemplateColumns: `120px repeat(${n}, minmax(44px, 1fr))`, minWidth: 120 + n * 46 }}>
        <div />
        {columns.map((c) => <div key={c} style={{ minHeight: 0, fontWeight: 600, color: 'var(--muted)' }} title={c}>{c.slice(0, 8)}</div>)}
        {matrix.map((row, i) => (
          <Fragment key={i}>
            <div style={{ justifyContent: 'end', textAlign: 'right', paddingRight: 6, fontWeight: 600, color: 'var(--muted)' }}>{columns[i].slice(0, 16)}</div>
            {row.map((v, j) => <div key={`${i}-${j}`} style={{ background: color(v), color: Math.abs(v) > 0.5 ? '#fff' : 'var(--text)' }} title={`${columns[i]} × ${columns[j]}: ${v}`}>{v.toFixed(2)}</div>)}
          </Fragment>
        ))}
      </div>
    </div>
  )
}

export function ConfusionMatrix({ cm }) {
  const cell = (v, tone, label) => (
    <div style={{ padding: 14, borderRadius: 10, textAlign: 'center', background: tone, color: '#fff' }}>
      <div style={{ fontSize: 22, fontWeight: 700 }}>{v?.toLocaleString()}</div><div style={{ fontSize: 11, opacity: .9 }}>{label}</div>
    </div>
  )
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
      {cell(cm.tn, '#16a34a', 'True negative')}{cell(cm.fp, '#f59e0b', 'False positive')}
      {cell(cm.fn, '#e11d48', 'False negative')}{cell(cm.tp, '#4f46e5', 'True positive')}
    </div>
  )
}
