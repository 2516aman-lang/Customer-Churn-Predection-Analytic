import pandas as pd
from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ...database.models import ScoringRun, User
from ...database.session import get_db
from ...schemas import BatchFromDatasetIn, RunOut, SinglePredictIn, WhatIfIn
from ...services import dataset_service, prediction_service as svc
from ...services.common import to_records
from ..deps import current_user, get_dataset, get_model, get_run

from src.inference import predict_one

router = APIRouter(prefix="/predictions", tags=["predictions"])


@router.get("/schema/{model_id}")
def schema(model_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    try:
        return svc.schema(get_model(db, model_id, user))
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/single")
def single(body: SinglePredictIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    m = get_model(db, body.model_id, user)
    try:
        return predict_one(svc._artifact(m), body.record)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/whatif")
def whatif(body: WhatIfIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Score a customer, then re-score with `changes` applied (e.g. contract → Two year)."""
    m = get_model(db, body.model_id, user)
    try:
        path = svc._artifact(m)
        base = predict_one(path, body.record)
        new = predict_one(path, {**body.record, **body.changes})
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"baseline": base, "scenario": new,
            "delta": round(new["churn_probability"] - base["churn_probability"], 4), "changes": body.changes}


@router.post("/batch", response_model=RunOut, status_code=201)
async def batch_upload(model_id: int = Form(...), file: UploadFile = File(...), name: str | None = Form(None),
                       db: Session = Depends(get_db), user: User = Depends(current_user)):
    m = get_model(db, model_id, user)
    try:
        df = dataset_service.read_upload(file.filename or "batch.csv", await file.read())
        return svc.run_batch(db, user, m, df, name or f"Batch · {file.filename}")
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/batch/dataset", response_model=RunOut, status_code=201)
def batch_dataset(body: BatchFromDatasetIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    m, ds = get_model(db, body.model_id, user), get_dataset(db, body.dataset_id, user)
    try:
        return svc.run_batch(db, user, m, dataset_service.load_df(ds), body.name or f"Scoring · {ds.name}", ds)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/runs", response_model=list[RunOut])
def runs(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return db.query(ScoringRun).filter(ScoringRun.owner_id == user.id).order_by(ScoringRun.id.desc()).all()


@router.get("/runs/{run_id}")
def run_detail(run_id: int, tier: str | None = None, limit: int = Query(50, ge=1, le=500), offset: int = Query(0, ge=0),
               db: Session = Depends(get_db), user: User = Depends(current_user)):
    run = get_run(db, run_id, user)
    df = svc.load_run(run)
    if tier and tier != "All":
        df = df[df["risk_tier"] == tier]
    df = df.sort_values("churn_probability", ascending=False)
    return {"run": RunOut.model_validate(run).model_dump(mode="json"), "total": int(len(df)),
            "columns": [c for c in df.columns if c != "top_drivers"],
            "rows": to_records(df.iloc[offset: offset + limit])}


@router.get("/runs/{run_id}/download")
def run_download(run_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    run = get_run(db, run_id, user)
    return FileResponse(run.results_path, media_type="text/csv", filename=f"{run.name}.csv")


@router.delete("/runs/{run_id}", status_code=204)
def run_delete(run_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    svc.delete_run(db, get_run(db, run_id, user))
