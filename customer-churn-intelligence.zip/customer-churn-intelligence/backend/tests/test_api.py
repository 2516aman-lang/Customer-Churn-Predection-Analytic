"""End-to-end API flow: auth → dataset → clean → train → predict → retention → report."""
import io

import pytest

P = "/api/v1"


def test_auth_required(client):
    assert client.get(f"{P}/datasets").status_code == 401


def test_register_login_duplicate(client, auth):
    assert client.post(f"{P}/auth/register", json={"email": "t@example.com", "password": "secret1"}).status_code == 409
    r = client.post(f"{P}/auth/login", json={"email": "t@example.com", "password": "secret1"})
    assert r.status_code == 200 and r.json()["user"]["email"] == "t@example.com"
    assert client.post(f"{P}/auth/login", json={"email": "t@example.com", "password": "bad"}).status_code == 401
    assert client.get(f"{P}/auth/me", headers=auth).json()["name"] == "Tester"


@pytest.fixture(scope="module")
def state():
    return {}


def test_dataset_flow(client, auth, state):
    r = client.post(f"{P}/datasets/sample", json={"rows": 1500}, headers=auth)
    assert r.status_code == 201, r.text
    ds = r.json()
    assert ds["target"] == "Churn" and ds["id_columns"] == ["customerID"] and ds["validation"]["quality_score"] > 0
    state["ds"] = ds["id"]
    # training before cleaning is rejected
    r = client.post(f"{P}/models/train", json={"dataset_id": ds["id"], "algorithms": ["logistic_regression"]}, headers=auth)
    assert r.status_code == 400
    r = client.post(f"{P}/datasets/{ds['id']}/clean", json={}, headers=auth)
    assert r.status_code == 200 and r.json()["status"] == "cleaned"
    assert r.json()["cleaning_report"]["duplicates_removed"] > 0
    pv = client.get(f"{P}/datasets/{ds['id']}/preview?rows=5", headers=auth).json()
    assert len(pv["rows"]) == 5 and "Churn" in pv["columns"]


def test_upload_rejects_bad_file(client, auth):
    r = client.post(f"{P}/datasets/upload", files={"file": ("x.pdf", b"nope")}, headers=auth)
    assert r.status_code == 400
    csv = b"a,b,Churn\n" + b"\n".join(f"{i},{i%3},{'Yes' if i%4==0 else 'No'}".encode() for i in range(200))
    r = client.post(f"{P}/datasets/upload", files={"file": ("tiny.csv", io.BytesIO(csv))}, headers=auth)
    assert r.status_code == 201 and r.json()["target"] == "Churn"


def test_eda_and_dashboard(client, auth, state):
    e = client.get(f"{P}/analytics/datasets/{state['ds']}/eda", headers=auth).json()
    assert e["overview"]["churn_rate"] > 0 and e["numeric"] and e["categorical"] and e["correlation"]
    seg = client.get(f"{P}/analytics/datasets/{state['ds']}/segments?by=Contract", headers=auth).json()
    assert {s["segment"] for s in seg} == {"Month-to-month", "One year", "Two year"}
    assert client.get(f"{P}/analytics/dashboard", headers=auth).status_code == 200


def test_train_compare_activate(client, auth, state):
    r = client.post(f"{P}/models/train", headers=auth,
                    json={"dataset_id": state["ds"], "algorithms": ["logistic_regression", "random_forest"],
                          "params": {"random_forest": {"n_estimators": 60}}, "cv_folds": 2})
    assert r.status_code == 202, r.text
    ids = [m["id"] for m in r.json()]
    for m in client.get(f"{P}/models?dataset_id={state['ds']}", headers=auth).json():
        assert m["status"] == "completed", m
        assert m["metrics"]["roc_auc"] > 0.7
    state["model"] = ids[0]
    d = client.get(f"{P}/models/{ids[0]}", headers=auth).json()
    assert d["result"]["importance"] and d["result"]["confusion_matrix"] and d["result"]["lift_table"]
    cmp_ = client.get(f"{P}/models/compare?ids={','.join(map(str, ids))}", headers=auth).json()
    assert len(cmp_) == 2
    assert client.post(f"{P}/models/{ids[1]}/activate", headers=auth).json()["is_active"] is True
    assert client.get(f"{P}/models/algorithms", headers=auth).json()


def test_predictions(client, auth, state):
    mid = state["model"]
    sch = client.get(f"{P}/predictions/schema/{mid}", headers=auth).json()
    assert "Contract" in sch["features"]
    rec = {**sch["baselines"], "Contract": "Month-to-month", "tenure": 2}
    one = client.post(f"{P}/predictions/single", json={"model_id": mid, "record": rec}, headers=auth).json()
    assert 0 <= one["churn_probability"] <= 1 and one["drivers"]
    w = client.post(f"{P}/predictions/whatif", headers=auth,
                    json={"model_id": mid, "record": rec, "changes": {"Contract": "Two year", "tenure": 40}}).json()
    assert w["delta"] < 0
    r = client.post(f"{P}/predictions/batch/dataset", json={"model_id": mid, "dataset_id": state["ds"]}, headers=auth)
    assert r.status_code == 201, r.text
    run = r.json()
    state["run"] = run["id"]
    assert run["summary"]["rows"] > 1000 and set(run["summary"]["tiers"]) == {"Critical", "High", "Medium", "Low"}
    page = client.get(f"{P}/predictions/runs/{run['id']}?limit=5", headers=auth).json()
    assert len(page["rows"]) == 5 and page["rows"][0]["churn_probability"] >= page["rows"][4]["churn_probability"]
    assert client.get(f"{P}/predictions/runs/{run['id']}/download", headers=auth).status_code == 200
    # upload scoring (missing columns are tolerated)
    csv = b"Contract,tenure,MonthlyCharges\nMonth-to-month,3,90\nTwo year,60,40\n"
    r = client.post(f"{P}/predictions/batch", data={"model_id": mid}, files={"file": ("n.csv", io.BytesIO(csv))}, headers=auth)
    assert r.status_code == 201 and r.json()["rows"] == 2


def test_retention(client, auth, state):
    rid = state["run"]
    o = client.get(f"{P}/retention/{rid}/overview", headers=auth).json()
    assert o["total_expected_loss"] > 0 and len(o["tiers"]) == 4
    c = client.get(f"{P}/retention/{rid}/customers?limit=5&tier=All", headers=auth).json()
    assert c["rows"][0]["recommended_action"] and c["id_column"] == "customerID"
    assert client.get(f"{P}/retention/{rid}/recommendations", headers=auth).json()
    s = client.post(f"{P}/retention/{rid}/simulate", json={"budget": 5000}, headers=auth).json()
    assert s["contacted"] > 0 and s["campaign_cost"] <= 5000 and s["net_benefit"] > 0
    z = client.post(f"{P}/retention/{rid}/simulate", json={"budget": 0}, headers=auth).json()
    assert z["contacted"] == 0


def test_reports(client, auth, state):
    for body, ext in [
        ({"kind": "executive_summary", "dataset_id": state["ds"], "model_id": state["model"], "run_id": state["run"]}, "pdf"),
        ({"kind": "model_performance", "model_id": state["model"]}, "pdf"),
        ({"kind": "at_risk_customers", "run_id": state["run"], "fmt": "csv"}, "csv"),
        ({"kind": "at_risk_customers", "run_id": state["run"]}, "pdf"),
    ]:
        r = client.post(f"{P}/reports", json=body, headers=auth)
        assert r.status_code == 201, r.text
        d = client.get(f"{P}/reports/{r.json()['id']}/download", headers=auth)
        assert d.status_code == 200 and len(d.content) > 100
        if ext == "pdf":
            assert d.content[:4] == b"%PDF"
    assert client.post(f"{P}/reports", json={"kind": "model_performance"}, headers=auth).status_code == 400
    assert len(client.get(f"{P}/reports", headers=auth).json()) == 4


def test_isolation_between_users(client, state):
    r = client.post(f"{P}/auth/register", json={"email": "other@example.com", "password": "secret1"})
    h = {"Authorization": f"Bearer {r.json()['access_token']}"}
    assert client.get(f"{P}/datasets/{state['ds']}", headers=h).status_code == 404
    assert client.get(f"{P}/models/{state['model']}", headers=h).status_code == 404
    assert client.get(f"{P}/retention/{state['run']}/overview", headers=h).status_code == 404


def test_delete_guards(client, auth, state):
    assert client.delete(f"{P}/datasets/{state['ds']}", headers=auth).status_code == 409
    assert client.delete(f"{P}/models/{state['model']}", headers=auth).status_code == 409
    assert client.delete(f"{P}/predictions/runs/{state['run']}", headers=auth).status_code == 204
