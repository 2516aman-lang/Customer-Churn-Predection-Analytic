"""scheduled re-scoring jobs

Revision ID: 0002
Revises: 0001
"""
from alembic import op
import sqlalchemy as sa

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        "schedules",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("owner_id", sa.Integer, sa.ForeignKey("users.id"), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("dataset_id", sa.Integer, sa.ForeignKey("datasets.id"), nullable=False),
        sa.Column("model_id", sa.Integer, sa.ForeignKey("models.id")),
        sa.Column("frequency", sa.String(10), nullable=False),
        sa.Column("enabled", sa.Boolean, nullable=False),
        sa.Column("min_tier", sa.String(10), nullable=False),
        sa.Column("email_to", sa.String(500)),
        sa.Column("push_webhook", sa.Boolean, nullable=False),
        sa.Column("next_run_at", TS),
        sa.Column("last_run_at", TS),
        sa.Column("last_run_id", sa.Integer),
        sa.Column("last_status", sa.String(20)),
        sa.Column("last_message", sa.Text),
        sa.Column("created_at", TS, nullable=False),
    )
    op.create_index("ix_schedules_owner_id", "schedules", ["owner_id"])
    op.create_index("ix_schedules_dataset_id", "schedules", ["dataset_id"])
    op.create_index("ix_schedules_next_run_at", "schedules", ["next_run_at"])


def downgrade() -> None:
    op.drop_table("schedules")
