from __future__ import annotations

from pathlib import Path

from sqlalchemy.orm import Session

from ..database.models import Dataset, MLModel, User
from ..workers import trainer

from src.training import ALGORITHMS


def start_training(db: Session, user: User, ds: Dataset, algorithms: list[str], name: str | None, params: dict,
                   test_size: float, cv_folds: int, exclude_columns: list[str]) -> list[MLModel]:
    if not ds.target:
        raise ValueError("Dataset has no target column configured")
    unknown = [a for a in algorithms if a not in ALGORITHMS]
    if unknown:
        raise ValueError(f"Unknown algorithm(s): {', '.join(unknown)}")
    if ds.status != "cleaned":
        raise ValueError("Clean the dataset before training (Datasets → Clean)")
    models = []
    for algo in dict.fromkeys(algorithms):
        m = MLModel(
            owner_id=user.id, dataset_id=ds.id, algorithm=algo,
            name=f"{name} · {ALGORITHMS[algo]['label']}" if name else f"{ALGORITHMS[algo]['label']} on {ds.name}",
            config={"params": params.get(algo, {}), "test_size": test_size, "cv_folds": cv_folds,
                    "exclude_columns": exclude_columns},
        )
        db.add(m)
        models.append(m)
    db.commit()
    for m in models:
        trainer.submit(m.id)
    for m in models:
        db.refresh(m)
    return models


def activate(db: Session, user: User, m: MLModel) -> MLModel:
    if m.status != "completed":
        raise ValueError("Only completed models can be activated")
    db.query(MLModel).filter(MLModel.owner_id == user.id).update({MLModel.is_active: False})
    m.is_active = True
    db.commit()
    return m


def delete(db: Session, m: MLModel):
    from src.inference import clear_cache

    for ext in ("joblib", "json"):
        Path(m.artifact_path).with_suffix(f".{ext}").unlink(missing_ok=True) if m.artifact_path else None
    clear_cache()
    db.delete(m)
    db.commit()
