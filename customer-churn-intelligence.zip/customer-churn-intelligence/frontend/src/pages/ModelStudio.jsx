import { useEffect, useState } from 'react'
import { CheckCircle2, Play, Trash2 } from 'lucide-react'
import { activateModel, compareModels, deleteModel, getModel, listAlgorithms, trainModels } from '../api/models'
import { Badge, Button, Card, EmptyState, Field, Loader, NumberField, PageHeader, StatCard, Tabs, fmt } from '../components/common'
import { ConfusionMatrix, HBar, LiftChart, PrChart, RocChart, ThresholdChart } from '../components/charts'
import DataTable from '../components/tables/DataTable'
import { useApp } from '../context/AppContext'
import { useAction } from '../hooks/useAction'
import { useAsync } from '../hooks/useAsync'
import { usePolling } from '../hooks/usePolling'

export default function ModelStudio() {
  const { dataset, models, refresh } = useApp()
  const [tab, setTab] = useState('train')
  const [selected, setSelected] = useState(null)
  const [compare, setCompare] = useState([])
  const pending = models.some((m) => ['queued', 'training'].includes(m.status))
  usePolling(refresh, pending, 2000)

  const dsModels = models.filter((m) => !dataset || m.dataset_id === dataset.id)
  const open = (id) => { setSelected(id); setTab('detail') }

  return (
    <>
      <PageHeader title="Model Studio" subtitle="Train, compare and explain churn models. Class imbalance is handled automatically." />
      <Tabs value={tab} onChange={setTab} tabs={[{ key: 'train', label: 'Train' }, { key: 'models', label: `Models (${dsModels.length})` }, { key: 'detail', label: 'Model detail' }, { key: 'compare', label: `Compare${compare.length ? ` (${compare.length})` : ''}` }]} />
      {tab === 'train' && <Train onStarted={() => setTab('models')} />}
      {tab === 'models' && <Leaderboard models={dsModels} compare={compare} setCompare={setCompare} open={open} />}
      {tab === 'detail' && <Detail id={selected ?? dsModels.find((m) => m.status === 'completed')?.id} />}
      {tab === 'compare' && <Compare ids={compare} />}
    </>
  )
}

function Train({ onStarted }) {
  const { dataset, refresh } = useApp()
  const { data: algos } = useAsync(listAlgorithms, [])
  const [chosen, setChosen] = useState(['logistic_regression', 'random_forest', 'gradient_boosting'])
  const [params, setParams] = useState({})
  const [testSize, setTestSize] = useState(0.2)
  const [cv, setCv] = useState(3)
  const [name, setName] = useState('')
  const [exclude, setExclude] = useState([])
  useEffect(() => setExclude([]), [dataset?.id])
  const [go, busy] = useAction(async () => {
    await trainModels({ dataset_id: dataset.id, algorithms: chosen, name: name || null, params, test_size: testSize, cv_folds: cv, exclude_columns: exclude })
    await refresh(); onStarted()
  }, { success: 'Training started' })

  if (!dataset) return <EmptyState title="No dataset" text="Select a dataset first." />
  const features = (dataset.validation?.profile || []).map((c) => c.name).filter((c) => c !== dataset.target && !dataset.id_columns.includes(c))
  return (
    <div className="grid g-wide">
      <Card title="Algorithms" sub="Select one or more to train side by side">
        <div className="stack">
          {algos?.map((a) => (
            <div key={a.key} className="card" style={{ padding: 12, boxShadow: 'none' }}>
              <label className="row" style={{ gap: 8, fontWeight: 600 }}>
                <input type="checkbox" style={{ width: 'auto' }} checked={chosen.includes(a.key)} onChange={(e) => setChosen(e.target.checked ? [...chosen, a.key] : chosen.filter((x) => x !== a.key))} />{a.label}
              </label>
              {chosen.includes(a.key) && (
                <div className="grid g4" style={{ marginTop: 10 }}>
                  {Object.entries(a.defaults).map(([k, v]) => (
                    <NumberField key={k} label={k} value={params[a.key]?.[k] ?? v} step={v < 1 ? 0.01 : 1} onChange={(x) => setParams({ ...params, [a.key]: { ...params[a.key], [k]: x } })} />
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>
      <Card title="Setup">
        <div className="stack">
          <Field label="Run name (optional)"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Q4 baseline" /></Field>
          <NumberField label="Test split" value={testSize} step={0.05} min={0.1} max={0.4} onChange={setTestSize} help="Share of rows held out for evaluation" />
          <NumberField label="Cross-validation folds" value={cv} min={0} max={10} onChange={setCv} help="0 disables CV" />
          <Field label="Exclude features" help="Drop leakage-prone or irrelevant columns">
            <select multiple size={5} value={exclude} onChange={(e) => setExclude([...e.target.selectedOptions].map((o) => o.value))}>{features.map((f) => <option key={f}>{f}</option>)}</select>
          </Field>
          {dataset.status !== 'cleaned' && <div className="alert warn">Clean this dataset first (Datasets → Clean).</div>}
          <Button variant="primary" icon={Play} busy={busy} disabled={!chosen.length || dataset.status !== 'cleaned'} onClick={go}>Train {chosen.length} model{chosen.length !== 1 && 's'}</Button>
        </div>
      </Card>
    </div>
  )
}

function Leaderboard({ models, compare, setCompare, open }) {
  const { refresh } = useApp()
  const [activate] = useAction(async (id) => { await activateModel(id); await refresh() }, { success: 'Model activated for scoring' })
  const [remove] = useAction(async (id) => { await deleteModel(id); await refresh() }, { success: 'Model deleted' })
  if (!models.length) return <EmptyState title="No models yet" text="Train some on the Train tab." />
  const best = Math.max(...models.filter((m) => m.metrics).map((m) => m.metrics.roc_auc), 0)
  const toggle = (id) => setCompare(compare.includes(id) ? compare.filter((x) => x !== id) : [...compare, id].slice(-4))
  const cols = [
    { key: 'cmp', label: '', render: (_, m) => m.status === 'completed' && <input type="checkbox" style={{ width: 'auto' }} checked={compare.includes(m.id)} onChange={() => toggle(m.id)} /> },
    { key: 'name', label: 'Model', render: (v, m) => <a href="#open" onClick={(e) => { e.preventDefault(); m.status === 'completed' && open(m.id) }}>{v}</a> },
    { key: 'status', label: 'Status', render: (v, m) => <span title={m.error}><Badge kind={v} />{m.is_active && <Badge kind="info"> active</Badge>}</span> },
    ...['roc_auc', 'pr_auc', 'precision', 'recall', 'f1'].map((k) => ({ key: k, label: k.replace('_', '-'), render: (_, m) => m.metrics ? <span style={{ fontWeight: m.metrics[k] === best && k === 'roc_auc' ? 700 : 400 }}>{fmt.dec(m.metrics[k])}</span> : '—' })),
    { key: 'cv', label: 'CV AUC', render: (_, m) => fmt.dec(m.metrics?.cv_roc_auc_mean) },
    { key: 'act', label: '', render: (_, m) => (
      <div className="row" style={{ flexWrap: 'nowrap' }}>
        {m.status === 'completed' && !m.is_active && <Button size="sm" icon={CheckCircle2} onClick={() => activate(m.id)}>Activate</Button>}
        <Button size="sm" variant="ghost" icon={Trash2} aria-label="Delete" onClick={() => confirm(`Delete ${m.name}?`) && remove(m.id)} />
      </div>) },
  ]
  return <Card title="Leaderboard" sub="Tick up to 4 models to compare curves. The active model powers predictions and retention."><DataTable columns={cols} rows={models} rowKey="id" /></Card>
}

function Detail({ id }) {
  const { data: m, loading } = useAsync(() => getModel(id), [id], { enabled: !!id })
  if (!id) return <EmptyState title="No completed model" text="Train a model first." />
  if (loading || !m) return <Loader />
  const r = m.result
  const met = m.metrics
  return (
    <div className="stack">
      <Card title={m.name} sub={`Threshold ${met.threshold} (max-F1) · ${r.meta.train_rows.toLocaleString()} train / ${r.meta.test_rows.toLocaleString()} test rows · ${r.meta.train_seconds}s`}>
        <div className="grid g4" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(130px,1fr))' }}>
          {['roc_auc', 'pr_auc', 'accuracy', 'precision', 'recall', 'f1'].map((k) => <StatCard key={k} label={k.replace('_', '-').toUpperCase()} value={fmt.dec(met[k])} />)}
        </div>
      </Card>
      <div className="grid g3">
        <Card title="ROC curve" sub={`AUC ${fmt.dec(met.roc_auc)}`}><RocChart curves={[{ name: m.name, ...r.roc_curve }]} h={240} /></Card>
        <Card title="Precision–recall"><PrChart curves={[{ name: m.name, ...r.pr_curve }]} h={240} /></Card>
        <Card title="Confusion matrix" sub="On held-out test set"><ConfusionMatrix cm={r.confusion_matrix} /></Card>
      </div>
      <div className="grid g2">
        <Card title="What drives churn?" sub="Permutation importance — drop in ROC-AUC when a feature is shuffled"><HBar data={r.importance.slice(0, 12)} labelKey="feature" valueKey="importance" format={(v) => v.toFixed(3)} h={340} /></Card>
        <Card title="Threshold trade-off" sub="Pick the point that matches your retention capacity"><ThresholdChart rows={r.threshold_table} current={met.threshold} h={340} /></Card>
      </div>
      <Card title="Lift & cumulative capture by risk decile" sub="Top deciles should concentrate churners"><LiftChart rows={r.lift_table} /></Card>
    </div>
  )
}

function Compare({ ids }) {
  const { data, loading } = useAsync(() => compareModels(ids), [ids.join(',')], { enabled: ids.length > 0 })
  if (!ids.length) return <EmptyState title="Nothing to compare" text="Tick models in the Models tab (up to 4)." />
  if (loading || !data) return <Loader />
  return (
    <div className="stack">
      <div className="grid g2">
        <Card title="ROC curves"><RocChart curves={data.map((d) => ({ name: d.name, ...d.roc_curve }))} /></Card>
        <Card title="Precision–recall"><PrChart curves={data.map((d) => ({ name: d.name, ...d.pr_curve }))} /></Card>
      </div>
      <Card title="Metrics">
        <DataTable rows={data.map((d) => ({ ...d, ...d.metrics }))} rowKey="id" columns={[{ key: 'name', label: 'Model' }, ...['roc_auc', 'pr_auc', 'accuracy', 'precision', 'recall', 'f1', 'brier'].map((k) => ({ key: k, label: k, render: (v) => fmt.dec(v) })), { key: 'train_seconds', label: 'Train (s)' }]} />
      </Card>
    </div>
  )
}
