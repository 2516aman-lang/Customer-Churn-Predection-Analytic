"""Background training worker (thread pool; swap for Celery/RQ in larger deployments)."""
from __future__ import annotations

import logging
import traceback
from concurrent.futures import ThreadPoolExecutor

from ..core.config import settings
from ..database.models import Dataset, MLModel, now
from ..database.session import SessionLocal

from src.training import train_model

log = logging.getLogger("trainer")
_executor = ThreadPoolExecutor(max_workers=settings.TRAIN_WORKERS, thread_name_prefix="trainer")


def run_training(model_id: int) -> None:
    db = SessionLocal()
    try:
        m = db.get(MLModel, model_id)
        if not m:
            return
        m.status = "training"
        db.commit()
        ds = db.get(Dataset, m.dataset_id)
        from ..services.dataset_service import load_df

        df = load_df(ds)
        cfg = m.config
        res = train_model(
            df, ds.target, m.algorithm, settings.artifacts_dir, f"model_{m.id}",
            params=cfg.get("params"), id_columns=ds.id_columns, exclude_columns=cfg.get("exclude_columns"),
            test_size=cfg.get("test_size", 0.2), cv_folds=cfg.get("cv_folds", 3),
        )
        m.metrics = {**res["metrics"], "cv_roc_auc_mean": res["meta"]["cv_roc_auc_mean"], "threshold": res["threshold"]}
        m.result = {k: v for k, v in res.items() if k != "artifact_path"}
        m.artifact_path = res["artifact_path"]
        m.status = "completed"
        m.finished_at = now()
        if not db.query(MLModel).filter(MLModel.owner_id == m.owner_id, MLModel.is_active.is_(True)).first():
            m.is_active = True
        db.commit()
    except Exception as e:  # noqa: BLE001
        log.error("training failed: %s", traceback.format_exc())
        db.rollback()
        m = db.get(MLModel, model_id)
        if m:
            m.status, m.error, m.finished_at = "failed", str(e)[:500], now()
            db.commit()
    finally:
        db.close()


def submit(model_id: int) -> None:
    if settings.SYNC_TRAINING:
        run_training(model_id)
    else:
        _executor.submit(run_training, model_id)
