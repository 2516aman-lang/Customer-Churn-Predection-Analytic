"""Retention analytics: value-at-risk, driver-based segments, next-best-action rules, campaign ROI simulation."""
from __future__ import annotations

from collections import defaultdict

import numpy as np
import pandas as pd

from ..database.models import ScoringRun
from .common import find_revenue_col, to_records

# (predicate on lowercase feature + value, action, owner, lever)
RULES = [
    (lambda f, v: "contract" in f and str(v).lower() in {"month-to-month", "monthly", "month to month"},
     "Offer a discounted 12-month contract upgrade", "Sales", "Commitment"),
    (lambda f, v: "payment" in f and "check" in str(v).lower() or "payment" in f and "electronic" in str(v).lower(),
     "Incentivise auto-pay / bank-transfer enrolment (e.g. bill credit)", "Billing", "Friction"),
    (lambda f, v: "tenure" in f or "age_of_account" in f,
     "Enrol in early-life onboarding & loyalty nurture programme", "Customer Success", "Engagement"),
    (lambda f, v: any(k in f for k in ("monthlycharge", "monthly_charge", "charges", "price", "bill", "spend")),
     "Right-size plan or apply a loyalty price lock", "Pricing", "Price"),
    (lambda f, v: any(k in f for k in ("ticket", "complaint", "support_call", "calls", "issue")),
     "Priority support callback and root-cause resolution", "Support", "Service quality"),
    (lambda f, v: any(k in f for k in ("techsupport", "security", "backup", "protection")) and str(v).lower() == "no",
     "Bundle a free trial of tech-support / security add-ons", "Product", "Value"),
    (lambda f, v: "internet" in f or "fiber" in str(v).lower(),
     "Proactive service-quality check and speed/upgrade offer", "Network", "Service quality"),
    (lambda f, v: any(k in f for k in ("senior", "dependents", "partner")),
     "Targeted family / senior plan communication", "Marketing", "Fit"),
]
DEFAULT_ACTION = ("Personal outreach from an account manager", "Customer Success", "Engagement")


def recommend(drivers: list[dict]) -> dict:
    """Pick the strongest churn-increasing driver and map it to an action."""
    pos = [d for d in drivers if d.get("impact", 0) > 0]
    if not pos:
        return {"driver": None, "action": DEFAULT_ACTION[0], "owner": DEFAULT_ACTION[1], "lever": DEFAULT_ACTION[2]}
    d = pos[0]
    f = str(d["feature"]).lower()
    for pred, action, owner, lever in RULES:
        try:
            if pred(f, d.get("value")):
                return {"driver": d["feature"], "action": action, "owner": owner, "lever": lever}
        except Exception:  # noqa: BLE001
            continue
    return {"driver": d["feature"], "action": DEFAULT_ACTION[0], "owner": DEFAULT_ACTION[1], "lever": DEFAULT_ACTION[2]}


def _prep(df: pd.DataFrame, summary: dict, clv_months: int, default_monthly: float) -> pd.DataFrame:
    df = df.copy()
    rev = summary.get("revenue_column") or find_revenue_col(df)
    df["monthly_value"] = df[rev].astype(float) if rev else float(default_monthly)
    df["customer_value"] = df["monthly_value"] * clv_months
    df["expected_loss"] = (df["churn_probability"] * df["customer_value"]).round(2)
    rec = df["top_drivers"].map(recommend)
    df["primary_driver"] = rec.map(lambda r: r["driver"])
    df["recommended_action"] = rec.map(lambda r: r["action"])
    df["action_owner"] = rec.map(lambda r: r["owner"])
    df["lever"] = rec.map(lambda r: r["lever"])
    return df


def prepared(run: ScoringRun, df: pd.DataFrame, clv_months=12, default_monthly=60.0) -> pd.DataFrame:
    return _prep(df, run.summary or {}, clv_months, default_monthly)


def overview(df: pd.DataFrame) -> dict:
    tiers = []
    for t in ["Critical", "High", "Medium", "Low"]:
        g = df[df["risk_tier"] == t]
        tiers.append({"tier": t, "customers": int(len(g)),
                      "expected_loss": round(float(g["expected_loss"].sum()), 2),
                      "avg_probability": round(float(g["churn_probability"].mean()), 4) if len(g) else 0})
    drivers = defaultdict(lambda: {"customers": 0, "impact": 0.0})
    for ds in df.loc[df["predicted_churn"] == 1, "top_drivers"]:
        pos = [d for d in ds if d["impact"] > 0]
        if pos:
            drivers[pos[0]["feature"]]["customers"] += 1
            drivers[pos[0]["feature"]]["impact"] += pos[0]["impact"]
    drv = sorted(({"feature": k, "customers": v["customers"], "avg_impact": round(v["impact"] / v["customers"], 4)}
                  for k, v in drivers.items()), key=lambda r: -r["customers"])
    levers = (df[df["predicted_churn"] == 1].groupby("lever")["expected_loss"].agg(["count", "sum"]).reset_index()
              .rename(columns={"count": "customers", "sum": "expected_loss"}).sort_values("expected_loss", ascending=False))
    levers["expected_loss"] = levers["expected_loss"].round(2)
    return {
        "customers": int(len(df)),
        "predicted_churners": int(df["predicted_churn"].sum()),
        "total_expected_loss": round(float(df["expected_loss"].sum()), 2),
        "monthly_revenue_at_risk": round(float((df["churn_probability"] * df["monthly_value"]).sum()), 2),
        "tiers": tiers, "drivers": drv, "levers": to_records(levers),
    }


def recommendations(df: pd.DataFrame) -> list[dict]:
    g = df[df["predicted_churn"] == 1].groupby(["recommended_action", "action_owner", "lever"]).agg(
        customers=("churn_probability", "size"), avg_probability=("churn_probability", "mean"),
        expected_loss=("expected_loss", "sum")).reset_index().sort_values("expected_loss", ascending=False)
    g["avg_probability"] = g["avg_probability"].round(4)
    g["expected_loss"] = g["expected_loss"].round(2)
    return to_records(g)


def at_risk(df: pd.DataFrame, id_col: str | None, tier: str | None, limit: int, offset: int, sort: str = "expected_loss") -> dict:
    d = df if not tier or tier == "All" else df[df["risk_tier"] == tier]
    d = d.sort_values(sort if sort in d.columns else "expected_loss", ascending=False)
    total = len(d)
    page = d.iloc[offset: offset + limit]
    keep = ([id_col] if id_col and id_col in page.columns else []) + [
        "churn_probability", "risk_tier", "monthly_value", "expected_loss", "primary_driver", "recommended_action", "top_drivers"]
    rows = page[keep].copy()
    if not (id_col and id_col in rows.columns):
        rows.insert(0, "customer", page.index.astype(str))
    return {"total": int(total), "rows": to_records(rows), "id_column": id_col or "customer"}


def simulate(df: pd.DataFrame, budget: float, cost_per_contact: float, offer_cost_pct: float, success_rate: float,
             min_probability: float) -> dict:
    d = df[df["churn_probability"] >= min_probability].copy()
    # expected economics per contacted customer
    d["gain"] = d["churn_probability"] * success_rate * d["customer_value"]
    d["offer_cost"] = success_rate * (offer_cost_pct / 100.0) * d["customer_value"]
    d["cost"] = cost_per_contact + d["offer_cost"]
    d["net"] = d["gain"] - d["cost"]
    d = d[d["net"] > 0].sort_values("net", ascending=False)
    d["cum_cost"] = d["cost"].cumsum()
    chosen = d[d["cum_cost"] <= budget] if budget > 0 else d.iloc[0:0]
    n = len(chosen)
    curve = []
    if n:
        cn = chosen["net"].cumsum().to_numpy()
        for i in np.unique(np.linspace(0, n - 1, min(n, 40)).astype(int)):
            curve.append({"contacted": int(i + 1), "cumulative_net": round(float(cn[i]), 2)})
    cost, gain = float(chosen["cost"].sum()), float(chosen["gain"].sum())
    return {
        "eligible": int(len(d)), "contacted": int(n),
        "expected_customers_saved": round(float((chosen["churn_probability"] * success_rate).sum()), 1),
        "revenue_saved": round(gain, 2), "campaign_cost": round(cost, 2),
        "net_benefit": round(gain - cost, 2), "roi": round((gain - cost) / cost, 3) if cost else 0,
        "budget_used_pct": round(cost / budget, 4) if budget else 0, "curve": curve,
    }
