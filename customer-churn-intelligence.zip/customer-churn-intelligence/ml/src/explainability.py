"""Model-agnostic explainability: permutation importance (global) and counterfactual-baseline
contributions (local). No SHAP dependency; works with any sklearn Pipeline exposing predict_proba."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance


def global_importance(pipeline, X: pd.DataFrame, y, n_repeats: int = 5, max_rows: int = 1500, seed: int = 42) -> list[dict]:
    if len(X) > max_rows:
        idx = np.random.default_rng(seed).choice(len(X), max_rows, replace=False)
        X, y = X.iloc[idx], np.asarray(y)[idx]
    res = permutation_importance(
        pipeline, X, y, scoring="roc_auc", n_repeats=n_repeats, random_state=seed, n_jobs=1
    )
    rows = [
        {"feature": str(c), "importance": round(float(m), 5), "std": round(float(s), 5)}
        for c, m, s in zip(X.columns, res.importances_mean, res.importances_std)
    ]
    return sorted(rows, key=lambda r: r["importance"], reverse=True)


def baselines(X: pd.DataFrame) -> dict:
    base = {}
    for c in X.columns:
        if pd.api.types.is_numeric_dtype(X[c]):
            base[c] = float(X[c].median())
        else:
            m = X[c].mode(dropna=True)
            base[c] = m.iloc[0] if len(m) else "Unknown"
    return base


def local_contributions(pipeline, row: pd.DataFrame, base: dict, top_k: int = 5) -> list[dict]:
    """Change in churn probability when each feature is replaced by its typical (baseline) value.
    Positive = pushes this customer toward churn."""
    p0 = float(pipeline.predict_proba(row)[0, 1])
    out = []
    for c in row.columns:
        if c not in base:
            continue
        alt = row.copy()
        alt[c] = base[c]
        delta = p0 - float(pipeline.predict_proba(alt)[0, 1])
        out.append({"feature": str(c), "value": _py(row.iloc[0][c]), "impact": round(delta, 4)})
    out.sort(key=lambda r: abs(r["impact"]), reverse=True)
    return out[:top_k]


def batch_top_drivers(pipeline, X: pd.DataFrame, base: dict, top_k: int = 3) -> list[list[dict]]:
    """Vectorised version: one scoring pass per feature across the whole frame."""
    p0 = pipeline.predict_proba(X)[:, 1]
    deltas = {}
    for c in X.columns:
        if c not in base:
            continue
        alt = X.copy()
        alt[c] = base[c]
        deltas[c] = p0 - pipeline.predict_proba(alt)[:, 1]
    D = pd.DataFrame(deltas, index=X.index)
    out = []
    for i in range(len(X)):
        r = D.iloc[i]
        top = r.reindex(r.abs().sort_values(ascending=False).index).head(top_k)
        out.append([
            {"feature": str(f), "value": _py(X.iloc[i][f]), "impact": round(float(v), 4)} for f, v in top.items()
        ])
    return out


def _py(v):
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return None if np.isnan(v) else round(float(v), 4)
    if pd.isna(v):
        return None
    return v
