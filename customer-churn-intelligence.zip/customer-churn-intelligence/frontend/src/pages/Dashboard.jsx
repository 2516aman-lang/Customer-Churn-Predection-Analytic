import { useNavigate } from 'react-router-dom'
import { Database, Sparkles } from 'lucide-react'
import { getDashboard, createSample } from '../api/datasets'
import { Button, Card, EmptyState, ErrorBox, Loader, PageHeader, StatCard, fmt, TIER_COLORS } from '../components/common'
import { Donut, HBar, ProbHistogram, RateBars } from '../components/charts'
import { useApp } from '../context/AppContext'
import { useAction } from '../hooks/useAction'
import { useAsync } from '../hooks/useAsync'

const STEPS = [
  ['Add data', '/datasets', 'Upload a CSV or load the sample'],
  ['Clean & validate', '/datasets', 'Fix types, duplicates, missing values'],
  ['Explore', '/eda', 'See who churns and why'],
  ['Train models', '/models', 'Compare algorithms'],
  ['Score customers', '/predictions', 'Batch or single predictions'],
  ['Retain', '/retention', 'Actions and ROI'],
]

export default function Dashboard() {
  const { datasetId, datasets, refresh, setDatasetId } = useApp()
  const nav = useNavigate()
  const { data, loading, error } = useAsync(() => getDashboard(datasetId), [datasetId], { enabled: true })
  const [sample, busy] = useAction(async () => { const d = await createSample(3000); await refresh(); setDatasetId(d.id) }, { success: 'Sample dataset loaded' })

  if (loading && !data) return <Loader />
  const ov = data?.overview
  const run = data?.latest_run?.summary
  const model = data?.active_model

  return (
    <>
      <PageHeader title="Dashboard" subtitle="Where churn stands, how well we can predict it, and what to do about it." />
      <ErrorBox error={error} />
      {!datasets.length ? (
        <Card>
          <EmptyState title="Start with some customer data" text="Upload your own file, or load a synthetic telecom dataset to explore the platform.">
            <div className="row" style={{ justifyContent: 'center', marginTop: 12 }}>
              <Button variant="primary" icon={Database} onClick={() => nav('/datasets')}>Upload data</Button>
              <Button icon={Sparkles} busy={busy} onClick={sample}>Load sample dataset</Button>
            </div>
          </EmptyState>
        </Card>
      ) : (
        <div className="stack">
          <div className="grid g4">
            <StatCard label="Customers" value={fmt.num(ov?.rows)} hint={data?.dataset?.name} />
            <StatCard label="Churn rate" value={fmt.pct(ov?.churn_rate)} tone="bad" hint={`${fmt.num(ov?.churned)} churned`} />
            <StatCard label="Monthly revenue lost" value={ov?.monthly_revenue_churned != null ? fmt.money(ov.monthly_revenue_churned) : '—'} tone="bad" hint={ov?.revenue_column ? `from ${ov.revenue_column}` : 'no revenue column found'} />
            <StatCard label="Avg tenure" value={ov?.avg_tenure != null ? `${ov.avg_tenure} mo` : '—'} hint={`${data?.counts.models} trained models · ${data?.counts.runs} scoring runs`} />
          </div>

          <div className="grid g-wide">
            <Card title="Where churn concentrates" sub="Highest-spread categories in the selected dataset">
              {data?.top_segments?.length ? (
                <div className="grid g3">
                  {data.top_segments.map((s) => (
                    <div key={s.column}><div className="small muted" style={{ marginBottom: 4 }}>{s.column}</div><RateBars data={s.values} h={190} avg={ov?.churn_rate} /></div>
                  ))}
                </div>
              ) : <EmptyState title="No target set" text="Choose the churn column on the Datasets page." />}
            </Card>
            <Card title="Pipeline" sub="Your path from data to retention">
              <div className="stack" style={{ gap: 10 }}>
                {STEPS.map(([t, to, d], i) => (
                  <div key={t} className="row" style={{ cursor: 'pointer', flexWrap: 'nowrap' }} onClick={() => nav(to)}>
                    <span className="badge info">{i + 1}</span><div><b>{t}</b><div className="small muted">{d}</div></div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          <div className="grid g2">
            <Card title={model ? `Active model · ${model.name}` : 'Active model'} sub={model ? `ROC-AUC ${fmt.dec(model.metrics.roc_auc)} · recall ${fmt.pct(model.metrics.recall)} · precision ${fmt.pct(model.metrics.precision)}` : undefined}>
              {model ? <HBar data={model.importance} labelKey="feature" valueKey="importance" format={(v) => v.toFixed(3)} h={260} />
                : <EmptyState title="No trained model" text="Train a model in Model Studio to see churn drivers here." />}
            </Card>
            <Card title="Latest risk scoring" sub={data?.latest_run?.name}>
              {run ? (
                <div className="grid g2">
                  <Donut data={Object.entries(run.tiers).map(([name, value]) => ({ name, value }))} colors={TIER_COLORS} center={<div style={{ textAlign: 'center' }}><div style={{ fontSize: 22, fontWeight: 700 }}>{fmt.num(run.rows)}</div><div className="small muted">scored</div></div>} />
                  <div>
                    <div className="small muted">Probability distribution</div><ProbHistogram counts={run.histogram} h={170} />
                    <div className="small muted" style={{ marginTop: 8 }}>Predicted churners: <b>{fmt.num(run.predicted_churners)}</b>{run.expected_monthly_revenue_at_risk != null && <> · Monthly revenue at risk: <b>{fmt.money(run.expected_monthly_revenue_at_risk)}</b></>}</div>
                  </div>
                </div>
              ) : <EmptyState title="Nothing scored yet" text="Score a dataset on the Predictions page." />}
            </Card>
          </div>
        </div>
      )}
    </>
  )
}
