import { useEffect, useState } from 'react'
import { Download, Eraser, RefreshCcw, Sparkles, Trash2 } from 'lucide-react'
import { download } from '../api/client'
import { cleanDataset, createSample, deleteDataset, previewDataset, replaceData, updateDataset, uploadDataset } from '../api/datasets'
import { Badge, Button, Card, EmptyState, FileDrop, Loader, PageHeader, Select, StatCard, Tabs, fmt } from '../components/common'
import DataTable from '../components/tables/DataTable'
import { useApp } from '../context/AppContext'
import { useAction } from '../hooks/useAction'
import { useAsync } from '../hooks/useAsync'

export default function Datasets() {
  const { datasets, dataset, setDatasetId, refresh, toast } = useApp()
  const [tab, setTab] = useState('quality')
  const [upload, uploading] = useAction(async (f) => { const d = await uploadDataset(f); await refresh(); setDatasetId(d.id); setTab('quality') }, { success: 'Dataset uploaded and validated' })
  const [sample, sampling] = useAction(async () => { const d = await createSample(3000); await refresh(); setDatasetId(d.id) }, { success: 'Sample dataset created' })
  const [remove] = useAction(async (id) => { await deleteDataset(id); await refresh() }, { success: 'Dataset deleted' })

  return (
    <>
      <PageHeader title="Datasets" subtitle="Upload, validate and clean customer data before modelling.">
        <Button icon={Sparkles} busy={sampling} onClick={sample}>Load sample data</Button>
      </PageHeader>
      <div className="stack">
        <div className="grid g-wide">
          <Card title="Upload"><FileDrop onFile={upload} busy={uploading} /></Card>
          <Card title="Your datasets">
            {!datasets.length ? <div className="muted">None yet.</div> : (
              <div className="stack" style={{ gap: 8 }}>
                {datasets.map((d) => (
                  <div key={d.id} className="row" style={{ justifyContent: 'space-between', flexWrap: 'nowrap', padding: 8, borderRadius: 8, cursor: 'pointer', background: d.id === dataset?.id ? 'var(--accent-soft)' : 'transparent' }} onClick={() => setDatasetId(d.id)}>
                    <div style={{ minWidth: 0 }}><b>{d.name}</b><div className="small muted">{fmt.num(d.rows)} rows · {d.columns} cols</div></div>
                    <div className="row" style={{ flexWrap: 'nowrap' }}>
                      <Badge kind={d.status} />
                      <Button size="sm" variant="ghost" icon={Trash2} onClick={(e) => { e.stopPropagation(); if (confirm(`Delete "${d.name}"?`)) remove(d.id) }} aria-label="Delete" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        {dataset ? (
          <div>
            <RefreshRow ds={dataset} refresh={refresh} />
            <Tabs value={tab} onChange={setTab} tabs={[{ key: 'quality', label: 'Quality' }, { key: 'configure', label: 'Configure' }, { key: 'clean', label: 'Clean' }, { key: 'preview', label: 'Preview' }]} />
            {tab === 'quality' && <Quality ds={dataset} />}
            {tab === 'configure' && <Configure ds={dataset} refresh={refresh} />}
            {tab === 'clean' && <Clean ds={dataset} refresh={refresh} />}
            {tab === 'preview' && <Preview ds={dataset} />}
          </div>
        ) : <Card><EmptyState title="No dataset selected" text="Upload a file or load the sample dataset to begin." /></Card>}
      </div>
    </>
  )
}

function Quality({ ds }) {
  const v = ds.validation
  if (!v) return <Loader />
  return (
    <div className="stack">
      <div className="grid g4">
        <StatCard label="Quality score" value={`${v.quality_score}/100`} tone={v.quality_score >= 80 ? 'good' : 'bad'} hint={v.is_valid ? 'Ready for modelling' : 'Blocking issues found'} />
        <StatCard label="Rows × columns" value={`${fmt.num(v.rows)} × ${v.columns}`} />
        <StatCard label="Duplicate rows" value={fmt.num(v.duplicates)} />
        <StatCard label="Churn rate" value={fmt.pct(v.imbalance?.churn_rate)} hint={v.imbalance ? `${fmt.num(v.imbalance.positives)} churned` : 'Select a target'} />
      </div>
      <div className="grid g-wide">
        <Card title="Issues & recommendations">
          {v.issues.length === 0 ? <div className="alert">No issues detected 🎉</div> : (
            <div className="stack" style={{ gap: 8 }}>
              {[...v.issues].sort((a, b) => ['error', 'warning', 'info'].indexOf(a.severity) - ['error', 'warning', 'info'].indexOf(b.severity)).map((i, k) => (
                <div key={k} className="row" style={{ flexWrap: 'nowrap', alignItems: 'flex-start' }}><Badge kind={i.severity} /><span>{i.message}</span></div>
              ))}
            </div>
          )}
        </Card>
        <Card title="Column profile">
          <div className="table-wrap" style={{ maxHeight: 360 }}>
            <table><thead><tr><th>Column</th><th>Type</th><th>Missing</th><th>Unique</th></tr></thead>
              <tbody>{v.profile.map((c) => <tr key={c.name}><td>{c.name}</td><td>{c.kind}</td><td>{c.missing_pct}%</td><td>{c.unique}</td></tr>)}</tbody></table>
          </div>
        </Card>
      </div>
    </div>
  )
}

function Configure({ ds, refresh }) {
  const cols = ds.validation?.profile?.map((c) => c.name) || []
  const [target, setTarget] = useState(ds.target || '')
  const [ids, setIds] = useState(ds.id_columns || [])
  useEffect(() => { setTarget(ds.target || ''); setIds(ds.id_columns || []) }, [ds.id])
  const [save, busy] = useAction(async () => { await updateDataset(ds.id, { target, id_columns: ids }); await refresh() }, { success: 'Configuration saved. Re-run cleaning if you changed the target.' })
  return (
    <Card title="Target & identifiers" sub="The target is the churn label. Identifier columns are excluded from modelling.">
      <div className="stack" style={{ maxWidth: 520 }}>
        <Select label="Churn (target) column" value={target} onChange={setTarget} options={cols} placeholder="Select…" help="Yes/No, True/False, 1/0 and Churned/Retained labels are understood." />
        <div className="field"><label>Identifier columns (excluded)</label>
          <div className="row">{cols.filter((c) => c !== target).map((c) => (
            <label key={c} className="row" style={{ gap: 5, fontWeight: 400, color: 'var(--text)' }}>
              <input type="checkbox" style={{ width: 'auto' }} checked={ids.includes(c)} onChange={(e) => setIds(e.target.checked ? [...ids, c] : ids.filter((x) => x !== c))} />{c}
            </label>
          ))}</div>
        </div>
        <Button variant="primary" busy={busy} onClick={save} disabled={!target}>Save</Button>
      </div>
    </Card>
  )
}

function Clean({ ds, refresh }) {
  const [opt, setOpt] = useState({ drop_duplicates: true, cap_outliers: true, impute: true })
  const [run, busy] = useAction(async () => { await cleanDataset(ds.id, opt); await refresh() }, { success: 'Dataset cleaned' })
  const r = ds.cleaning_report
  return (
    <div className="grid g2">
      <Card title="Cleaning pipeline" sub="Coerces numeric-looking text, normalises the target to 0/1, then applies the options below.">
        <div className="stack">
          {[['drop_duplicates', 'Remove duplicate rows'], ['impute', 'Impute missing values (median / mode)'], ['cap_outliers', 'Cap extreme outliers (3×IQR)']].map(([k, l]) => (
            <label key={k} className="row" style={{ gap: 8 }}><input type="checkbox" style={{ width: 'auto' }} checked={opt[k]} onChange={(e) => setOpt({ ...opt, [k]: e.target.checked })} />{l}</label>
          ))}
          <div className="row">
            <Button variant="primary" icon={Eraser} busy={busy} onClick={run} disabled={!ds.target}>{ds.status === 'cleaned' ? 'Re-run cleaning' : 'Clean dataset'}</Button>
            {ds.status === 'cleaned' && <Button icon={Download} onClick={() => download(`/datasets/${ds.id}/download`, `${ds.name}_clean.csv`)}>Download cleaned CSV</Button>}
          </div>
          {!ds.target && <div className="alert warn">Choose a target column on the Configure tab first.</div>}
        </div>
      </Card>
      <Card title="Cleaning report">
        {!r ? <div className="muted">Not cleaned yet. Models can only be trained on cleaned datasets.</div> : (
          <dl className="kv">
            <dt>Rows before → after</dt><dd>{fmt.num(r.rows_before)} → {fmt.num(r.rows_after)}</dd>
            <dt>Duplicates removed</dt><dd>{r.duplicates_removed}</dd>
            <dt>Rows missing target dropped</dt><dd>{r.dropped_rows_missing_target}</dd>
            <dt>Converted to numeric</dt><dd>{r.coerced_numeric.join(', ') || '—'}</dd>
            <dt>Imputed</dt><dd>{Object.entries(r.imputed).map(([c, v]) => `${c} (${v.count}, ${v.strategy})`).join('; ') || '—'}</dd>
            <dt>Outliers capped</dt><dd>{Object.entries(r.capped_outliers).map(([c, n]) => `${c} (${n})`).join('; ') || '—'}</dd>
          </dl>
        )}
      </Card>
    </div>
  )
}

function Preview({ ds }) {
  const [offset, setOffset] = useState(0)
  const [version, setVersion] = useState('auto')
  useEffect(() => setOffset(0), [ds.id, version])
  const { data, loading } = useAsync(() => previewDataset(ds.id, { rows: 15, offset, version }), [ds.id, offset, version, ds.status])
  return (
    <Card title="Data preview" actions={ds.status === 'cleaned' && <select style={{ width: 'auto' }} value={version} onChange={(e) => setVersion(e.target.value)}><option value="auto">Cleaned</option><option value="raw">Raw</option></select>}>
      {loading && !data ? <Loader /> : data && <DataTable columns={data.columns.map((c) => ({ key: c }))} rows={data.rows} total={data.total} offset={offset} limit={15} onPage={setOffset} />}
    </Card>
  )
}

function RefreshRow({ ds, refresh }) {
  const [go, busy] = useAction(async (f) => { await replaceData(ds.id, f); await refresh() }, { success: 'Data refreshed — scheduled runs will use it' })
  return (
    <div className="row" style={{ marginBottom: 12 }}>
      <label className="btn sm" style={{ cursor: 'pointer' }}>
        <RefreshCcw size={14} className={busy ? 'spin' : ''} /> Replace data with a newer file
        <input type="file" accept=".csv,.xlsx,.xls,.tsv" hidden onChange={(e) => { e.target.files[0] && go(e.target.files[0]); e.target.value = '' }} />
      </label>
      <span className="small muted">Keeps target and ID settings; re-cleans automatically. Must contain the same columns.</span>
    </div>
  )
}
