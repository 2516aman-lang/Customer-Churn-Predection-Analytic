import { LogOut } from 'lucide-react'
import { useApp } from '../../context/AppContext'
import { useAuth } from '../../context/AuthContext'

export default function Navbar() {
  const { datasets, datasetId, setDatasetId, activeModel } = useApp()
  const { user, logout } = useAuth()
  return (
    <header className="navbar">
      <span className="muted small">Dataset</span>
      <select value={datasetId ?? ''} onChange={(e) => setDatasetId(Number(e.target.value))} disabled={!datasets.length}>
        {!datasets.length && <option value="">No datasets yet</option>}
        {datasets.map((d) => <option key={d.id} value={d.id}>{d.name} · {d.rows.toLocaleString()} rows</option>)}
      </select>
      {activeModel && <span className="badge info" title="Active model used for scoring">Active model: {activeModel.name}</span>}
      <span className="spacer" />
      <span className="muted small">{user?.name || user?.email}</span>
      <button className="btn sm ghost" onClick={logout} title="Sign out"><LogOut size={15} /> Sign out</button>
    </header>
  )
}
