import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "ml"))

import numpy as np
import pandas as pd

from src.cleaning import clean_dataframe, normalize_target
from src.evaluation import evaluate, lift_table
from src.sample_data import generate_sample
from src.validation import validate_dataset


def test_normalize_target():
    s = normalize_target(pd.Series(["Yes", "no", "TRUE", 0, 1, "Churned", None]))
    assert s.dropna().tolist() == [1, 0, 1, 0, 1, 1]


def test_clean_fixes_blank_numeric_and_dupes():
    df = generate_sample(800)
    out, rep = clean_dataframe(df, "Churn", id_columns=["customerID"])
    assert pd.api.types.is_numeric_dtype(out["TotalCharges"]) and out.isna().sum().sum() == 0
    assert rep["duplicates_removed"] > 0 and set(out["Churn"].unique()) <= {0, 1}


def test_validation_flags_problems():
    v = validate_dataset(generate_sample(800), "Churn")
    codes = {i["code"] for i in v["issues"]}
    assert {"duplicates", "missing", "id_column"} <= codes
    tiny = validate_dataset(pd.DataFrame({"a": [1, 2], "Churn": ["Yes", "No"]}), "Churn")
    assert not tiny["is_valid"]


def test_evaluate_perfect_and_lift():
    y = np.array([0] * 50 + [1] * 50)
    p = np.concatenate([np.linspace(0, 0.4, 50), np.linspace(0.6, 1, 50)])
    ev = evaluate(y, p)
    assert ev["metrics"]["roc_auc"] == 1.0
    lt = lift_table(y, p)
    assert lt[0]["lift"] == 2.0 and lt[-1]["cum_capture"] == 1.0
