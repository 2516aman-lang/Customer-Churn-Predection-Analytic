from __future__ import annotations

import io
from pathlib import Path

import pandas as pd
from sqlalchemy.orm import Session

from ..core.config import settings
from ..database.models import Dataset, User
from .common import safe_name

from src.cleaning import clean_dataframe  # noqa: E402  (ml package on sys.path via config)
from src.sample_data import generate_sample
from src.validation import validate_dataset


def read_upload(filename: str, content: bytes) -> pd.DataFrame:
    if len(content) > settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise ValueError(f"File exceeds {settings.MAX_UPLOAD_MB} MB limit")
    low = filename.lower()
    if low.endswith((".xlsx", ".xls")):
        df = pd.read_excel(io.BytesIO(content))
    elif low.endswith((".csv", ".txt", ".tsv")):
        df = pd.read_csv(io.BytesIO(content), sep=None, engine="python")
    else:
        raise ValueError("Unsupported file type. Upload a CSV or Excel file.")
    if df.empty:
        raise ValueError("The uploaded file contains no rows")
    return df


def create_dataset(db: Session, user: User, name: str, filename: str, df: pd.DataFrame) -> Dataset:
    ds = Dataset(owner_id=user.id, name=name, filename=filename, raw_path="", rows=len(df), columns=df.shape[1])
    db.add(ds)
    db.flush()
    path = settings.raw_dir / f"{ds.id}_{safe_name(Path(filename).stem)}.csv"
    df.to_csv(path, index=False)
    ds.raw_path = str(path)
    ds.validation = validate_dataset(df)
    ds.target = ds.validation["suggested_target"]
    ds.id_columns = ds.validation["suggested_id_columns"]
    if ds.target:  # re-validate with target for imbalance info
        ds.validation = validate_dataset(df, ds.target)
    db.commit()
    db.refresh(ds)
    return ds


def create_sample(db: Session, user: User, rows: int, seed: int) -> Dataset:
    df = generate_sample(rows, seed)
    return create_dataset(db, user, f"Sample telco churn ({rows} rows)", "sample_telco_churn.csv", df)


def load_df(ds: Dataset, prefer_clean: bool = True) -> pd.DataFrame:
    if prefer_clean and ds.clean_path and Path(ds.clean_path).exists():
        return pd.read_csv(ds.clean_path)
    return pd.read_csv(ds.raw_path)


def revalidate(db: Session, ds: Dataset):
    df = load_df(ds, prefer_clean=False)
    ds.validation = validate_dataset(df, ds.target)
    db.commit()
    return ds


def clean(db: Session, ds: Dataset, drop_duplicates=True, cap_outliers=True, impute=True) -> Dataset:
    if not ds.target:
        raise ValueError("Select a target column before cleaning")
    raw = load_df(ds, prefer_clean=False)
    cleaned, report = clean_dataframe(
        raw, ds.target, drop_duplicates=drop_duplicates, cap_outliers=cap_outliers, impute=impute, id_columns=ds.id_columns
    )
    path = settings.processed_dir / f"{ds.id}_clean.csv"
    cleaned.to_csv(path, index=False)
    ds.clean_path = str(path)
    ds.status = "cleaned"
    ds.cleaning_report = report
    ds.rows, ds.columns = cleaned.shape
    db.commit()
    db.refresh(ds)
    return ds


def delete_files(ds: Dataset):
    for p in (ds.raw_path, ds.clean_path):
        if p:
            Path(p).unlink(missing_ok=True)


def replace_data(db: Session, ds: Dataset, df: pd.DataFrame) -> Dataset:
    """Swap in fresh data (e.g. this month's customer extract) keeping target/ID config.
    The new file must contain the original columns; a cleaned dataset is re-cleaned automatically."""
    old = load_df(ds, prefer_clean=False)
    missing = [c for c in old.columns if c not in df.columns and c != ds.target]
    if missing:
        raise ValueError(f"New data is missing columns: {', '.join(map(str, missing[:8]))}")
    df.to_csv(ds.raw_path, index=False)
    ds.rows, ds.columns = len(df), df.shape[1]
    ds.validation = validate_dataset(df, ds.target if ds.target in df.columns else None)
    db.commit()
    if ds.status == "cleaned" and ds.target in df.columns:
        return clean(db, ds)
    ds.status, ds.clean_path = "raw", None
    db.commit()
    db.refresh(ds)
    return ds
