import client, { data } from './client'
export const listDatasets = () => data(client.get('/datasets'))
export const getDataset = (id) => data(client.get(`/datasets/${id}`))
export const uploadDataset = (file) => {
  const f = new FormData()
  f.append('file', file)
  return data(client.post('/datasets/upload', f))
}
export const createSample = (rows = 3000) => data(client.post('/datasets/sample', { rows }))
export const updateDataset = (id, body) => data(client.patch(`/datasets/${id}`, body))
export const previewDataset = (id, params) => data(client.get(`/datasets/${id}/preview`, { params }))
export const cleanDataset = (id, body = {}) => data(client.post(`/datasets/${id}/clean`, body))
export const deleteDataset = (id) => client.delete(`/datasets/${id}`)
export const getEda = (id) => data(client.get(`/analytics/datasets/${id}/eda`))
export const getSegments = (id, by) => data(client.get(`/analytics/datasets/${id}/segments`, { params: { by } }))
export const getDashboard = (dataset_id) => data(client.get('/analytics/dashboard', { params: { dataset_id } }))
export const replaceData = (id, file) => {
  const f = new FormData()
  f.append('file', file)
  return data(client.put(`/datasets/${id}/data`, f))
}
