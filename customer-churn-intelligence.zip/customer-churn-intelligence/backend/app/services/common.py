from __future__ import annotations

import json
import re

import pandas as pd


def to_records(df: pd.DataFrame) -> list[dict]:
    """JSON-safe records (NaN -> null, numpy -> python)."""
    return json.loads(df.to_json(orient="records", date_format="iso"))


def safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._") or "file"


def find_revenue_col(df: pd.DataFrame) -> str | None:
    cols = list(df.columns)
    for c in cols:
        low = str(c).lower().replace("_", "").replace(" ", "")
        if "monthly" in low and ("charge" in low or "revenue" in low or "fee" in low or "spend" in low):
            if pd.api.types.is_numeric_dtype(df[c]):
                return c
    for c in cols:
        low = str(c).lower().replace("_", "").replace(" ", "")
        if low in {"mrr", "arpu", "revenue", "monthlyrevenue", "monthlyspend"} and pd.api.types.is_numeric_dtype(df[c]):
            return c
    return None
