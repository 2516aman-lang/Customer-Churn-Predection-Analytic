from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from ..core.config import settings

_args = {"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(settings.DATABASE_URL, connect_args=_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Bring the schema up to date. Uses Alembic; adopts pre-migration databases (created via create_all) by stamping 0001."""
    from pathlib import Path

    from sqlalchemy import inspect

    from . import models  # noqa: F401

    ini = Path(__file__).resolve().parents[2] / "alembic.ini"
    if not settings.AUTO_MIGRATE or not ini.exists():
        Base.metadata.create_all(bind=engine)
        return
    from alembic import command
    from alembic.config import Config

    cfg = Config(str(ini))
    tables = set(inspect(engine).get_table_names())
    if "users" in tables and "alembic_version" not in tables:
        command.stamp(cfg, "0001")  # legacy database: baseline already present
    command.upgrade(cfg, "head")
