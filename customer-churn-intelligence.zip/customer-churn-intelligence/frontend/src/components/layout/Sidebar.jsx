import { NavLink } from 'react-router-dom'
import { BarChart3, CalendarClock, Boxes, Database, FileText, HeartHandshake, LayoutDashboard, LineChart, Sparkles } from 'lucide-react'

export const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/datasets', label: 'Datasets', icon: Database },
  { to: '/eda', label: 'Exploration', icon: BarChart3 },
  { to: '/models', label: 'Model Studio', icon: Boxes },
  { to: '/predictions', label: 'Predictions', icon: Sparkles },
  { to: '/retention', label: 'Retention', icon: HeartHandshake },
  { to: '/automation', label: 'Automation', icon: CalendarClock },
  { to: '/reports', label: 'Reports', icon: FileText },
]

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark"><LineChart size={17} color="#fff" /></span>Churn Intelligence</div>
      {NAV.map(({ to, label, icon: Icon, end }) => (
        <NavLink key={to} to={to} end={end} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <Icon size={17} />{label}
        </NavLink>
      ))}
      <div className="sidebar-foot">v1.0 · predict · explain · retain</div>
    </aside>
  )
}
