import client, { data } from './client'
export const getSchema = (modelId) => data(client.get(`/predictions/schema/${modelId}`))
export const predictSingle = (body) => data(client.post('/predictions/single', body))
export const whatIf = (body) => data(client.post('/predictions/whatif', body))
export const batchFromDataset = (body) => data(client.post('/predictions/batch/dataset', body))
export const batchUpload = (modelId, file) => {
  const f = new FormData()
  f.append('model_id', modelId)
  f.append('file', file)
  return data(client.post('/predictions/batch', f))
}
export const listRuns = () => data(client.get('/predictions/runs'))
export const getRun = (id, params) => data(client.get(`/predictions/runs/${id}`, { params }))
export const deleteRun = (id) => client.delete(`/predictions/runs/${id}`)
// retention
export const retentionOverview = (id, clv_months) => data(client.get(`/retention/${id}/overview`, { params: { clv_months } }))
export const retentionCustomers = (id, params) => data(client.get(`/retention/${id}/customers`, { params }))
export const retentionRecs = (id, clv_months) => data(client.get(`/retention/${id}/recommendations`, { params: { clv_months } }))
export const simulateCampaign = (id, body) => data(client.post(`/retention/${id}/simulate`, body))
// reports
export const listReports = () => data(client.get('/reports'))
export const createReport = (body) => data(client.post('/reports', body))
export const deleteReport = (id) => client.delete(`/reports/${id}`)
// export
export const exportConfig = () => data(client.get('/retention/export/config'))
export const exportEmail = (id, body) => data(client.post(`/retention/${id}/export/email`, body))
export const exportWebhook = (id, body) => data(client.post(`/retention/${id}/export/webhook`, body))
