from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ...core.security import create_access_token, hash_password, verify_password
from ...database.models import User
from ...database.session import get_db
from ...schemas import LoginIn, RegisterIn, TokenOut, UserOut
from ..deps import current_user

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=TokenOut, status_code=201)
def register(body: RegisterIn, db: Session = Depends(get_db)):
    email = body.email.lower().strip()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(409, "Email already registered")
    u = User(email=email, name=body.name or email.split("@")[0], hashed_password=hash_password(body.password))
    db.add(u)
    db.commit()
    return TokenOut(access_token=create_access_token(str(u.id)), user=UserOut.model_validate(u))


@router.post("/login", response_model=TokenOut)
def login(body: LoginIn, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.email == body.email.lower().strip()).first()
    if not u or not verify_password(body.password, u.hashed_password):
        raise HTTPException(401, "Incorrect email or password")
    return TokenOut(access_token=create_access_token(str(u.id)), user=UserOut.model_validate(u))


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user
