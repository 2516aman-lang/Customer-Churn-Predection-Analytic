from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ...database.models import Dataset, MLModel, ScoringRun, User
from ...database.session import get_db
from ...services import analytics_service as svc
from ...services import dataset_service
from ..deps import current_user, get_dataset

router = APIRouter(prefix="/analytics", tags=["analytics"])


def _ready(ds: Dataset):
    if not ds.target:
        raise HTTPException(400, "Set a target column for this dataset first")
    return dataset_service.load_df(ds)


@router.get("/dashboard")
def dashboard(dataset_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = db.query(Dataset).filter(Dataset.owner_id == user.id)
    ds = get_dataset(db, dataset_id, user) if dataset_id else q.order_by(Dataset.id.desc()).first()
    model = db.query(MLModel).filter(MLModel.owner_id == user.id, MLModel.is_active.is_(True)).first()
    runs = db.query(ScoringRun).filter(ScoringRun.owner_id == user.id).order_by(ScoringRun.id.desc())
    # prefer the active model's latest run, otherwise the latest run of any model
    run = (runs.filter(ScoringRun.model_id == model.id).first() if model else None) or runs.first()
    out = {
        "counts": {
            "datasets": q.count(),
            "models": db.query(MLModel).filter(MLModel.owner_id == user.id, MLModel.status == "completed").count(),
            "runs": db.query(ScoringRun).filter(ScoringRun.owner_id == user.id).count(),
        },
        "dataset": None, "overview": None, "active_model": None, "latest_run": None, "top_segments": [],
    }
    if ds:
        out["dataset"] = {"id": ds.id, "name": ds.name, "status": ds.status}
        df = dataset_service.load_df(ds)
        out["overview"] = svc.overview(df, ds.target)
        if ds.target:
            e = svc.eda(df, ds.target, ds.id_columns)
            out["top_segments"] = [{"column": c["column"], "values": c["values"]} for c in e["categorical"][:3]]
    if model:
        out["active_model"] = {"id": model.id, "name": model.name, "algorithm": model.algorithm, "metrics": model.metrics,
                               "importance": (model.result or {}).get("importance", [])[:8]}
    if run:
        out["latest_run"] = {"id": run.id, "name": run.name, "summary": run.summary, "created_at": run.created_at}
    return out


@router.get("/datasets/{dataset_id}/eda")
def eda(dataset_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    ds = get_dataset(db, dataset_id, user)
    return svc.eda(_ready(ds), ds.target, ds.id_columns)


@router.get("/datasets/{dataset_id}/segments")
def segments(dataset_id: int, by: str = Query(...), db: Session = Depends(get_db), user: User = Depends(current_user)):
    ds = get_dataset(db, dataset_id, user)
    df = _ready(ds)
    if by not in df.columns:
        raise HTTPException(400, f"Unknown column '{by}'")
    return svc.segment(df, ds.target, by)
