"""initial schema: users, datasets, models, scoring runs, reports

Revision ID: 0001
Revises:
"""
from alembic import op
import sqlalchemy as sa

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

TS = sa.DateTime(timezone=True)


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("created_at", TS, nullable=False),
    )
    op.create_index("ix_users_email", "users", ["email"], unique=True)

    op.create_table(
        "datasets",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("owner_id", sa.Integer, sa.ForeignKey("users.id"), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("filename", sa.String(255), nullable=False),
        sa.Column("raw_path", sa.String(500), nullable=False),
        sa.Column("clean_path", sa.String(500)),
        sa.Column("rows", sa.Integer, nullable=False),
        sa.Column("columns", sa.Integer, nullable=False),
        sa.Column("target", sa.String(120)),
        sa.Column("id_columns", sa.JSON, nullable=False),
        sa.Column("status", sa.String(20), nullable=False),
        sa.Column("validation", sa.JSON),
        sa.Column("cleaning_report", sa.JSON),
        sa.Column("created_at", TS, nullable=False),
    )
    op.create_index("ix_datasets_owner_id", "datasets", ["owner_id"])

    op.create_table(
        "models",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("owner_id", sa.Integer, sa.ForeignKey("users.id"), nullable=False),
        sa.Column("dataset_id", sa.Integer, sa.ForeignKey("datasets.id"), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("algorithm", sa.String(60), nullable=False),
        sa.Column("status", sa.String(20), nullable=False),
        sa.Column("config", sa.JSON, nullable=False),
        sa.Column("metrics", sa.JSON),
        sa.Column("result", sa.JSON),
        sa.Column("artifact_path", sa.String(500)),
        sa.Column("is_active", sa.Boolean, nullable=False),
        sa.Column("error", sa.Text),
        sa.Column("created_at", TS, nullable=False),
        sa.Column("finished_at", TS),
    )
    op.create_index("ix_models_owner_id", "models", ["owner_id"])
    op.create_index("ix_models_dataset_id", "models", ["dataset_id"])

    op.create_table(
        "scoring_runs",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("owner_id", sa.Integer, sa.ForeignKey("users.id"), nullable=False),
        sa.Column("model_id", sa.Integer, sa.ForeignKey("models.id"), nullable=False),
        sa.Column("dataset_id", sa.Integer, sa.ForeignKey("datasets.id")),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("rows", sa.Integer, nullable=False),
        sa.Column("summary", sa.JSON),
        sa.Column("results_path", sa.String(500), nullable=False),
        sa.Column("created_at", TS, nullable=False),
    )
    op.create_index("ix_scoring_runs_owner_id", "scoring_runs", ["owner_id"])
    op.create_index("ix_scoring_runs_model_id", "scoring_runs", ["model_id"])

    op.create_table(
        "reports",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("owner_id", sa.Integer, sa.ForeignKey("users.id"), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("kind", sa.String(40), nullable=False),
        sa.Column("fmt", sa.String(10), nullable=False),
        sa.Column("path", sa.String(500), nullable=False),
        sa.Column("params", sa.JSON, nullable=False),
        sa.Column("created_at", TS, nullable=False),
    )
    op.create_index("ix_reports_owner_id", "reports", ["owner_id"])


def downgrade() -> None:
    for t in ("reports", "scoring_runs", "models", "datasets", "users"):
        op.drop_table(t)
