import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import { listDatasets } from '../api/datasets'
import { listModels } from '../api/models'
import { listRuns } from '../api/predictions'
import { useAuth } from './AuthContext'

const Ctx = createContext(null)
export const useApp = () => useContext(Ctx)

const load = (k) => { try { return JSON.parse(localStorage.getItem(k)) } catch { return null } }
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)) } catch { /* ignore */ } }

export function AppProvider({ children }) {
  const { user } = useAuth()
  const [datasets, setDatasets] = useState([])
  const [models, setModels] = useState([])
  const [runs, setRuns] = useState([])
  const [datasetId, setDatasetIdRaw] = useState(load('sel_dataset'))
  const [toasts, setToasts] = useState([])

  const setDatasetId = (id) => { setDatasetIdRaw(id); save('sel_dataset', id) }

  const refresh = useCallback(async () => {
    const [d, m, r] = await Promise.all([listDatasets(), listModels(), listRuns()])
    setDatasets(d); setModels(m); setRuns(r)
    setDatasetIdRaw((cur) => (d.some((x) => x.id === cur) ? cur : d[0]?.id ?? null))
    return { d, m, r }
  }, [])

  useEffect(() => { if (user) refresh().catch(() => {}) }, [user, refresh])

  const toast = useCallback((message, type = 'info') => {
    const id = Math.random()
    setToasts((t) => [...t, { id, message, type }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4500)
  }, [])

  const dataset = datasets.find((d) => d.id === datasetId) || null
  const activeModel = models.find((m) => m.is_active) || null

  return (
    <Ctx.Provider value={{ datasets, models, runs, dataset, datasetId, setDatasetId, activeModel, refresh, toast, toasts }}>
      {children}
    </Ctx.Provider>
  )
}
