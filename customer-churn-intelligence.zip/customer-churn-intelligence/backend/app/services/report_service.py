"""PDF / CSV report generation (reportlab)."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from reportlab.graphics.charts.barcharts import HorizontalBarChart
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from ..core.config import settings
from ..database.models import Dataset, MLModel, ScoringRun
from . import analytics_service, dataset_service, prediction_service, retention_service

INDIGO = colors.HexColor("#4f46e5")
SS = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=SS["Title"], textColor=INDIGO, fontSize=22, alignment=0, spaceAfter=4)
H2 = ParagraphStyle("H2", parent=SS["Heading2"], textColor=colors.HexColor("#111827"), spaceBefore=14, spaceAfter=6)
BODY = ParagraphStyle("B", parent=SS["BodyText"], fontSize=9.5, leading=13)
SMALL = ParagraphStyle("S", parent=BODY, fontSize=8, textColor=colors.grey)


def _table(rows, widths=None, header=True):
    t = Table(rows, colWidths=widths, repeatRows=1 if header else 0)
    style = [("FONTSIZE", (0, 0), (-1, -1), 8.5), ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#d1d5db")),
             ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f9fafb")]),
             ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]
    if header:
        style += [("BACKGROUND", (0, 0), (-1, 0), INDIGO), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                  ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold")]
    t.setStyle(TableStyle(style))
    return t


def _bar(items: list[tuple[str, float]], height=160):
    d = Drawing(440, height)
    c = HorizontalBarChart()
    c.x, c.y, c.width, c.height = 130, 10, 290, height - 20
    c.data = [[v for _, v in reversed(items)]]
    c.categoryAxis.categoryNames = [k[:24] for k, _ in reversed(items)]
    c.categoryAxis.labels.fontSize = 7
    c.valueAxis.labels.fontSize = 7
    c.bars[0].fillColor = INDIGO
    d.add(c)
    return d


def _doc(path: Path, title: str, story: list):
    def footer(canvas, doc):
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(colors.grey)
        canvas.drawString(2 * cm, 1.2 * cm, f"{title} · generated {datetime.now():%Y-%m-%d %H:%M}")
        canvas.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"Page {doc.page}")

    SimpleDocTemplate(str(path), pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm,
                      bottomMargin=2 * cm, title=title).build(story, onFirstPage=footer, onLaterPages=footer)


def _kpis(pairs):
    return _table([[k for k, _ in pairs], [v for _, v in pairs]])


def _model_section(m: MLModel) -> list:
    r = m.result or {}
    met = m.metrics or {}
    cm_ = r.get("confusion_matrix", {})
    s = [Paragraph("Model performance", H2),
         Paragraph(f"<b>{m.name}</b> ({m.algorithm.replace('_', ' ')}), decision threshold {met.get('threshold')}. "
                   f"Cross-validated ROC-AUC: {met.get('cv_roc_auc_mean')}.", BODY), Spacer(1, 6),
         _table([["ROC-AUC", "PR-AUC", "Accuracy", "Precision", "Recall", "F1"],
                 [met.get(k) for k in ("roc_auc", "pr_auc", "accuracy", "precision", "recall", "f1")]]), Spacer(1, 8),
         _table([["", "Pred. retained", "Pred. churn"], ["Actual retained", cm_.get("tn"), cm_.get("fp")],
                 ["Actual churn", cm_.get("fn"), cm_.get("tp")]], widths=[4 * cm, 4 * cm, 4 * cm])]
    imp = [(i["feature"], i["importance"]) for i in (r.get("importance") or [])[:10]]
    if imp:
        s += [Paragraph("Top drivers of churn (permutation importance, ΔROC-AUC)", H2), _bar(imp)]
    lift = r.get("lift_table") or []
    if lift:
        s += [Paragraph("Lift by risk decile", H2),
              _table([["Decile", "Customers", "Churn rate", "Lift", "Cum. capture"]] +
                     [[l["decile"], l["customers"], f"{l['churn_rate']:.1%}", l["lift"], f"{l['cum_capture']:.1%}"] for l in lift])]
    return s


def build(db, user, kind: str, fmt: str, title: str | None, ds: Dataset | None, model: MLModel | None,
          run: ScoringRun | None, report_id_hint: int) -> tuple[str, str]:
    """Returns (title, path)."""
    base = settings.reports_dir / f"{kind}_{report_id_hint}_{datetime.now():%Y%m%d%H%M%S}"

    if kind == "at_risk_customers":
        if not run:
            raise ValueError("Select a scoring run for the at-risk customers report")
        df = retention_service.prepared(run, prediction_service.load_run(run))
        d = df[df["predicted_churn"] == 1].sort_values("expected_loss", ascending=False)
        id_col = (run.summary or {}).get("id_column")
        cols = ([id_col] if id_col else []) + ["churn_probability", "risk_tier", "monthly_value", "expected_loss",
                                                "primary_driver", "recommended_action", "action_owner"]
        out = d[cols]
        t = title or f"At-risk customers · {run.name}"
        if fmt == "csv":
            p = base.with_suffix(".csv")
            out.to_csv(p, index=False)
            return t, str(p)
        p = base.with_suffix(".pdf")
        rows = [[c.replace("_", " ").title() for c in cols]] + [
            [(f"{v:.2f}" if isinstance(v, float) else str(v))[:34] for v in r] for r in out.head(60).itertuples(index=False)]
        _doc(p, t, [Paragraph(t, H1), Paragraph(f"{len(out)} predicted churners; top 60 by expected loss shown.", BODY),
                    Spacer(1, 8), _table(rows)])
        return t, str(p)

    if fmt == "csv":
        raise ValueError("CSV is only available for the at-risk customers report")

    p = base.with_suffix(".pdf")
    if kind == "model_performance":
        if not model:
            raise ValueError("Select a model")
        t = title or f"Model performance · {model.name}"
        _doc(p, t, [Paragraph(t, H1)] + _model_section(model))
        return t, str(p)

    # executive summary
    if not ds:
        raise ValueError("Select a dataset")
    t = title or f"Executive churn summary · {ds.name}"
    df = dataset_service.load_df(ds)
    ov = analytics_service.overview(df, ds.target)
    story = [Paragraph(t, H1), Paragraph(f"Prepared for {user.name or user.email}", SMALL), Spacer(1, 10),
             Paragraph("Headline", H2),
             _kpis([("Customers", f"{ov['rows']:,}"), ("Churn rate", f"{ov.get('churn_rate', 0):.1%}"),
                    ("Churned", f"{ov.get('churned', 0):,}"),
                    ("Monthly revenue lost", f"{ov.get('monthly_revenue_churned', 0):,.0f}" if 'monthly_revenue_churned' in ov else "n/a")])]
    e = analytics_service.eda(df, ds.target, ds.id_columns)
    cats = e["categorical"][:3]
    if cats:
        story.append(Paragraph("Where churn concentrates", H2))
        for c in cats:
            top = sorted(c["values"], key=lambda v: -v.get("churn_rate", 0))[:3]
            story.append(Paragraph(f"<b>{c['column']}</b>: " + ", ".join(f"{v['value']} ({v['churn_rate']:.1%})" for v in top), BODY))
    if run:
        df_r = retention_service.prepared(run, prediction_service.load_run(run))
        o = retention_service.overview(df_r)
        story += [Paragraph("Retention opportunity", H2),
                  _kpis([("Scored", f"{o['customers']:,}"), ("Predicted churners", f"{o['predicted_churners']:,}"),
                         ("Expected loss (12m)", f"{o['total_expected_loss']:,.0f}"),
                         ("Monthly rev. at risk", f"{o['monthly_revenue_at_risk']:,.0f}")]), Spacer(1, 8),
                  _table([["Tier", "Customers", "Avg probability", "Expected loss"]] +
                         [[x["tier"], x["customers"], f"{x['avg_probability']:.1%}", f"{x['expected_loss']:,.0f}"] for x in o["tiers"]])]
        recs = retention_service.recommendations(df_r)[:6]
        if recs:
            story += [Paragraph("Recommended actions", H2),
                      _table([["Action", "Owner", "Customers", "Expected loss"]] +
                             [[r["recommended_action"][:62], r["action_owner"], r["customers"], f"{r['expected_loss']:,.0f}"] for r in recs],
                             widths=[8.5 * cm, 3 * cm, 2.2 * cm, 3 * cm])]
    if model:
        story += _model_section(model)
    _doc(p, t, story)
    return t, str(p)
