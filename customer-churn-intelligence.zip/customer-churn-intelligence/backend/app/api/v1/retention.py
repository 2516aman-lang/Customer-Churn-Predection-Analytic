from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.orm import Session

from ...database.models import User
from ...database.session import get_db
from ...schemas import EmailExportIn, SimulateIn, WebhookExportIn
from ...services import export_service, prediction_service, retention_service as svc
from ..deps import current_user, get_run

router = APIRouter(prefix="/retention", tags=["retention"])


def _df(db, run_id, user, clv_months=12, default_monthly=60.0):
    run = get_run(db, run_id, user)
    return run, svc.prepared(run, prediction_service.load_run(run), clv_months, default_monthly)


@router.get("/{run_id}/overview")
def overview(run_id: int, clv_months: int = Query(12, ge=1, le=120), default_monthly_value: float = 60.0,
             db: Session = Depends(get_db), user: User = Depends(current_user)):
    _, df = _df(db, run_id, user, clv_months, default_monthly_value)
    return svc.overview(df)


@router.get("/{run_id}/customers")
def customers(run_id: int, tier: str | None = None, limit: int = Query(25, ge=1, le=200), offset: int = Query(0, ge=0),
              clv_months: int = Query(12, ge=1, le=120), db: Session = Depends(get_db), user: User = Depends(current_user)):
    run, df = _df(db, run_id, user, clv_months)
    return svc.at_risk(df, (run.summary or {}).get("id_column"), tier, limit, offset)


@router.get("/{run_id}/recommendations")
def recommendations(run_id: int, clv_months: int = Query(12, ge=1, le=120), db: Session = Depends(get_db),
                    user: User = Depends(current_user)):
    _, df = _df(db, run_id, user, clv_months)
    return svc.recommendations(df)


@router.post("/{run_id}/simulate")
def simulate(run_id: int, body: SimulateIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    _, df = _df(db, run_id, user, body.clv_months, body.default_monthly_value)
    return svc.simulate(df, body.budget, body.cost_per_contact, body.offer_cost_pct, body.success_rate, body.min_probability)


# ---------------------------------------------------------------- export
@router.get("/export/config")
def export_config(_: User = Depends(current_user)):
    return {"email_configured": export_service.smtp_configured(), "webhook_configured": export_service.webhook_configured(),
            "crm_formats": list(export_service.CRM_FORMATS)}


@router.get("/{run_id}/export/csv")
def export_csv(run_id: int, fmt: str = "generic", min_tier: str = "High", clv_months: int = Query(12, ge=1, le=120),
               db: Session = Depends(get_db), user: User = Depends(current_user)):
    run = get_run(db, run_id, user)
    try:
        df = export_service.to_crm(export_service.at_risk_frame(run, min_tier, clv_months), fmt)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return Response(export_service.csv_bytes(df), media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="at_risk_{fmt}_run{run.id}.csv"'})


@router.post("/{run_id}/export/email")
def export_email(run_id: int, body: EmailExportIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    run = get_run(db, run_id, user)
    try:
        df = export_service.at_risk_frame(run, body.min_tier)
        text = (body.message + "\n\n" if body.message else "") + export_service.summary_text(run, df, body.min_tier)
        export_service.send_email(body.to, body.subject or f"[Churn] {run.name}: {len(df)} at-risk customers", text,
                                  export_service.csv_bytes(export_service.to_crm(df, body.crm_format)))
    except ValueError as e:
        raise HTTPException(400, str(e))
    except OSError as e:  # connection / SMTP failures
        raise HTTPException(502, f"Could not send email: {e}")
    return {"sent": True, "customers": len(df), "recipients": body.to}


@router.post("/{run_id}/export/webhook")
def export_webhook(run_id: int, body: WebhookExportIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    run = get_run(db, run_id, user)
    try:
        return export_service.push_webhook(run, export_service.at_risk_frame(run, body.min_tier), body.url)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001  (httpx transport errors)
        raise HTTPException(502, f"Webhook delivery failed: {e}")
