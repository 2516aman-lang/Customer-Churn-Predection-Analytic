/** Generic table. columns: [{key, label, render?, wrap?, align?}] */
export default function DataTable({ columns, rows, total, offset = 0, limit, onPage, empty = 'No rows', rowKey }) {
  return (
    <>
      <div className="table-wrap">
        <table>
          <thead><tr>{columns.map((c) => <th key={c.key} style={{ textAlign: c.align }}>{c.label ?? c.key}</th>)}</tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={columns.length} className="muted" style={{ textAlign: 'center', padding: 24 }}>{empty}</td></tr>}
            {rows.map((r, i) => (
              <tr key={rowKey ? r[rowKey] : i}>
                {columns.map((c) => (
                  <td key={c.key} className={c.wrap ? 'wrap' : ''} style={{ textAlign: c.align }}>
                    {c.render ? c.render(r[c.key], r) : r[c.key] ?? <span className="muted">—</span>}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {onPage && total > limit && (
        <div className="pager">
          <span>{offset + 1}–{Math.min(offset + limit, total)} of {total.toLocaleString()}</span>
          <span className="row">
            <button className="btn sm" disabled={offset === 0} onClick={() => onPage(Math.max(0, offset - limit))}>Prev</button>
            <button className="btn sm" disabled={offset + limit >= total} onClick={() => onPage(offset + limit)}>Next</button>
          </span>
        </div>
      )}
    </>
  )
}
