"""Inference helpers: load artifacts, score customers, assign risk tiers, explain drivers."""
from __future__ import annotations

from functools import lru_cache

import joblib
import pandas as pd

from . import explainability as xai
from .cleaning import _coerce_numeric_like

TIERS = [(0.7, "Critical"), (0.5, "High"), (0.3, "Medium"), (0.0, "Low")]


def risk_tier(p: float) -> str:
    for cut, name in TIERS:
        if p >= cut:
            return name
    return "Low"


@lru_cache(maxsize=8)
def load_artifact(path: str) -> dict:
    return joblib.load(path)


def clear_cache():
    load_artifact.cache_clear()


def prepare_frame(df: pd.DataFrame, meta: dict) -> pd.DataFrame:
    """Align an incoming frame to the training schema (missing columns -> NaN, order, numeric coercion)."""
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    rep = {"coerced_numeric": []}
    df = _coerce_numeric_like(df, rep)
    X = pd.DataFrame(index=df.index)
    for c in meta["features"]:
        if c in df.columns:
            X[c] = df[c]
        else:
            X[c] = pd.NA
        if meta["feature_types"][c] == "numeric":
            X[c] = pd.to_numeric(X[c], errors="coerce")
        else:
            X[c] = X[c].astype("object").where(X[c].notna(), None)
    return X


def predict_frame(path: str, df: pd.DataFrame, explain: bool = True, top_k: int = 3) -> pd.DataFrame:
    art = load_artifact(path)
    pipe, meta = art["pipeline"], art["meta"]
    X = prepare_frame(df, meta)
    proba = pipe.predict_proba(X)[:, 1]
    out = pd.DataFrame(index=df.index)
    out["churn_probability"] = proba.round(4)
    out["predicted_churn"] = (proba >= meta["threshold"]).astype(int)
    out["risk_tier"] = [risk_tier(p) for p in proba]
    if explain:
        out["top_drivers"] = xai.batch_top_drivers(pipe, X, meta["baselines"], top_k=top_k)
    return out


def predict_one(path: str, record: dict, top_k: int = 5) -> dict:
    art = load_artifact(path)
    pipe, meta = art["pipeline"], art["meta"]
    X = prepare_frame(pd.DataFrame([record]), meta)
    p = float(pipe.predict_proba(X)[0, 1])
    return {
        "churn_probability": round(p, 4),
        "predicted_churn": int(p >= meta["threshold"]),
        "risk_tier": risk_tier(p),
        "threshold": meta["threshold"],
        "drivers": xai.local_contributions(pipe, X, meta["baselines"], top_k=top_k),
    }
