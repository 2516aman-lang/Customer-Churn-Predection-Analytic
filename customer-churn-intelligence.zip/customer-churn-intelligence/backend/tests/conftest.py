import os
import shutil
import sys
import tempfile
from pathlib import Path

import pytest

_tmp = Path(tempfile.mkdtemp(prefix="churn_test_"))
ML_SRC = Path(__file__).resolve().parents[2] / "ml"
(_tmp / "ml").mkdir()
shutil.copytree(ML_SRC / "src", _tmp / "ml" / "src")
os.environ.update(
    DATABASE_URL=f"sqlite:///{_tmp / 'test.db'}", ML_DIR=str(_tmp / "ml"), REPORTS_DIR=str(_tmp / "reports"),
    SYNC_TRAINING="1", ENABLE_SCHEDULER="0", ALLOW_PRIVATE_WEBHOOKS="1", SECRET_KEY="test-secret-key-that-is-long-enough-for-hs256",
)
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="session")
def auth(client):
    r = client.post("/api/v1/auth/register", json={"email": "t@example.com", "password": "secret1", "name": "Tester"})
    assert r.status_code == 201, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}
