"""Application settings (env-driven). Paths default to the monorepo layout."""
from __future__ import annotations

import sys
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]  # customer-churn-intelligence/


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    APP_NAME: str = "Customer Churn Intelligence"
    API_V1_PREFIX: str = "/api/v1"
    SECRET_KEY: str = "change-me-in-production"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 12
    DATABASE_URL: str = f"sqlite:///{ROOT / 'backend' / 'churn.db'}"
    CORS_ORIGINS: str = "http://localhost:5173,http://127.0.0.1:5173"
    ML_DIR: str = str(ROOT / "ml")
    REPORTS_DIR: str = str(ROOT / "reports")
    MAX_UPLOAD_MB: int = 50
    SYNC_TRAINING: bool = False  # run training inline (used by tests)
    TRAIN_WORKERS: int = 2
    AUTO_MIGRATE: bool = True  # run `alembic upgrade head` on startup
    # scheduler
    ENABLE_SCHEDULER: bool = True
    SCHEDULER_INTERVAL_SECONDS: int = 30
    # email export (SMTP)
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM: str = "churn-intelligence@localhost"
    SMTP_STARTTLS: bool = True
    # CRM webhook export
    CRM_WEBHOOK_URL: str = ""
    CRM_WEBHOOK_TOKEN: str = ""
    ALLOW_PRIVATE_WEBHOOKS: bool = False  # SSRF guard: block private/loopback targets unless true

    @property
    def raw_dir(self) -> Path:
        return Path(self.ML_DIR) / "data" / "raw"

    @property
    def processed_dir(self) -> Path:
        return Path(self.ML_DIR) / "data" / "processed"

    @property
    def artifacts_dir(self) -> Path:
        return Path(self.ML_DIR) / "artifacts"

    @property
    def reports_dir(self) -> Path:
        return Path(self.REPORTS_DIR)

    def ensure_dirs(self):
        for p in (self.raw_dir, self.processed_dir, self.artifacts_dir, self.reports_dir):
            p.mkdir(parents=True, exist_ok=True)


settings = Settings()
settings.ensure_dirs()
# make `ml/src` importable as the `src` package
if settings.ML_DIR not in sys.path:
    sys.path.insert(0, settings.ML_DIR)
