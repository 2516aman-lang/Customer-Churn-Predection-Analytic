import { useState } from 'react'
import { Pause, Play, Plus, RefreshCw, Trash2 } from 'lucide-react'
import { exportConfig } from '../api/predictions'
import { createSchedule, deleteSchedule, listSchedules, runSchedule, updateSchedule } from '../api/schedules'
import { Badge, Button, Card, EmptyState, Field, Loader, PageHeader, Select } from '../components/common'
import DataTable from '../components/tables/DataTable'
import { useApp } from '../context/AppContext'
import { useAction } from '../hooks/useAction'
import { useAsync } from '../hooks/useAsync'

const when = (v) => (v ? new Date(v).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' }) : '—')

export default function Automation() {
  const { datasets, models, datasetId, refresh } = useApp()
  const { data: schedules, loading, reload } = useAsync(listSchedules, [])
  const { data: cfg } = useAsync(exportConfig, [])
  const done = models.filter((m) => m.status === 'completed')
  const ready = datasets.filter((d) => d.status === 'cleaned')
  const [f, setF] = useState({ name: '', dataset_id: '', model_id: '', frequency: 'daily', min_tier: 'High', email_to: '', push_webhook: false })
  const set = (k) => (v) => setF({ ...f, [k]: v })

  const [create, creating] = useAction(async () => {
    await createSchedule({ ...f, name: f.name || 'Scheduled scoring', dataset_id: Number(f.dataset_id || datasetId || ready[0]?.id), model_id: f.model_id ? Number(f.model_id) : null, email_to: f.email_to.trim() || null })
    await reload()
  }, { success: 'Schedule created' })
  const [runNow, running] = useAction(async (id) => { await runSchedule(id); await Promise.all([reload(), refresh()]) }, { success: 'Run finished — see status' })
  const [toggle] = useAction(async (s) => { await updateSchedule(s.id, { enabled: !s.enabled }); await reload() })
  const [remove] = useAction(async (id) => { await deleteSchedule(id); await reload() }, { success: 'Schedule deleted' })

  return (
    <>
      <PageHeader title="Automation" subtitle="Re-score customers on a schedule, then email or push the at-risk list to your CRM." />
      <div className="stack">
        <Card title="New schedule" sub="Each run re-reads the dataset, scores it, stores a new scoring run and compares it with the previous one.">
          {!ready.length ? <EmptyState title="No cleaned dataset" text="Clean a dataset first (Datasets → Clean)." /> : (
            <div className="stack">
              <div className="grid g4">
                <Field label="Name"><input value={f.name} onChange={(e) => set('name')(e.target.value)} placeholder="Nightly scoring" /></Field>
                <Select label="Dataset" value={f.dataset_id || datasetId || ''} onChange={set('dataset_id')} options={ready.map((d) => ({ value: d.id, label: d.name }))} help="Refresh its data from the Datasets page" />
                <Select label="Model" value={f.model_id} onChange={set('model_id')} options={done.map((m) => ({ value: m.id, label: m.name }))} placeholder="Always the active model" />
                <Select label="Frequency" value={f.frequency} onChange={set('frequency')} options={['hourly', 'daily', 'weekly']} />
              </div>
              <div className="grid g4">
                <Select label="Notify for tier ≥" value={f.min_tier} onChange={set('min_tier')} options={['Critical', 'High', 'Medium', 'Low']} />
                <Field label="Email recipients" help={cfg && !cfg.email_configured ? 'Email not configured on server' : 'Comma-separated, optional'}><input disabled={cfg && !cfg.email_configured} value={f.email_to} onChange={(e) => set('email_to')(e.target.value)} placeholder="team@company.com" /></Field>
                <Field label="CRM webhook" help={cfg && !cfg.webhook_configured ? 'Webhook not configured on server' : 'Push list after each run'}>
                  <label className="row" style={{ gap: 8, padding: '8px 0' }}><input type="checkbox" style={{ width: 'auto' }} disabled={cfg && !cfg.webhook_configured} checked={f.push_webhook} onChange={(e) => set('push_webhook')(e.target.checked)} />Push to CRM</label>
                </Field>
              </div>
              <div><Button variant="primary" icon={Plus} busy={creating} onClick={create}>Create schedule</Button></div>
            </div>
          )}
        </Card>

        <Card title="Schedules">
          {loading && !schedules ? <Loader /> : !schedules?.length ? <EmptyState title="Nothing scheduled" text="Create one above." /> : (
            <DataTable rows={schedules} rowKey="id" columns={[
              { key: 'name', label: 'Schedule', render: (v, s) => <div><b>{v}</b><div className="small muted">{datasets.find((d) => d.id === s.dataset_id)?.name || `Dataset #${s.dataset_id}`}</div></div> },
              { key: 'frequency', label: 'Every', render: (v, s) => <span>{v} {!s.enabled && <Badge kind="queued">paused</Badge>}</span> },
              { key: 'next_run_at', label: 'Next run', render: (v, s) => (s.enabled ? when(v) : '—') },
              { key: 'last_run_at', label: 'Last run', render: when },
              { key: 'last_status', label: 'Status', render: (v) => (v ? <Badge kind={v === 'ok' ? 'completed' : 'failed'}>{v}</Badge> : '—') },
              { key: 'last_message', label: 'Result', wrap: true },
              { key: 'id', label: '', render: (id, s) => (
                <div className="row" style={{ flexWrap: 'nowrap' }}>
                  <Button size="sm" icon={RefreshCw} busy={running} onClick={() => runNow(id)}>Run now</Button>
                  <Button size="sm" variant="ghost" icon={s.enabled ? Pause : Play} aria-label={s.enabled ? 'Pause' : 'Resume'} onClick={() => toggle(s)} />
                  <Button size="sm" variant="ghost" icon={Trash2} aria-label="Delete" onClick={() => confirm(`Delete "${s.name}"?`) && remove(id)} />
                </div>) },
            ]} />
          )}
        </Card>
      </div>
    </>
  )
}
