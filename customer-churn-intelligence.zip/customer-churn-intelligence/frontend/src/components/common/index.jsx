import { useRef, useState } from 'react'
import { Loader2, Upload } from 'lucide-react'

export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="page-header">
      <div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>
      <div className="row">{children}</div>
    </div>
  )
}

export function Card({ title, sub, actions, children, className = '' }) {
  return (
    <section className={`card ${className}`}>
      {(title || actions) && (
        <div className="card-head">
          <div><h3>{title}</h3>{sub && <div className="sub">{sub}</div>}</div>
          {actions}
        </div>
      )}
      {children}
    </section>
  )
}

export function StatCard({ label, value, hint, tone }) {
  return (
    <div className={`card stat ${tone || ''}`}>
      <div className="label">{label}</div>
      <div className="value">{value ?? '—'}</div>
      {hint && <div className="hint">{hint}</div>}
    </div>
  )
}

export function Button({ children, icon: Icon, busy, variant, size, ...rest }) {
  return (
    <button className={`btn ${variant || ''} ${size || ''}`} disabled={busy || rest.disabled} {...rest}>
      {busy ? <Loader2 size={15} className="spin" /> : Icon && <Icon size={15} />}
      {children}
    </button>
  )
}

export const Badge = ({ kind, children }) => <span className={`badge ${kind || ''}`}>{children ?? kind}</span>

export const Loader = ({ label = 'Loading…' }) => (
  <div className="loader"><Loader2 className="spin" size={18} /> {label}</div>
)

export const EmptyState = ({ title, text, children }) => (
  <div className="empty"><h3>{title}</h3><p>{text}</p>{children}</div>
)

export const ErrorBox = ({ error }) => (error ? <div className="alert error">{error}</div> : null)

export function Field({ label, help, children }) {
  return <label className="field"><span className="cap">{label}</span>{children}{help && <span className="help">{help}</span>}</label>
}

export function Select({ label, value, onChange, options, placeholder, help }) {
  return (
    <Field label={label} help={help}>
      <select value={value ?? ''} onChange={(e) => onChange(e.target.value)}>
        {placeholder && <option value="">{placeholder}</option>}
        {options.map((o) => (typeof o === 'object' ? <option key={o.value} value={o.value}>{o.label}</option> : <option key={o}>{o}</option>))}
      </select>
    </Field>
  )
}

export function NumberField({ label, value, onChange, help, ...rest }) {
  return (
    <Field label={label} help={help}>
      <input type="number" value={value} onChange={(e) => onChange(e.target.value === '' ? '' : Number(e.target.value))} {...rest} />
    </Field>
  )
}

export function Tabs({ tabs, value, onChange }) {
  return (
    <div className="tabs">
      {tabs.map((t) => (
        <button key={t.key} className={`tab ${value === t.key ? 'active' : ''}`} onClick={() => onChange(t.key)}>{t.label}</button>
      ))}
    </div>
  )
}

export function FileDrop({ onFile, accept = '.csv,.xlsx,.xls,.tsv', label = 'Drop a CSV / Excel file here, or click to browse', busy }) {
  const ref = useRef()
  const [over, setOver] = useState(false)
  return (
    <div
      className={`drop ${over ? 'over' : ''}`}
      onClick={() => ref.current.click()}
      onDragOver={(e) => { e.preventDefault(); setOver(true) }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); e.dataTransfer.files[0] && onFile(e.dataTransfer.files[0]) }}
    >
      <input ref={ref} type="file" accept={accept} hidden onChange={(e) => { e.target.files[0] && onFile(e.target.files[0]); e.target.value = '' }} />
      {busy ? <Loader2 className="spin" /> : <Upload />}
      <div style={{ marginTop: 6 }}>{busy ? 'Uploading…' : label}</div>
    </div>
  )
}

export const fmt = {
  pct: (v, d = 1) => (v == null ? '—' : `${(v * 100).toFixed(d)}%`),
  num: (v) => (v == null ? '—' : Number(v).toLocaleString()),
  money: (v) => (v == null ? '—' : Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 })),
  dec: (v, d = 3) => (v == null ? '—' : Number(v).toFixed(d)),
}

export const TIER_COLORS = { Critical: '#dc2626', High: '#f97316', Medium: '#eab308', Low: '#22c55e' }
