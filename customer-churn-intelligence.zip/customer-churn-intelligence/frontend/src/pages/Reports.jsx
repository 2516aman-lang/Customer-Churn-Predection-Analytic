import { useState } from 'react'
import { Download, FilePlus, Trash2 } from 'lucide-react'
import { download } from '../api/client'
import { createReport, deleteReport, listReports } from '../api/predictions'
import { Badge, Button, Card, EmptyState, Loader, PageHeader, Select } from '../components/common'
import DataTable from '../components/tables/DataTable'
import { useApp } from '../context/AppContext'
import { useAction } from '../hooks/useAction'
import { useAsync } from '../hooks/useAsync'

const KINDS = [
  { value: 'executive_summary', label: 'Executive summary (PDF)', needs: ['dataset', 'model', 'run'], fmts: ['pdf'] },
  { value: 'model_performance', label: 'Model performance (PDF)', needs: ['model'], fmts: ['pdf'] },
  { value: 'at_risk_customers', label: 'At-risk customers', needs: ['run'], fmts: ['csv', 'pdf'] },
]

export default function Reports() {
  const { datasets, models, runs, datasetId, activeModel } = useApp()
  const { data: reports, loading, reload } = useAsync(listReports, [])
  const [kind, setKind] = useState('executive_summary')
  const [fmt, setFmt] = useState('pdf')
  const [ds, setDs] = useState(datasetId ?? '')
  const [model, setModel] = useState(activeModel?.id ?? '')
  const [run, setRun] = useState(runs[0]?.id ?? '')
  const k = KINDS.find((x) => x.value === kind)
  const done = models.filter((m) => m.status === 'completed')
  const [make, busy] = useAction(async () => {
    await createReport({ kind, fmt: k.fmts.includes(fmt) ? fmt : k.fmts[0], dataset_id: k.needs.includes('dataset') && ds ? Number(ds) : null, model_id: k.needs.includes('model') && model ? Number(model) : null, run_id: k.needs.includes('run') && run ? Number(run) : null })
    await reload()
  }, { success: 'Report generated' })
  const [remove] = useAction(async (id) => { await deleteReport(id); await reload() })

  return (
    <>
      <PageHeader title="Reports" subtitle="Shareable PDF and CSV deliverables for stakeholders." />
      <div className="stack">
        <Card title="Generate a report">
          <div className="grid g4">
            <Select label="Report" value={kind} onChange={(v) => { setKind(v); setFmt('pdf') }} options={KINDS} />
            {k.fmts.length > 1 && <Select label="Format" value={fmt} onChange={setFmt} options={k.fmts} />}
            {k.needs.includes('dataset') && <Select label="Dataset" value={ds} onChange={setDs} placeholder="Select…" options={datasets.map((d) => ({ value: d.id, label: d.name }))} />}
            {k.needs.includes('model') && <Select label="Model" value={model} onChange={setModel} placeholder="Select…" options={done.map((m) => ({ value: m.id, label: m.name }))} />}
            {k.needs.includes('run') && <Select label="Scoring run" value={run} onChange={setRun} placeholder="Select…" options={runs.map((r) => ({ value: r.id, label: `#${r.id} ${r.name}` }))} help={kind === 'executive_summary' ? 'Optional — adds retention section' : undefined} />}
          </div>
          <div style={{ marginTop: 14 }}><Button variant="primary" icon={FilePlus} busy={busy} onClick={make}>Generate</Button></div>
        </Card>
        <Card title="Generated reports">
          {loading && !reports ? <Loader /> : !reports?.length ? <EmptyState title="No reports yet" text="Generate one above." /> : (
            <DataTable rows={reports} rowKey="id" columns={[
              { key: 'title', label: 'Title' }, { key: 'kind', label: 'Type', render: (v) => v.replace(/_/g, ' ') },
              { key: 'fmt', label: 'Format', render: (v) => <Badge kind="info">{v.toUpperCase()}</Badge> },
              { key: 'created_at', label: 'Created', render: (v) => new Date(v).toLocaleString() },
              { key: 'id', label: '', render: (id, r) => <div className="row" style={{ flexWrap: 'nowrap' }}><Button size="sm" icon={Download} onClick={() => download(`/reports/${id}/download`, `${r.title}.${r.fmt}`)}>Download</Button><Button size="sm" variant="ghost" icon={Trash2} aria-label="Delete" onClick={() => remove(id)} /></div> },
            ]} />
          )}
        </Card>
      </div>
    </>
  )
}
