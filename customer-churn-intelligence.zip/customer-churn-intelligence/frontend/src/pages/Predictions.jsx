import { useEffect, useMemo, useState } from 'react'
import { Download, Play, Trash2, Zap } from 'lucide-react'
import { download } from '../api/client'
import { batchFromDataset, batchUpload, deleteRun, getRun, getSchema, predictSingle, whatIf } from '../api/predictions'
import { Badge, Button, Card, EmptyState, FileDrop, Loader, PageHeader, Select, Tabs, fmt, TIER_COLORS } from '../components/common'
import { Donut, ProbHistogram } from '../components/charts'
import DataTable from '../components/tables/DataTable'
import { useApp } from '../context/AppContext'
import { useAction } from '../hooks/useAction'
import { useAsync } from '../hooks/useAsync'

export default function Predictions() {
  const { models, activeModel } = useApp()
  const done = models.filter((m) => m.status === 'completed')
  const [modelId, setModelId] = useState(activeModel?.id ?? done[0]?.id ?? '')
  const [tab, setTab] = useState('single')
  useEffect(() => { if (!modelId && (activeModel || done[0])) setModelId((activeModel || done[0]).id) }, [activeModel, done.length])
  if (!done.length) return <><PageHeader title="Predictions" /><Card><EmptyState title="No trained models" text="Train a model in Model Studio first." /></Card></>
  return (
    <>
      <PageHeader title="Predictions" subtitle="Score one customer with explanations, or an entire book of business.">
        <div style={{ minWidth: 280 }}><Select label="Model" value={modelId} onChange={(v) => setModelId(Number(v))} options={done.map((m) => ({ value: m.id, label: `${m.name}${m.is_active ? ' (active)' : ''}` }))} /></div>
      </PageHeader>
      <Tabs value={tab} onChange={setTab} tabs={[{ key: 'single', label: 'Single customer & what-if' }, { key: 'batch', label: 'Batch scoring' }]} />
      {tab === 'single' ? <Single modelId={modelId} /> : <Batch modelId={modelId} />}
    </>
  )
}

function Gauge({ p, tier }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <div className="gauge" style={{ color: TIER_COLORS[tier] }}>{fmt.pct(p)}</div>
      <Badge kind={tier}>{tier} risk</Badge>
      <div className="meter" style={{ marginTop: 12 }}><span style={{ width: `${p * 100}%`, background: TIER_COLORS[tier] }} /></div>
    </div>
  )
}

function Drivers({ items }) {
  return items.map((d) => (
    <div key={d.feature} className="driver"><span>{d.feature} = <b>{String(d.value)}</b></span><span className={d.impact > 0 ? 'pos' : 'neg'}>{d.impact > 0 ? '+' : ''}{(d.impact * 100).toFixed(1)} pts</span></div>
  ))
}

function Single({ modelId }) {
  const { data: schema, loading } = useAsync(() => getSchema(modelId), [modelId], { enabled: !!modelId })
  const [rec, setRec] = useState({})
  const [res, setRes] = useState(null)
  const [changes, setChanges] = useState({})
  const [scen, setScen] = useState(null)
  useEffect(() => { if (schema) { setRec({ ...schema.baselines }); setRes(null); setScen(null); setChanges({}) } }, [schema])
  const [score, busy] = useAction(async () => { setRes(await predictSingle({ model_id: modelId, record: rec })); setScen(null) })
  const [sim, busy2] = useAction(async () => setScen(await whatIf({ model_id: modelId, record: rec, changes })))
  if (loading || !schema) return <Loader />

  const input = (f, value, onChange) => schema.feature_types[f] === 'numeric'
    ? <input type="number" step="any" value={value ?? ''} onChange={(e) => onChange(e.target.value === '' ? null : Number(e.target.value))} />
    : <select value={value ?? ''} onChange={(e) => onChange(e.target.value)}>{[...new Set([value, ...schema.feature_options[f]])].filter((x) => x != null).map((o) => <option key={o}>{o}</option>)}</select>

  return (
    <div className="grid g-wide">
      <Card title="Customer profile" sub="Pre-filled with typical values — adjust and score">
        <div className="grid g3">{schema.features.map((f) => <div className="field" key={f}><label>{f}</label>{input(f, rec[f], (v) => setRec({ ...rec, [f]: v }))}</div>)}</div>
        <div style={{ marginTop: 14 }}><Button variant="primary" icon={Zap} busy={busy} onClick={score}>Predict churn risk</Button></div>
      </Card>
      <div className="stack">
        <Card title="Result">
          {!res ? <div className="muted">Run a prediction to see the risk score and what drives it.</div> : (
            <div className="stack"><Gauge p={res.churn_probability} tier={res.risk_tier} />
              <div className="small muted">Flagged as churner above {fmt.pct(res.threshold, 0)}: <b>{res.predicted_churn ? 'Yes' : 'No'}</b></div>
              <div><div className="small muted" style={{ marginBottom: 4 }}>Top drivers (change vs. a typical customer)</div><Drivers items={res.drivers} /></div></div>
          )}
        </Card>
        {res && (
          <Card title="What-if scenario" sub="Which intervention would move this customer's risk?">
            <div className="stack">
              <Select label="Change a feature" value="" placeholder="Add a change…" onChange={(f) => f && setChanges({ ...changes, [f]: rec[f] })} options={schema.features.filter((f) => !(f in changes))} />
              {Object.entries(changes).map(([f, v]) => (
                <div className="field" key={f}><label>{f}</label><div className="row" style={{ flexWrap: 'nowrap' }}>{input(f, v, (x) => setChanges({ ...changes, [f]: x }))}<Button size="sm" variant="ghost" icon={Trash2} aria-label="Remove" onClick={() => { const c = { ...changes }; delete c[f]; setChanges(c) }} /></div></div>
              ))}
              <Button icon={Play} busy={busy2} disabled={!Object.keys(changes).length} onClick={sim}>Run scenario</Button>
              {scen && <div className="alert">Risk {fmt.pct(scen.baseline.churn_probability)} → <b>{fmt.pct(scen.scenario.churn_probability)}</b> ({scen.delta > 0 ? '+' : ''}{(scen.delta * 100).toFixed(1)} pts, now <Badge kind={scen.scenario.risk_tier}>{scen.scenario.risk_tier}</Badge>)</div>}
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}

function Batch({ modelId }) {
  const { dataset, runs, refresh, toast } = useApp()
  const [runId, setRunId] = useState(null)
  const [tier, setTier] = useState('All')
  const [offset, setOffset] = useState(0)
  const [scoreDs, b1] = useAction(async () => { const r = await batchFromDataset({ model_id: modelId, dataset_id: dataset.id }); await refresh(); setRunId(r.id) }, { success: 'Scoring complete' })
  const [scoreFile, b2] = useAction(async (f) => { const r = await batchUpload(modelId, f); await refresh(); setRunId(r.id) }, { success: 'Scoring complete' })
  const [remove] = useAction(async (id) => { await deleteRun(id); await refresh(); setRunId(null) }, { success: 'Run deleted' })
  useEffect(() => { if (!runId && runs.length) setRunId(runs[0].id) }, [runs.length])
  useEffect(() => setOffset(0), [runId, tier])
  const run = runs.find((r) => r.id === runId)
  const { data, loading } = useAsync(() => getRun(runId, { tier, limit: 15, offset }), [runId, tier, offset], { enabled: !!runId && !!run })

  const cols = useMemo(() => {
    if (!data) return []
    const first = run?.summary?.id_column || data.columns[0]
    const show = [first, 'churn_probability', 'risk_tier', 'predicted_churn', ...data.columns.filter((c) => !['churn_probability', 'risk_tier', 'predicted_churn', first].includes(c)).slice(0, 5)]
    return show.map((k) => ({ key: k, render: k === 'churn_probability' ? (v) => fmt.pct(v) : k === 'risk_tier' ? (v) => <Badge kind={v} /> : undefined }))
  }, [data, run])

  return (
    <div className="stack">
      <div className="grid g2">
        <Card title="Score a stored dataset" sub={dataset ? dataset.name : 'Select a dataset in the top bar'}><Button variant="primary" icon={Play} busy={b1} disabled={!dataset} onClick={scoreDs}>Score dataset</Button></Card>
        <Card title="Or upload new customers"><FileDrop onFile={scoreFile} busy={b2} label="Drop a CSV of customers to score" /></Card>
      </div>
      {runs.length > 0 && (
        <Card title="Scoring results" actions={run && <div className="row">
          <Button size="sm" icon={Download} onClick={() => download(`/predictions/runs/${run.id}/download`, `${run.name}.csv`)}>CSV</Button>
          <Button size="sm" variant="danger" icon={Trash2} onClick={() => confirm('Delete this run?') && remove(run.id)}>Delete</Button></div>}>
          <div className="stack">
            <div style={{ maxWidth: 420 }}><Select label="Run" value={runId ?? ''} onChange={(v) => setRunId(Number(v))} options={runs.map((r) => ({ value: r.id, label: `#${r.id} ${r.name} · ${r.rows} rows` }))} /></div>
            {run?.summary && (
              <div className="grid g3">
                <Donut data={Object.entries(run.summary.tiers).map(([name, value]) => ({ name, value }))} colors={TIER_COLORS} h={190} />
                <div><div className="small muted">Probability distribution</div><ProbHistogram counts={run.summary.histogram} h={170} /></div>
                <dl className="kv" style={{ alignContent: 'start' }}><dt>Customers</dt><dd>{fmt.num(run.summary.rows)}</dd><dt>Predicted churners</dt><dd>{fmt.num(run.summary.predicted_churners)}</dd><dt>Avg probability</dt><dd>{fmt.pct(run.summary.avg_probability)}</dd>{run.summary.expected_monthly_revenue_at_risk != null && <><dt>Monthly revenue at risk</dt><dd>{fmt.money(run.summary.expected_monthly_revenue_at_risk)}</dd></>}</dl>
              </div>
            )}
            <div className="row">{['All', 'Critical', 'High', 'Medium', 'Low'].map((t) => <button key={t} className={`btn sm ${tier === t ? 'primary' : ''}`} onClick={() => setTier(t)}>{t}</button>)}</div>
            {loading && !data ? <Loader /> : data && <DataTable columns={cols} rows={data.rows} total={data.total} offset={offset} limit={15} onPage={setOffset} />}
          </div>
        </Card>
      )}
    </div>
  )
}
